from __future__ import division
import sys,os, time, re
import numpy as np
sys.path.append('results/')
from copy import deepcopy
import itertools
from tools.userError import userError
from tools.globalVariables import *
from tools.io.read_sbml_model import read_sbml_model
from tools.core.compound import compound
from tools.core.reaction import reaction
from tools.core.organism import organism
from tools.core.model import model
from tools.fba.fba import fba
from tools.fba.set_specific_bounds import set_specific_bounds
from tools.fba.find_blocked_rxns import find_blocked_rxns
from tools.fba.find_essential_rxns import find_essential_rxns
from tools.fba.fcf import fcf
from tools.io.create_model import create_model
from tools.strain_design.OptForce.OptForce import OptForce
from ss_analysis import add_nsAA_pathways
from imp import load_source
from multiprocessing import Process, Manager, Value, Array
# Increse the recursion limit, otherwise deepcopy will complain
sys.setrecursionlimit(10000)

def create_refStrain_model(target_product = 'Pyrrolysine', is_nsAA = False, glc_uptake_rate = 100, aeration = 'aerobic', media_type = 'minimal', stdout_msgs = True, warnings = True):
    """
    Creates the updated model after adding external reactions for the production of nsAAs

    INPUTS:
    -------
    target_product:
    Name or id of the target product. If this is a non-standard amino acid, allowed 
    inputs are 'Pyrrolysine' and 'pAF'. Otherwise, provide the name or id of the
    target product (if providing id, it should be the id in the [e] compartment)

    is_nsAA:
    Represents if the target product is a nnn-standard amino acid (True) or not (False)

    glc_uptake_rate:
    Glucose uptake rate: 100 for OptForce applicaitons (since flux measurements are based on
    100 moles of glucose uptake). You can use 10 if you don't want to do OptForce 

    OUTPUTS:
    --------
    Ecoli_model:
    Modified metabolic model producing nsAA

    product_exchrxn_id:
    Exchange rxn id for the nsAA

    flux_bounds_dict & flux_bounds_filename
    Inputs to funciton set_specific_flux_bounds containing flux bounds for a specific growth
    medium or specific flux bounds for intracellular metabolic reactions

    Ali R. Zomorrodi - Segre's Lab @ BU
    Last updated: 08-08-2018
    """
    # Model path
    model_path = 'models/Escherichia_coli/iJO1366/'

    if media_type.lower() == 'minimal' and aeration.lower() == 'aerobic':
        flux_bounds_dict = {'EX_glc(e)':[-glc_uptake_rate,1000], 'EX_o2(e)':[-2*glc_uptake_rate,1000]}
        flux_bounds_filename = model_path + 'iJO1366_minimal_glucose_aerobic.py'
    elif media_type.lower() == 'minimal' and aeration.lower() == 'anaerobic':
        flux_bounds_dict = {'EX_glc(e)':[-glc_uptake_rate,1000]} 
        flux_bounds_filename = model_path + 'iJO1366_minimal_glucose_anaerobic.py'
    elif media_type.lower() == 'rich' and aeration.lower() == 'aerobic':
        flux_bounds_dict = {'EX_glc(e)':[-glc_uptake_rate,1000], 'EX_o2(e)':[-2*glc_uptake_rate,1000]} 
        flux_bounds_filename = model_path + 'iJO1366_rich_glucose_aerobic.py' 
    elif media_type.lower() == 'rich' and aeration.lower() == 'anaerobic':
        flux_bounds_dict = {'EX_glc(e)':[-glc_uptake_rate,1000]} 
        flux_bounds_filename = model_path + 'iJO1366_rich_glucose_anaerobic.py' 
    else:
        raise ValueError('Unknown media_type and/or aeraiton type: {}, {}'.format(media_type,aeration))

    model_organism = organism(id = 'Ecoli', name = 'Escherichia coli',domain = 'Bacteria', genus = 'Escherichia', species = 'coli', strain = 'MG1655')

    # Orignal iJo1266 model
    Ecoli_model = create_model(model_organism = model_organism, model_info = {'id':'iJO1366', 'input_file_type':'sbml', 'model_filename':model_path + 'iJO1366_updated.xml', 'biomassrxn_id':'Ec_biomass_iJO1366_core_53p95M'}, growthMedium_flux_bounds = {'flux_bounds_filename':flux_bounds_filename, 'flux_bounds_dict': flux_bounds_dict}, stdout_msgs = stdout_msgs, warnings = True)

    # Load the list of transport-like (pseudo-transport) reacitons and add "pseudo-transport" to their subsystem 
    load_source('dataFile', model_path + 'iJO1366_transport_like_rxns.py')
    import dataFile
    transport_like_rxns = dataFile.transport_like_rxns
    for r_id in transport_like_rxns:
        Ecoli_model.reactions_by_id[r_id].subsystem = Ecoli_model.reactions_by_id[r_id].subsystem + ' (pseudo-transport)' 

    # Add the nsAA biosynthesis pathways to the model
    if is_nsAA: 
        if target_product.lower() == 'pyrrolysine':
            add_pyrlys_pathway = True
            add_pAF_pathway = False
            product_exchrxn_id = 'EX_pyrlys_L(e)'
        elif is_nsAA and target_product.lower() == 'paf':
            add_pyrlys_pathway = False
            add_pAF_pathway = True
            product_exchrxn_id = 'EX_paphe(e)'
        else:
            raise ValueError('Invalid value for non-standard AA name')

        if stdout_msgs:
            print '\nproduct exchange reaction id = ',product_exchrxn_id

        Ecoli_nsAA_producing = add_nsAA_pathways(model = deepcopy(Ecoli_model), add_pyrlys_pathway = add_pyrlys_pathway, add_pAF_pathway = add_pAF_pathway, is_gro_pyrlys_auxo = False, is_gro_pAF_auxo = False, stdout_msgs = stdout_msgs, warnings = warnings) 
        Ecoli_model = deepcopy(Ecoli_nsAA_producing)
    else:
        target_product_id = [c.id for c in Ecoli_model.compounds if target_product in [c.id, c.name] + c.name_aliases]
        if len(target_product_id) == 1:
            target_product_id = target_product_id[0]
        elif len(target_product_id) > 1:
            raise userError('OptForce_sim: More than one compuond was found in the model for target product {}: {}'.format(target_product, target_product_id))
        elif len(target_product_id) == 0:
            raise userError('OptForce_sim: No compuond was found in the model for target product {}'.format(target_product))
        product_exchrxn_id = [r.id for r in Ecoli_model.compounds_by_id[target_product_id].reactions if r.is_exchange][0]

        if stdout_msgs:
            print '\nproduct exchange reaction id = ',product_exchrxn_id

    # Find the max biomass flux for Ecoli_model 
    if stdout_msgs and is_nsAA:
        print '\n--- FBA after adding new pathways ---'
    elif stdout_msgs and not is_nsAA:
        print '\n--- Find max biomass ---'

    set_specific_bounds(model = Ecoli_model, file_name = flux_bounds_filename, flux_bounds = flux_bounds_dict)

    Ecoli_model.fba(stdout_msgs = False)
    if Ecoli_model.fba_model.solution['exit_flag'] == 'globallyOptimal':
        Ecoli_model_max_biomass = Ecoli_model.fba_model.solution['objective_value']
        if stdout_msgs:
            print 'max biomass = {} , Product exch flux = {}'.format(Ecoli_model_max_biomass,Ecoli_model.fba_model.solution['opt_rxnFluxes'][product_exchrxn_id])
    else:
        raise userError('FBA to find max biomass flux for Ecoli_model was not solved to optimality: exit_flag = {}'.format(Ecoli_model.fba_model.solution['exit_flag'] ))

    # Find the max product exchange reaction flux 
    if stdout_msgs:
        print '\n--- FBA to find max product exchange reaction flux ---'
    for rxn in Ecoli_model.reactions:
        rxn.objective_coefficient = 0
    Ecoli_model.reactions_by_id[product_exchrxn_id].objective_coefficient = 1
    set_specific_bounds(model = Ecoli_model, file_name = flux_bounds_filename, flux_bounds = flux_bounds_dict)

    Ecoli_model.fba(stdout_msgs = False)
    if Ecoli_model.fba_model.solution['exit_flag'] == 'globallyOptimal':
        max_theor_product_flux =  Ecoli_model.fba_model.solution['objective_value']
        if stdout_msgs:
            print 'biomass = {} , max product exch flux = {}'.format(Ecoli_model.fba_model.solution['opt_rxnFluxes'][Ecoli_model.biomass_reaction.id],Ecoli_model.fba_model.solution['opt_rxnFluxes'][product_exchrxn_id])
    else:
        raise userError('FBA to find max product exchange reaction flux was not solved to optimality')

    return (Ecoli_model, product_exchrxn_id, flux_bounds_dict, flux_bounds_filename, Ecoli_model_max_biomass, max_theor_product_flux)

    Ecoli_model.reactions_by_id[product_exchrxn_id].objective_coefficient = 0


def find_coupled_rxns(nsAA = 'Pyrrolysine', aeration = 'aerobic', media_type = 'minimal', stdout_msgs = True, warnings = True): 
    """
    Finds the set of fully coupled reactions 
    """
    Ecoli_nsAA_producing, nsAA_exchrxn_id, flux_bounds_dict, flux_bounds_filename, Ecoli_nsAA_producing_max_biomass, max_theor_nsAA_flux = create_refStrain_model(nsAA = nsAA, aeration = aeration, media_type = media_type, stdout_msgs = stdout_msgs, warnings = warnings)

    # Load blocked rxns list 
    blocked_results_filename = 'results/iJO1366nsAA_blocked_rxns_' + aeration + '_' + media_type + '_' + re.sub('\(e\)|_e_|_e$','',targeet_product).lower() + '.py'
    load_source('dataFile',blocked_results_filename)
    import dataFile
    blocked_rxns = dataFile.blocked_rxns

    results_filename = 'results/iJO1366nsAA_coupled_sets_' + aeration + '_' + media_type + '_' + re.sub('\(e\)|_e_|_e$','',target_product).lower() + '.py'

    fcf_inst = fcf(model = Ecoli_nsAA_producing, blocked_rxns = blocked_rxns, results_filename = results_filename, warnings = True, stdout_msgs = True)
    fcf_inst.run()


def OptForce_sim(target_product = 'Pyrrolysine', is_nsAA = False, product_MW = None, aeration = 'aerobic', media_type = 'minimal', product_targetYield_percent = 80, min_biomass_percent = 20, find_inSilico_essential_rxns = False, find_inSilico_blocked_rxns = False, read_flux_bounds_ref_fromFile = False, read_flux_bounds_overprod_fromFile = False, read_MUST_singles_fromFile = False, read_MUST_doubles_fromFile = False, max_threads_num = 1, stdout_msgs = True, warnings = True):
    """
    Performs OptForce simulations for Ecoli strains producing pyrrolysine and pAF 

    INPUTS:
    -------
    target_product: 
    Name or id of the target product, If this non_standard amino acid, it should be 
    either pyrrolysine or pAF. Otherwise, it can be the name or id of a standard 
    metabolite (in case an id is provided it should be the id in the [e] compartment)

    is_nsAA:
    Represents if the target product is a non-standard amino acid (True) or not (False)

    product_MW:
    Molecular weight of the product (g/mol)

    media_type: 
    Type of growth mediam: M9 (minimal), LB (rich)

    aeration: 
    Type of aeration 'aerobic' or 'anaerobic'

    find_inSilico_essential_rxns and find_inSilico_blocked_rxns
    Represent if in silico essential and blocked reactions should be found (True) or not (False)

    product_targetYield_percent & min_biomass_percent:
    Product target yield and min required percentage of biomass

    max_threads_num:
    Max number of cores to use

    Ali R. Zomorrodi - Segre's Lab @ BU
    Last updated: 03-14-2018
    """
    if not isinstance(target_product,str):
        raise TypeError('target_product must be a string')
    elif is_nsAA and target_product.lower() not in ['pyrrolysine','paf']:
        raise ValueError('Invalid value for nsAA. Allowed choices are Pyrrolysine and pAF')

    if not isinstance(aeration,str):
        raise TypeError('aeration must a a string')
    elif aeration.lower() not in ['aerobic','anaerobic']:
        raise ValueError('Invalid aeration value: {}'.format(aeration))

    if not isinstance(media_type,str):
        raise TypeError('media_type must be a string')
    elif media_type.lower() not in ['minimal','rich']:
        raise ValueError('Invalid media_type value! Allowed choices are: [M9, LB]')


    for bool_var in [find_inSilico_essential_rxns, find_inSilico_blocked_rxns, read_flux_bounds_ref_fromFile, read_flux_bounds_overprod_fromFile, read_MUST_singles_fromFile, read_MUST_doubles_fromFile]:
        if not isinstance(bool_var, bool):
            bool_var_name = [k for k,v in locals().iteritems() if v is var][0]
            raise TypeError('{} must be True or False. Instead {} was provided'.format(bool_var_name, type(bool_var)))

    print '\n------------- {} , {} ---------------\n'.format(media_type, aeration)
    Ecoli_model, product_exchrxn_id, flux_bounds_dict, flux_bounds_filename, Ecoli_model_max_biomass, max_theor_product_flux = create_refStrain_model(target_product = target_product, is_nsAA = is_nsAA, aeration = aeration, media_type = media_type, stdout_msgs = stdout_msgs, warnings = warnings)
    
    # Set all objective function coefficients to zero
    for rxn in Ecoli_model.reactions:
        rxn.objective_coefficient = 0

    # Create an instance of OptForce
    results_filename_base = 'results/optforce_' + aeration + '_' + media_type + '_' + re.sub('\(e\)|_e_|_e$','',target_product).lower()

    # Data files 
    read_exp_flux_bounds_ref_fromThisFile = 'tools/strain_design/flux_data/Escherichia_coli/iJO1366_' + media_type + '_' + aeration + '_glc_PMID_23036703.py'
    read_inVivo_essential_rxns_fromThisFile = 'models/Escherichia_coli/iJO1366/iJO1366_inVivo_essential_rxns_aerobic_glucose_minimal.py'

    # Essential and blocked rxns
    if is_nsAA:
        blocked_rxns_filename = 'results/iJO1366nsAA_blocked_rxns_' + aeration + '_' + media_type + '_' + re.sub('\(e\)|_e$','',target_product).lower() + '.py'
        inSilico_essential_rxns_filename = 'results/iJO1366nsAA_essential_rxns_' + aeration + '_' + media_type + '_' + re.sub('\(e\)|_e$','',target_product).lower() + '.py'
    else:
        blocked_rxns_filename = 'results/iJO1366_blocked_rxns_' + aeration + '_' + media_type + '.py'
        inSilico_essential_rxns_filename = 'results/iJO1366_essential_rxns_' + aeration + '_' + media_type + '.py'

    if find_inSilico_essential_rxns:
        print '\n ----- Finding in silico essential reactions ----\n'
        essential_rxns = find_essential_rxns(model = Ecoli_model, viability_thr = 1, results_filename = inSilico_essential_rxns_filename,  stdout_msgs = True, warnings = True)
        print '\nIn silico essential reactions were written into {}\n'.format(inSilico_essential_rxns_filename)

    read_inSilico_essential_rxns_fromThisFile = inSilico_essential_rxns_filename 

    if find_inSilico_blocked_rxns:
        print '\n----- Finding blocked reactions ----\n'
        blocked_rxns = find_blocked_rxns(model = Ecoli_model, always_blocked_only = False, results_filename = blocked_rxns_filename, stdout_msgs = True)
        print '\nBlocked reactions were written into {}\n'.format(blocked_rxns_filename)

    read_blocked_rxns_fromThisFile = blocked_rxns_filename 

    MUST_singles_diff_thr = 1
    MUST_doubles_params = {'objective_thr':1, 'validate_results':True, 'stdout_msgs': False}

    OptForce_target_prod = OptForce(model = Ecoli_model, product_exchrxn_id = product_exchrxn_id, product_targetYield_percent = product_targetYield_percent, min_biomass_percent = min_biomass_percent, growthMedium_flux_bounds = {'flux_bounds_filename':flux_bounds_filename, 'flux_bounds_dict': flux_bounds_dict}, read_exp_flux_bounds_ref_fromThisFile = read_exp_flux_bounds_ref_fromThisFile, read_blocked_rxns_fromThisFile = read_blocked_rxns_fromThisFile, read_inSilico_essential_rxns_fromThisFile = read_inSilico_essential_rxns_fromThisFile, read_inVivo_essential_rxns_fromThisFile = read_inVivo_essential_rxns_fromThisFile, MUST_singles_diff_thr = MUST_singles_diff_thr, MUST_doubles_params = MUST_doubles_params, optimization_solver = 'gurobi', stdout_msgs = True)

    # Convert product_targetYield_percent and min_biomass_percent to strings to be used in output file names
    if product_targetYield_percent == int(product_targetYield_percent):
        product_targetYield_percent_str = str(int(product_targetYield_percent))
    else:
        product_targetYield_percent_str = re.sub('\.','_point_', str(product_targetYield_percent))

    if min_biomass_percent == int(min_biomass_percent):
        min_biomass_percent_str = str(int(min_biomass_percent))
    else:
        min_biomass_percent_str = re.sub('\.','_point_', str(min_biomass_percent))

    # string to be attached to the end of filename
    targetYield_minBiomass_str = product_targetYield_percent_str + '_' + min_biomass_percent_str

    # File to read/store flux bounds and MUST sets
    if target_product.lower() in ['paf','pyrrolysine']:
        # In this case we have one modified model for each product so targer_product name appears
        # in the filenmae
        flux_bounds_ref_filename = results_filename_base + '_flux_bounds_ref.py' 
    else:
        # In this case the same original metabolic model is used as the refe for all products
        flux_bounds_ref_filename = re.sub('_' + re.sub('\(e\)|_e_|_e$','',target_product).lower(),'',results_filename_base) + '_flux_bounds_ref.py' 

    if read_flux_bounds_ref_fromFile:
        OptForce_target_prod.read_flux_bounds_ref_fromThisFile = flux_bounds_ref_filename 
    else:
        OptForce_target_prod.save_flux_bounds_ref_toThisFile = flux_bounds_ref_filename 

    if read_flux_bounds_overprod_fromFile:
        OptForce_target_prod.read_flux_bounds_overprod_fromThisFile = results_filename_base + '_flux_bounds_overprod_' + targetYield_minBiomass_str +  '.py'
    else:
        OptForce_target_prod.save_flux_bounds_overprod_toThisFile = results_filename_base + '_flux_bounds_overprod_' + targetYield_minBiomass_str + '.py'

    if read_MUST_singles_fromFile:
        OptForce_target_prod.read_MUST_singles_fromThisFile = results_filename_base + '_MUST_singles_' + targetYield_minBiomass_str + '.py'
    else:
        OptForce_target_prod.save_MUST_singles_toThisFile = results_filename_base + '_MUST_singles_' + targetYield_minBiomass_str + '.py'

    if read_MUST_doubles_fromFile:
        OptForce_target_prod.read_MUST_doubles_fromThisFile = results_filename_base + '_MUST_doubles_' + targetYield_minBiomass_str + '.py'
    else:
        OptForce_target_prod.MUST_doubles_params['results_filename'] = results_filename_base + '_MUST_doubles_' + targetYield_minBiomass_str + '.py'

    if target_product.lower() == 'pyrrolysine':

        optimization_solver = 'gurobi'
        product_targetYield_percent_FORCE = 90
        doNot_modify_transport_rxns = True

        """ 
        Up-regulation of either DAPDC, DHDPS, DAPE, THDPS, DHDPRy, SDPDS or i
        down-regulation of SDPTA all have the same impact on the yield, and therefore, only one of them
        is imposed and the rest are avoided 
        PPKr, CBMKr and CYTK1 code for two reactions invovled in ATP synthesis with some 
        putative genes and are avoided
        """ 
        fixed_X_rxns = []
        fixed_L_rxns = []
        fixed_U_rxns = ['DAPDC']
        ignored_X_rxns = ['PPKr', 'CBMKr', 'CYTK1']
        ignored_L_rxns = ['SDPTA']
        ignored_U_rxns = ['PylB', 'PylC', 'PylD1', 'PylD2', 'DHDPS', 'DAPE',  'THDPS', 'DHDPRy', 'SDPDS']

    elif target_product.lower() == 'paf':

        optimization_solver = 'gurobi'
        product_targetYield_percent_FORCE = 90
        doNot_modify_transport_rxns = True

        """ 
        Down-regulation of CHORM always appears in all interventions
        Down-regulation of ANS, ANPRT, PRAIi and IGPS have the effect always appear and 
        have the same effect
        Up-regulation of CHORS, PSCVT, SHKK, SHK3Dr and DHQTi always appear and have 
        the same effect
        PapB, PapC, PAPHES and ADCS are reactions in the terminal pathway and their up-regulaiton
        will satisfy the desired target yield.  
        """ 
        
        fixed_X_rxns = []
        #fixed_L_rxns = ['CHORM', 'ANS']
        fixed_L_rxns = []
        fixed_U_rxns = ['CHORS']
        ignored_X_rxns = []
        ignored_L_rxns = ['ANPRT', 'PRAIi', 'IGPS']
        ignored_U_rxns = ['PapB', 'PapC', 'PAPHES', 'ADCS', 'PSCVT', 'SHKK', 'SHK3Dr', 'DHQTi']

    elif target_product == 'phe_L_e':

        optimization_solver = 'gurobi'
        product_targetYield_percent_FORCE = 90
        doNot_modify_transport_rxns = True

        """ 
        Round 1: Up-regulation of PPNDH and PHETA1 (up-regulation of PHETA1 appears as down-regulation
        according to reaction direction in the model)  give the desired yield but these are 
        are trivial up-regulation of reactions in the terminal pathway and are excluded

        Round 2: Up-regulaton of CHORM combined with down-regulation of TYRTA (appears as up-regulation 
        basedon the direction of reaction in the model) or PPND are trivial as well

        Round 3: We prevented up-regulation of CHORM and down-regulation of TYRTA and PPND
        but no interventions were found with up to four interventions (the code didn't finish running
        for five interventions. The reason probably is that if PPNDH and PHETA1 are not up-regulated
        eithr TYRTA or PPND have to be down-regulated  

        Round 4: We fixed down-regulation of PPND, didn't allow donw-regulation of TYRTA and up-regulation
        of CHORM to find interventions in other parts of the metabolism instead of CHORM up-regulation.
        Here, with three interventions, we achieve a yield of 10.73 mol/100 mol of cabon src (19.31% of max)
        These three interventions include (1) Down-regulation of PPND, (2) Down-regulation of ANS, or ANPRT
        or PRAIi or IGPS, (3) Up-regulation of DHQTi or SHK3Dr or SHKK or PSCVT or CHORS
        Then, we four interventions which includes addition of a knockout ICHORT, DHBD, DHBS or SERASr, the
        yield would increase to 27.65 mol/100 mol of carbon src (49.77% of max)

        Round 5: We ignored upregulation of DHQTi, SHK3Dr, SHKK, PSCVT and knockout of DHBD, DHBS and SERASr. 
        We fixed down-regulation of PPND and ANS, and up-regulation of CHORS.
        We didn't fix knockout of ICHORT to see if the code can find alternative interventions 
        """ 
        fixed_X_rxns = []
        fixed_L_rxns = ['PPND', 'ANS']
        fixed_U_rxns = ['CHORS']
        ignored_X_rxns = ['DHBD', 'DHBS', 'SERASr']
        ignored_L_rxns = ['PHETA1']
        ignored_U_rxns = ['PPNDH', 'TYRTA', 'CHORM', 'DHQTi', 'SHK3Dr', 'SHKK', 'PSCVT']

    elif target_product == 'trp_L_e':

        optimization_solver = 'gurobi'
        product_targetYield_percent_FORCE = 90
        doNot_modify_transport_rxns = False

        """ 
        Round 1: Up-regulation of TRPtex and TRPt2rpp (down-regulation based on the model)
        appear in the first round and are trivial solutions

        Round 2: Knock out of INDOLEtex, and up-regulation of ANS, ANPRT, PRAIi or IGPS lead to 
        22.05 mol/100 mol of carbon src = 0.25 g/g of carbon src (49.23% of theoretical max) 
        However, these reaction interventions are up-regulation of reactions in the terminal
        pathway of trp production and thus removed from consideration to find alternative
        reaction mechanisms in other parts of the metabolism

        Round 3: Knock out of INDOLEtex, ICHORT, up-regulation of DHQTi and down-regulation of 
        CHORM appear as interventions that lead to 22.04 mol/100 mol of carbon src = 0.25 g/g 
        of carbon src (49.21% of theoretical maximum. But the code is not able to find alaternative
        optimal solutions for # of interventions = 4. So, we fix, down-regulation of CHORM to see
        if the model can find anything

        Round 4: (1) Up-regulation of either DHQTi, SHK3Dr, SHKK, PSCVT or CHORS, (2) knockout of 
        either ICHORT, DHBD, DHBS or SERASr, (3) Down-regulatio of CHORM, knockout of INDOLEtex, 
        lead toa pAF production flux of 22.04  mol/100 mol of carbon src (49.21% of max
        Knocking out TYRtex and PHEtex increases the production flux to 22.37 mol/100 mol of carbon src
        (49.95% of max). 

        Round 5: We ignored upregulation of DHQTi, SHK3Dr, SHKK, PSCVT and 
        knockout of DHBD, DHBS and SERASr. We fixed down-regulation of CHORM and up-regulation of CHORS.
        We didn't fix knockout of ICHORT to see if the code can find alternative kockouts not including
        transport reactions such as INDOLEtex  
        """ 
        fixed_X_rxns = []
        fixed_L_rxns = ['CHORM']
        fixed_U_rxns = ['CHORS']
        ignored_X_rxns = ['DHBD', 'DHBS', 'SERASr']
        ignored_L_rxns = ['TRPt2rpp', 'TRPtex']
        ignored_U_rxns = ['ANS', 'ANPRT', 'PRAIi', 'IGPS', 'DHQTi', 'SHK3Dr', 'SHKK', 'PSCVT']

    else:
        raise userError('Invalid target product: {}'.format(target_product))

    OptForce_target_prod.FORCE_params = {'product_MW':product_MW, 'max_interven_num':10, 'notMUST_max_interven_num':8, 'notXrxns_interven_num':8, 'notLrxns_interven_num':8, 'notUrxns_interven_num':8, 'fixed_X_rxns':fixed_X_rxns, 'fixed_L_rxns':fixed_L_rxns, 'fixed_U_rxns':fixed_U_rxns, 'ignored_X_rxns':ignored_X_rxns, 'ignored_L_rxns':ignored_L_rxns, 'ignored_U_rxns':ignored_U_rxns, 'build_new_optModel':True, 'dual_formulation_type': 'standard', 'product_targetYield_percent': product_targetYield_percent, 'validate_results': True, 'doNot_modify_transport_rxns':doNot_modify_transport_rxns, 'max_threads_num': max_threads_num, 'results_filename':results_filename_base + '_FORCE_sets_' + targetYield_minBiomass_str + '.py', 'optimization_solver':optimization_solver}

    OptForce_target_prod.run()

def verify_intervens(target_product = 'Pyrrolysine', is_nsAA = True, aeration = 'aerobic', media_type = 'minimal'):
    """
    Verifid identified interventions 
    """
    # Model path
    model_path = 'models/Escherichia_coli/iJO1366/'

    model_organism = organism(id = 'Ecoli', name = 'Escherichia coli',domain = 'Bacteria', genus = 'Escherichia', species = 'coli', strain = 'MG1655')

    Ecoli_model, product_exchrxn_id, flux_bounds_dict, flux_bounds_filename, Ecoli_model_max_biomass, max_theor_product_flux = create_refStrain_model(target_product = target_product, is_nsAA = is_nsAA, aeration = aeration, media_type = media_type, stdout_msgs = True, warnings = True)

    # Set flux bound for min biomass requirement
    product_targetYield_percent = 20
    min_biomass_percent = 80
    
    # Read reference and overproducing flux bounds
    results_filename_base = 'results/optforce_' + aeration + '_' + media_type + '_' + re.sub('\(e\)|_e_|_e$','',target_product).lower()

    # Convert product_targetYield_percent and min_biomass_percent to strings to be used in output file names
    if product_targetYield_percent == int(product_targetYield_percent):
        product_targetYield_percent_str = str(int(product_targetYield_percent))
    else:
        product_targetYield_percent_str = re.sub('\.','_point_', str(product_targetYield_percent))

    if min_biomass_percent == int(min_biomass_percent):
        min_biomass_percent_str = str(int(min_biomass_percent))
    else:
        min_biomass_percent_str = re.sub('\.','_point_', str(min_biomass_percent))

    # string to be attached to the end of filename
    targetYield_minBiomass_str = product_targetYield_percent_str + '_' + min_biomass_percent_str

    read_flux_bounds_overprod_fromThisFile = results_filename_base + '_flux_bounds_overprod_' + targetYield_minBiomass_str +  '.py'

    load_source('dataFile',read_flux_bounds_overprod_fromThisFile)
    import dataFile
    flux_bounds_overprod = dataFile.fva_flux_bounds

    if target_product == 'Pyrrolysine':
        X_rxns = ['MDH'] 
        L_rxns = []
        U_rxns = ['DAPDC']
    elif target_product == 'pAF':
        X_rxns = ['ICHORT']
        L_rxns = ['CHORM','ANS']
        U_rxns = ['CHORS']
    elif target_product == 'trp_L_e':
        X_rxns = []
        L_rxns = []
        U_rxns = ['IGPS','TRPS1','TRPS2']
    else:
        raise userError('Invalid nsAA!')

    for j in X_rxns:
        Ecoli_model.reactions_by_id[j].flux_bounds = [0,0]
    for j in L_rxns:
        Ecoli_model.reactions_by_id[j].flux_bounds[1] = flux_bounds_overprod[j][1]
    for j in U_rxns:
        Ecoli_model.reactions_by_id[j].flux_bounds[0] = flux_bounds_overprod[j][0]

    # Maximize biomass flux (perform FBA)
    print '\n---- Product exchange reaction flux when maximizing biomass flux (performing FBA) ---'

    for rxn in Ecoli_model.reactions:
        rxn.objective_coefficient = 0
    Ecoli_model.biomass_reaction.objective_coefficient = 1

    Ecoli_model.fba(build_new_optModel = True, maximize = True, stdout_msgs = True)

    if Ecoli_model.fba_model.solution['exit_flag'] == 'globallyOptimal':
        product_exchrxn_flux = Ecoli_model.fba_model.optModel.v[product_exchrxn_id].value
        prdouct_max_theor_percent = 100*product_exchrxn_flux/max_theor_product_flux

        print 'Product flux when maximizing biomass = max biomass = {:.2f}, product exchange rxn flux = {:.2f} ({:.2f}% of theoretical max)\n'.format(Ecoli_model.fba_model.optModel.v[Ecoli_model.biomass_reaction.id].value, product_exchrxn_flux, prdouct_max_theor_percent)
    else:
        print '\n**Error! Verification problem was not solved to optimality'


    #-- Minimize production of flux of the metabolite while imposing a min biomass requirement --
    print '\n---- Minimize production of flux of the metabolite while imposing a min biomass requirement ---'
    set_specific_bounds(model = Ecoli_model, flux_bounds = {Ecoli_model.biomass_reaction.id:[(min_biomass_percent/100)*Ecoli_model_max_biomass,None]}, reset_flux_bounds = False)

    # Set all objective function coefficients to zero
    for rxn in Ecoli_model.reactions:
        rxn.objective_coefficient = 0
    Ecoli_model.reactions_by_id[product_exchrxn_id].objective_coefficient = 1

    Ecoli_model.fba(build_new_optModel = True, maximize = False, stdout_msgs = True)

    if Ecoli_model.fba_model.solution['exit_flag'] == 'globallyOptimal':
        maxmin_product_flux = Ecoli_model.fba_model.optModel.v[product_exchrxn_id].value
        prdouct_max_theor_percent = 100*maxmin_product_flux/max_theor_product_flux

        print 'maxmin product flux = {:.2f} ({:.2f}% of theoretical max)\n'.format(maxmin_product_flux, prdouct_max_theor_percent)
    else:
        print '\n**Error! Verification problem was not solved to optimality'

def get_flux_ranges(rxns_list = [], target_product = 'Pyrrolysine', is_nsAA = False, glc_uptake_rate = 100, aeration = 'aerobic', media_type = 'minimal', product_targetYield_percent = 80, min_biomass_percent = 20, stdout_msgs = True, warnings = True):
    """
    Identifies flux range of for a set of reactions consistent with a desired threshold on biomass and
    a metabolite production

    INPUTS:
    ------
    rxns_list:
    A list of rxn ids

    target_product: 
    Name or id of the target product, If this non_standard amino acid, it should be 
    either pyrrolysine or pAF. Otherwise, it can be the name or id of a standard 
    metabolite (in case an id is provided it should be the id in the [e] compartment)

    is_nsAA:
    Represents if the target product is a non-standard amino acid (True) or not (False)

    media_type: 
    Type of growth mediam: M9 (minimal), LB (rich)

    aeration: 
    Type of aeration 'aerobic' or 'anaerobic'

    OUTPUT:
    -------
    flux_ranges:
    A dictionary where keys are rxn names given in rxns_list and values are tuples containing
    flux ranges for each rxn 
    """
    model_path = 'models/Escherichia_coli/iJO1366/'

    model_organism = organism(id = 'Ecoli', name = 'Escherichia coli',domain = 'Bacteria', genus = 'Escherichia', species = 'coli', strain = 'MG1655')

    Ecoli_model, product_exchrxn_id, flux_bounds_dict, flux_bounds_filename, Ecoli_model_max_biomass, max_theor_product_flux = create_refStrain_model(target_product = target_product, is_nsAA = is_nsAA, glc_uptake_rate = glc_uptake_rate, aeration = aeration, media_type = media_type, stdout_msgs = stdout_msgs, warnings = True)

    Ecoli_model.biomass_reaction.objective_coefficient = 0 
    set_specific_bounds(model = Ecoli_model, flux_bounds = {Ecoli_model.biomass_reaction.id:[(min_biomass_percent/100)*Ecoli_model_max_biomass,None], product_exchrxn_id:[(product_targetYield_percent/100)*max_theor_product_flux, None]}, reset_flux_bounds = False)

    # A dictionary where keys are reaction ids and values are a list or tuple containing min and max of cluxes
    flux_ranges = dict([(j,[None, None]) for j in rxns_list])


    for rxn in rxns_list: 

        Ecoli_model.reactions_by_id[rxn].objective_coefficient = 1

        # Minimize        
        Ecoli_model.fba(build_new_optModel = True, maximize = False, stdout_msgs = False)
    
        if Ecoli_model.fba_model.solution['exit_flag'] == 'globallyOptimal':
            flux_ranges[rxn][0] = Ecoli_model.fba_model.optModel.v[rxn].value
        else:
            raise userError('\nReaction = {}, **Error! Optimizaiton problem to find min flux for overproducing strain was not solved to optimality, exist_flag = {}'.format(eng_strain, Ecoli_model.fba_model.solution['exit_flag']))

        # Maximize        
        Ecoli_model.fba(build_new_optModel = True, maximize = True, stdout_msgs = False)
        if Ecoli_model.fba_model.solution['exit_flag'] == 'globallyOptimal':
            flux_ranges[rxn][1] = Ecoli_model.fba_model.optModel.v[rxn].value
        else:
            raise userError('\nReaction = {}, **Error! Optimizaiton problem to find max flux for overproducing strain was not solved to optimality, exist_flag = {}'.format(eng_strain, Ecoli_model.fba_model.solution['exit_flag']))

        if stdout_msgs:
            print '\n--- Flux ranges ---'
            print '{}:\t [LB, UB] = {}'.format(rxn, flux_ranges[rxn])
    
        Ecoli_model.reactions_by_id[rxn].objective_coefficient = 0

    return flux_ranges
 
def print_must_subsystems():
    """
    Prints how many reaction participates in the subsystem for each type of manipualtion
    """
    # Model path
    model_path = 'models/Escherichia_coli/iJO1366/'

    model_organism = organism(id = 'Ecoli', name = 'Escherichia coli',domain = 'Bacteria', genus = 'Escherichia', species = 'coli', strain = 'MG1655')

    # Orignal iJo1266 model
    model = create_model(model_organism = model_organism, model_info = {'id':'iJO1366', 'input_file_type':'sbml','model_filename':model_path + 'iJO1366_updated.xml', 'biomassrxn_id':'Ec_biomass_iJO1366_core_53p95M'}, perform_fba = False, stdout_msgs = True, warnings = True)

    Ecoli_pyr_producing = add_nsAA_pathways(model = deepcopy(model), add_pyrlys = True, add_pAF = False)
    Ecoli_paf_producing = add_nsAA_pathways(model = deepcopy(model), add_pyrlys = False, add_pAF = True)

    must_sets = {}
    must_sets['X_pyr'] = ['ICL', 'MALS', 'COBALT2tex', 'S2FE2ST']
    must_sets['L_pyr'] = ['PTAr']
    must_sets['U_pyr'] = ['PylB', 'PylC', 'PylD1', 'PylD2', 'PyrLYStex', 'ASPK', 'DAPDC', 'SDPTA', 'DHDPS', 'GLUSy', 'GLUDy', 'SDPDS', 'PPC', 'THDPS', 'DHDPRy', 'DAPE', 'ASAD', 'ASPTA', 'ACKr', 'ACtex', 'CO2tex', 'CO2tpp', 'NH4tex', 'NH4tpp']
    must_sets['all_pyr'] = list(set(must_sets['X_pyr'] + must_sets['L_pyr'] + must_sets['U_pyr']))

    must_sets['X_paf'] = ['ICL', 'MALS', 'COBALT2tex', 'S2FE2ST']
    must_sets['L_paf'] = ['ENO','GAPD', 'PGI', 'TPI', 'ACONTa', 'ACONTb', 'ICDHyr', 'AKGDH', 'PTAr']
    must_sets['U_paf'] = ['PapB', 'PapC', 'PAPHEtex', 'PAPHEt2rpp', 'ADCS', 'CHORS', 'DDPA', 'DHQS', 'DHQTi', 'DRPA', 'RPI', 'RPE', 'GLUDy', 'GND', 'PGK', 'PGM', 'PPM2', 'PSCVT', 'SHKK', 'SHK3Dr', 'TKT1', 'TKT2', 'ACKr', 'ACtex', 'CO2tex', 'CO2tpp', 'NH4tex', 'NH4tpp']
    must_sets['all_paf'] = list(set(must_sets['X_paf'] + must_sets['L_paf'] + must_sets['U_paf']))

    for must_set in ['X_paf', 'L_paf', 'U_paf', 'all_paf', 'X_pyr', 'L_pyr', 'U_pyr', 'all_pyr']: 
        print '\n----- {} --------'.format(must_set)
        subsys_dict = {}
        for r in must_sets[must_set]:
            if 'pyr' in must_set.lower():
                subsys = Ecoli_pyr_producing.reactions_by_id[r].subsystem
            elif 'paf' in must_set.lower():
                subsys = Ecoli_paf_producing.reactions_by_id[r].subsystem
            else:
                raise ValueError('Unknown must)set: {}'.format(must_set))

            if subsys != '':
                if subsys in subsys_dict.keys():
                    subsys_dict[subsys].append(r) 
                else:
                    subsys_dict[subsys] = [r]    
        for k in sorted(subsys_dict.keys(), key = lambda x: len(subsys_dict[x]), reverse = False):
            print '{}\t{}'.format(k,len(subsys_dict[k]))
  
#------------------------------------
if __name__ == '__main__':
    OptForce_sim(nsAA = 'pAF', aeration = 'aerobic', media_type = 'minimal', stdout_msgs = True, warnings = True)
    #verify_intervens(target_product = 'pAF', aeration = 'aerobic', media_type = 'minimal')



