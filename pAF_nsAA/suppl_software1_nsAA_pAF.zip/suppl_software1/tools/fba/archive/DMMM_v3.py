from __future__ import division
import sys, time
sys.path.append('../../')
from tools.userError import *
from tools.core.metabolite import metabolite
from tools.core.reaction import reaction
from tools.core.organism import organism
from tools.core.model import model
from fba import fba
from death_rate import death_rate

class DMMM(object):
    """
    Performs dynamic multi-species metabolic modeling (DMMM) (PMID: 20668487) 

    Ali R. Zomorrodi - Daniel Segre Lab @ Boston University
    Last updated: 02-14-2015
    """   

    def __init__(self,community_members,shared_metabolites,reactor_type = 'batch',time_range = [0,1,10],store_dynamic_fluxes = False, screen_output = 'on'):

        """
        INPUTS:
        ------
          community_members: A list of objects of type model for each community member.
                             The object organism of the moell must have the following 
                             properties specified:
                             gDW_per_mL: Initial cell cencentration in gDW/mL in the form 
                                         of a dictionary where the key is the initial time
                                         point and the value is the initial cell concentraiton
                             The following optional properties can also be provided:
                             cells_per_mL: Initial cell cencentration in cells/mL in the form 
                                         of a dictionary where the key is the initial time
                                         point and the value is the initial cell concentraiton
                             gDW_per_cell: Gram of dry weight for one cell 
         shared_metabolites: A list of objects of type metabolite containing the information
                             about shared metabolites. The assigned compartment for these
                             metabolites is 'shared', Each shared metabolite object must have the
                             following properties specified: 
                             reactant_reactions: Exchange reactions of community members taking
                             up this metabolite 
                             product_reactions: Echange reactions of community members producing 
                             this metabolite
                             reactions: reactant_reactions + product_reactions
                             cocentration: Initial concentration in the form of a dictionary
                                           where the key is the initial time point and value
                                           is initial concentration in mM. Example: {0:0.1} 
               reactor_type: Type of reactor for simulations (batch or chemostat)
                 time_range: Range of the simulation time. This is a list with 
                             either two or three elements.
                             Two-element format: [startTime,endTime]
                             Three-element format: [startTime,timeStep,endTime]. If the 
                             time step is not given a time step of one is used
        store_dynamic_fluxes: Assign the dynamic changes in fluxes to the 'flux' field 
                             of the objects of type 'reaction' (default = False)
                screenOuput: Prints a summary of the FBA in the output. Set it to 'off'
                             to turn it off.

        NOTE:
        -----
        Reaction fluxes and cell concentrations (organism.cells_per_mL) in the model as well as
        shared metabolite concentraitons (shared_metab.concentration) should have already been
        stored in the form a dictionary. Keys of this dictionary are time points and 
        values are reactoin fluxes or concentraitons. This dictionary can be empty for
        fluxes at the begining but it must have one member for the other two 
        indicating the initial concentration of the shared metabolites and initial cell 
        concentrations. For example, organsim.concentration = {0:10^5} or
        shared_metab.concentraiton = [0:0.5]
        """

        self.community_members = community_members
        self.shared_metabolites = shared_metabolites

        if reactor_type not in ['batch','chemostat']:
            raise userError('**ERROR! reactor_type must be batch or chemostat.')
        else:
            self.reactor_type = reactor_type

        if store_dynamic_fluxes not in [True,False]:
            raise userError('**ERROR! store_dynamic_fluxes must be either True or False\n')
        else:
            self.store_dynamic_fluxes = store_dynamic_fluxes

        if screen_output not in ['on','off']:
            raise userError('**ERROR! screen_output must be either on or off.\n')
        else:
            self.screen_output = screen_output


        if len(time_range) == 3:
            # Initial time
            self._t0 = time_range[0]

            # Original dt. This mught be adjusted during the simulations
            self._dt = time_range[1]

            # Final simulation time
            self._tf = time_range[2]   
        elif len(time_range) == 2:
            # Initial time
            self._t0 = time_range[0]

            # Original dt. This mught be adjusted during the simulations
            self._dt = 1

            # Final simulation time
            self._tf = time_range[1]   # Final simulation time
        else:
            userError("**ERROR! Invalid time_range (allowable size of the vectors are two or three)") 

        #-- Check if an initial concentration for the shared metabolites and cells --
        # have been provided. If the initial concentrations are provided but they 
        # are in the form of a single value, instead of a dictionary, they are assigned
        # to the first time point as a dictionary. 

        # The initial concentration can be given for a cell can be given in gDW/mL
        # or in cells_per_ML
        no_conc_members = []
        for member in self.community_members:
            if member.organism.cells_per_mL is None and member.organism.gDW_per_ML is None:
                no_conc_members.append(member)

            elif member.organism.cells_per_mL is not None and member.organism.gDW_per_mL is None:
                if type(member.organism.cells_per_mL) is not dict:
                    member.organism.cells_per_mL = {self._t0:member.organism.cells_per_mL}

                member.organism.gDW_per_mL = {self._t0:member.organism.cells_per_mL*member.organism.gDW_per_cell}

            elif member.organism.cells_per_mL is None and member.organism.gDW_per_mL is not None:
                if type(member.organism.gDW_per_mL) is not dict:
                    member.organism.gDW_per_mL = {self._t0:member.organism.gDW_per_mL}
                # If initial concentration is given in terms of gDW_per_mL, then there is no need
                # for DMMM to have gDW_per_cell
                if member.organism.gDW_per_cell is not None:
                    member.organism.cells_per_mL = {self._t0:member.organism.gDW_per_mL[self._t0]/member.organism.gDW_per_cell}

            elif member.organism.cells_per_mL is not None and member.organism.gDW_per_mL is not None:
                if type(member.organism.cells_per_mL) is not dict:
                    member.organism.cells_per_mL = {self._t0:member.organism.cells_per_mL}
                if type(member.organism.gDW_per_mL) is not dict:
                    member.organism.gDW_per_mL = {self._t0:member.organism.gDW_per_mL}

        if len(no_conc_members) > 0:
            print '**ERROR! Initial biomass concnetration was not provided for the following community members:'
            for member in no_conc_members:
                print member.id
            raise userError()

        # Check initial concentration for shared metabolites
        non_conc_metab = []
        for shared_metab in self.shared_metabolites:
            if shared_metab.concentration is None:
                non_conc_metab.append(shared_meetab)
            # If the initial concentration has been provided but not in the form of
            # a dicitonary, convert it into a dicitonary and assigne it to the initial
            # time point specified by time_range[0]
            elif type(shared_metab.concentration) is not dict:
                shared_metab.concentration = {self._t0:shared_metab.concentration}


        # Initialize mu for each community members
        for member in self.community_members:
            if member.organism.mu == None:
                member.organism.mu = {} 

    def uptake_rate_UB_calc(self):
        """ 
        Compute the upper bound on the uptake rates of the shared metabolites 
        (LB on exchange fluxes) using kinetic expressions 
        """ 
        for shared_metab in self.shared_metabolites:
            for uptake_reaction in shared_metab.reactant_reactions:         
                # Assume uptake reactions are exchange reactions with only one
                # reactant 
                uptake_reaction.reactants[0].concentration = shared_metab.concentration[self._t] 
                uptake_reaction.kinetic_rate_calc(assignLB = True) 

    def update_fba_model(self):
        """ 
        This is an abstract method that can be defined by subclasses. This is useful
        for cases one needs to solve a different fba model (i.e., different objective
        function or different constriants) at each time point
        """ 
        pass 

    def mu_uptake_export_calc(self):
        """ 
        Compute the specific growth rate of community members and the uptake
        and export rates of shared metabolites 
        """ 
        for member in self.community_members:
            if self.store_dynamic_fluxes == False:
                member.fba(create_model = False, store_opt_fluxes = False, screen_output = 'off')
            else:
                member.fba(create_model = False, store_opt_fluxes = True, flux_key = self._t, screen_output = 'off')

            # Use the following general names to be used for other methods
            member.optimization_model = member.fba_model
            member.pyomo_model = member.fba_model.pyomo_fbaModel

            if member.fba_model.solution['exit_flag'] == 'globallyOptimal':
                if self.store_dynamic_fluxes == False:
                    member.organism.mu[self._t] = member.fba_model.pyomo_fbaModel.v[member.biomass_reaction].value 
                else:
                    member.organism.mu[self._t] = member.biomass_reaction.flux[self._t]
            else:
                if self.screen_output.lower() == 'on':
                    print '   Death rate ...'
                # Find the limiting nutrients that this member takes up 
                limiting_nutrients = [uptake_rxn.reactants[0] for shared_metab in self.shared_metabolites for uptake_rxn in shared_metab.reactant_reactions if uptake_rxn in member.reactions]
                mu_death = death_rate(member,limiting_nutrients,screen_output = 'off') 
                if mu_death is not None:
                    member.organism.mu[self._t] = mu_death
                else:
                    print '\n**WARNING! mu_death could not be computed successfully. 1% of max biomass flux for the wild-type under the same condition was assigned as the death rate'
                    member.organism.mu[self._t] = -0.01*member.wildType_max_biomass

                # Set the flux of all reactions (including export reactions for shared metabolites)
                # to zero
                for r in member.reactions:
                    r.flux[self._t] = 0

    def update_concentrations_batch(self):
        """ 
        Updates cell concentrationns the concnetration of extracellular metabolites
        for a batch reactor 
        """ 

        #--- Update the cell concentrations ---
        # dX/dt = mu*X or (X(t+dt) - X(t))/dt = mu*X(t) 
        # If concentration is negative set it to zero
        for member in self.community_members:
            # We always need gDW_per_mL to update metabolite concentrations but
            # providing cells_per_mL is optional
            member.organism.gDW_per_mL[self._t + self._dt] = max(member.organism.mu[self._t]*member.organism.gDW_per_mL[self._t]*self._dt + member.organism.gDW_per_mL[self._t],0)

            if member.organism.cells_per_mL is not None:
                member.organism.cells_per_mL[self._t + self._dt] = max(member.organism.mu[self._t]*member.organism.cells_per_mL[self._t]*self._dt + member.organism.cells_per_mL[self._t],0)

        #--- Update shared metabolite concentrations ---
        # dC/dt = f where, f = sum(k,v_export_k*X_k) - sum(k,v_uptake_k*X_k)
        # (C(t+dt) - c(t))/dt = sum(k,v_export_k*X_k) - sum(k,v_uptake_k*X_k)

        # A dictionary with keys and values as follows:
        #   Keys: The time interval needed for the concentration of metabolites 
        #         to become zero
        # Values: metabolites that get a negative concentration upon update
        dt_zero_conc = {}

        for shared_metab in self.shared_metabolites:
            if self.store_dynamic_fluxes is False:
                f = sum([r.model.pyomo_model.v[r].value*r.model.organism.gDW_per_mL[self._t] for r in shared_metab.reactions])
            else:
                f = sum([r.flux[self._t]*r.model.organism.gDW_per_mL[self._t] for r in shared_metab.reactions])

            conc = f*self._dt + shared_metab.concentration[self._t]

            if conc >= 0 or (conc < 0 and abs(conc) <= 1e-9):
                shared_metab.concentration[self._t + self._dt] = max(conc,0)

            #if conc < 0 and abs(conc) > 1e-9 and f > 0
            # Note that the adjusted time interval is obtained by dt = -C(t)/f i
            # or (2e-9 - C(t))/f because if abs(conc) <= 1e-9 it is assumed to be zero
            elif conc < 0 and abs(conc) > 1e-9:

                shared_metab.concentration[self._t + self._dt] = None 

                # find the time interval needed to get a zero concentration
                # or a concentration where abs(conc) <= 1e-9.
                # C(t + dt) = f*dt + C(t) = 1e-9  ==> dt = (1e-9 - -C(t))/f
                dt_zero_conc_curr = (1e-9 - shared_metab.concentration[self._t])/f

                # The following says keep only up to 10 decimals for dt
                # dt_zero_conc_curr = float("{0:.10f}".format(dt_zero_conc_curr))

                if dt_zero_conc_curr < 0:
                    raise userError('\n**ERROR! negative dt for metabolite ' + shared_metab.id + '  (dt = ' + str(dt_zero_conc_curr) + '  conc(t) = ' + str(shared_metab.concentration[self._t]) + '  f = ' + str(f) + '\n')
                elif dt_zero_conc_curr > self._dt:
                    raise userError('**ERROR! The obtained modified dt for the shared metabolite ' + shared_metab.id + ' (dt = ' + str(dt_zero_conc_curr) + ') is smaller than the original time interval (dt = ' + str(self._dt) + ')')
                else:
                    dt_zero_conc[dt_zero_conc_curr] = shared_metab

            else:
                raise userError('**ERROR! Uknonwon case for metabolite ' + shared_metab.id + '   (conc = ' + str(conc) + ')')


        # Update time if there is no negative concentrations
        if len(dt_zero_conc) == 0:      
            self._t += self._dt
            if self.screen_output.lower() == 'on':
                print 't = ',self._t

        # Otherwise divide the original time interval into smaller ones, if any of the
        # metabolite concentrations turns out to be negative. For example, the original
        # dt could be one, and dt's stored in dt_zero_conc can be 0.3 and 0.7. Then
        # we should do one simulation with a dt of 0.3, a second simulation with dt of
        # 0.7 - 0.3 = 0.4 and a last simulation with dt of 1 - 0.7 = 0.3
        else:
            if self.screen_output.lower() == 'on':
                print '    Redoing simulations by dividng the original time interval into smaller ones to avoid getting a negative concentration ...'

            # First remove all previously computed values for self._t + self._dt
            for member in self.community_members:
                del member.organism.cells_per_mL[self._t + self._dt] 

            for shared_metab in self.shared_metabolites:
                 del shared_metab.concentration[self._t + self._dt] 

            # Add zero and the original dt to the list and sort it
            #**all_dts = sorted(dt_zero_conc.keys() + [0,self._dt])
            dt_zero_conc[0] = None
            dt_zero_conc[self._dt] = None
 
            # Find out smaller dt's required for simulations (a fraction of the original dt)
            dt_zero_conc_sorted = sorted(dt_zero_conc.keys())
            dt_fracs = [dt_zero_conc_sorted[i] - dt_zero_conc_sorted[i-1] for i in range(1,len(dt_zero_conc))]
            dt_fracs_dict = dict([(dt_zero_conc_sorted[i] - dt_zero_conc_sorted[i-1],dt_zero_conc[dt_zero_conc_sorted[i]]) for i in range(1,len(dt_zero_conc))]) 

            print '\n   dt_fracs = ',dt_fracs,'\n'

            for dt_frac in dt_fracs:
                #-- Re-updated cell concentrations --
                for member in self.community_members:
                    # (X(t+dt) - X(t))/dt = mu*X(t)
                    # If concentration is negative set it to zero
                    member.organism.gDW_per_mL[self._t + dt_frac] = max(member.organism.mu[self._t]*member.organism.gDW_per_mL[self._t]*self._dt + member.organism.gDW_per_mL[self._t],0)
                    # Providing cells_per_mL by the user is optional
                    if member.organism.cells_per_mL is not None:
                        member.organism.cells_per_mL[self._t + dt_frac] = max(member.organism.mu[self._t]*member.organism.cells_per_mL[self._t]*self._dt + member.organism.cells_per_mL[self._t],0)
          
                #-- Re-updated metabolite concentrations --
                # Set the concentration for metabolite corresponding to this dt_frac to zero
                if dt_fracs_dict[dt_frac] != None:
                    dt_fracs_dict[dt_frac].concentration[self._t + dt_frac] = 0

                for shared_metab in [m for m in self.shared_metabolites if m != dt_fracs_dict[dt_frac]]:
                    # (C(t+dt) - c(t))/dt = f = sum(k,v_export_k*X_k) - sum(k,v_uptake_k*X_k)
                    if self.store_dynamic_fluxes is False:
                        f = sum([r.model.pyomo_model.v[r]*r.model.organism.gDW_per_mL[self._t] for r in shared_metab.reactions])
                    else:
                        f = sum([r.flux[self._t]*r.model.organism.gDW_per_mL[self._t] for r in shared_metab.reactions])
                    conc = f*dt_frac + shared_metab.concentration[self._t]

                    if conc < 0 and abs(conc) > 1e09:
                        print 'WARNING! Negative concentration for the shared metabolite ',shared_metab.id,' after divding the original time interval into smaller ones. This concentration was set to zero.'

                    else:
                        shared_metab.concentration[self._t + dt_frac] = max(conc,0)

                # Update time 
                self._t += dt_frac
                if self.screen_output.lower() == 'on':
                    print '\n    t = ',self._t

    def update_concentrations_chemostat(self):
        """ 
        Updates cell concentrationns the concnetration of extracellular metabolites
        for a chemostat. **To be completed 
        """ 
        pass

    def run(self):
        """ 
        This function runs the dynamic simulaitons. 
        """

        if self.screen_output == 'on':
            print 'Start running DMMM ...'

        start_DMMM = time.clock()

        self._t = self._t0

        # Compute the upper bound on the uptake rates of 
        # the shared metabolites using kinetic expressions for the self._t0
        self.uptake_rate_UB_calc()

        # Update the fba model for the initial point
        self.update_fba_model()

        # Compute the specific growth rate (mu) for each species using FBA 
        # as well as the export rates for self._t0
        self.mu_uptake_export_calc()

        while self._t + self._dt <= self._tf:

            # Time is udpated inside method update_concentrations 
            # Update concentrations in the next time point 
            if self.reactor_type.lower() == 'batch':
                self.update_concentrations_batch()
            elif self.reactor_type.lower() == 'chemostat':
                self.update_concentrations_chemostat()

            # Compute the upper bound on the uptake rates of 
            # the shared metabolites using kinetic expressions
            self.uptake_rate_UB_calc()

            # Update the fba model for the initial point
            self.update_fba_model()

            # Compute the specific growth rate (mu) for each species using FBA 
            # as well as the export rates 
            self.mu_uptake_export_calc()

        # Elapsed time to run DMMM
        elapsed_DMMM = time.clock() - start_DMMM

        if self.screen_output.lower() == 'on':
           print '\nelapsed time (sec) for DMMM = ',elapsed_DMMM,'\n'

#---------- Test DMMM ---------------
if __name__ == "__main__":
    from copy import deepcopy
    from tools.io.read_gams_model import read_gams_model
    from set_specific_bounds import set_specific_bounds

    # Increse the recursion limit, otherwise deepcopy will complain
    sys.setrecursionlimit(10000)
    
    #--- E. coli iAF1260 model ---
    print '\n--- Wild-type E.coli (iAF1260 model) ----'
    iAF1260 = read_gams_model(gams_model_file = '/fs/home06/alizom//models/Ecoli/iAF1260/iAF1260ModelData.py',model_name = 'iAF1260',organism_name = 'E. coli',model_type = 'metabolic')
    iAF1260.biomass_reaction = iAF1260.get_reactions({'Ec_biomass_iAF1260_core_59p81M':'id'}) 
    iAF1260.all_biomass_reactions = {'core':iAF1260.get_reactions({'Ec_biomass_iAF1260_core_59p81M':'id'}),'WT':iAF1260.get_reactions({'Ec_biomass_iAF1260_WT_59p81M':'id'})} 
    iAF1260.organism.gDW_per_cell = 2.8e-13
 
    # Assign a general Michaelis-Menten type uptake kinetics to all exchange reactions
    # Example: EX_glc(E): glc-D[e] <==>    Vmax*C['glc-D[e]']/(Km + C['glc-D[e]']) 
    # Use a Vmax value of 10 mmole/gDW.h and a Km value of 10 micro-M 
    for reaction in [r for r in iAF1260.reactions if r.type.lower() == 'exchange']:
        # The id of metabolite participating in the exchange reaction
        metab_id = [m.id for m in reaction.metabolites][0]
        reaction.kinetics = "10*C['" + metab_id + "']/(10 + C['" + metab_id + "'])"

    # Glucose uptake kinetics 
    exch_rxns = iAF1260.get_reactions({'EX_glc(e)':'id','EX_lys-L(e)':'id','EX_ile-L(e)':'id'})
    exch_rxns['EX_glc(e)'].kinetics = "10*C['glc-D[e]']/(0.15 + C['glc-D[e]'])"
    exch_rxns['EX_lys-L(e)'].kinetics = "0.1964*C['lys-L[e]']/(5e-4 + C['lys-L[e]']) + 0.3055*C['lys-L[e]']/(1e-2 + C['lys-L[e]'])"
    exch_rxns['EX_ile-L(e)'].kinetics = "0.0346*C['ile-L[e]']/(1.22e-3 + C['ile-L[e]'])"
   
    # Growth medium
    set_specific_bounds(iAF1260,specific_bounds_file = '/fs/home06/alizom/models/Ecoli/iAF1260/iAF1260_minimal_glucose_anaerobic.py',simulation_condition = 'minimal_glucose_anaerobic')

    # Assign and objective function coefficients
    for rxn in iAF1260.reactions:
        rxn.objective_coefficient = 0
    iAF1260.biomass_reaction.objective_coefficient = 1

    # Perform FBA for the wild-type
    iAF1260.fba(assign_wildType_max_biomass = True)

    # Compute ms and biomass yield for glucose
    glc_D = iAF1260.get_metabolites({'glc-D[e]':'id'})
    glc_D.ms_calc() 
    glc_D.biomass_yield_calc() 
    print '\n  **glc-D ms = ',glc_D.ms
    print '  **glc-D biomass yield = ',glc_D.biomass_yield,'\n'
    # Check if the bounds and objective function were set back to original values
    # after calculating ms and biomass yield
    iAF1260.fba()

    #--- DMMM for the co-culture of lysA and ilvE mutants ---
    print '\n--- lysA mutant ----'
    # lysA mutant and related reaction whose flux should be set to zero 
    iAF1260_lysA = deepcopy(iAF1260)
    iAF1260_lysA.organism.id = 'lysA_Ecoli'
    iAF1260_lysA.organism.cells_per_mL = {0:7.5e6}
    iAF1260_lysA.organism.gDW_per_mL = {0:7.5e6*iAF1260_lysA.organism.gDW_per_cell}
    DAPDC = iAF1260_lysA.get_reactions({'DAPDC':'id'})
    DAPDC.flux_bounds = [0,0]
    iAF1260_lysA.fba(create_model = False)
    # Compute ms and biomass yield for lys-L
    lys_L = iAF1260_lysA.get_metabolites({'lys-L[e]':'id'})
    lys_L.ms_calc()    
    lys_L.biomass_yield_calc()    
    print '\n  **lys-L ms = ',lys_L.ms
    print '  **lys-L biomass yield = ',lys_L.biomass_yield,'\n'
    # Check if the bounds and objective function were set back to original values
    # after calculating ms and biomass yield
    iAF1260_lysA.fba()

    print '\n**Test cooperative behavior ....'
    for rxn in iAF1260_lysA.reactions:
        rxn.objective_coefficient = 0
    iAF1260_lysA.get_reactions({'EX_ile-L(e)':'id'}).objective_coefficient = 1
    iAF1260_lysA.fba(create_model = False)
    iAF1260_lysA.biomass_reaction.objective_coefficient = 1

    # ilvE mutant and related reaction whose flux should be set to zero 
    print '\n--- ilvE mutant ----'
    iAF1260_ilvE = deepcopy(iAF1260)
    iAF1260_ilvE.organism.id = 'ilvE_Ecoli'
    iAF1260_ilvE.organism.cells_per_mL = {0:7.5e6}
    iAF1260_ilvE.organism.gDW_per_mL = {0:7.5e6*iAF1260_ilvE.organism.gDW_per_cell}
    ILETA = iAF1260_ilvE.get_reactions({'ILETA':'id'})
    VALTA = iAF1260_ilvE.get_reactions({'VALTA':'id'})
    ILETA.flux_bounds = [0,0]
    VALTA.flux_bounds = [0,0]
    iAF1260_ilvE.fba(create_model = False)
    # Compute ms and biomass yield for ile-L
    ile_L = iAF1260_ilvE.get_metabolites({'ile-L[e]':'id'})
    ile_L.ms_calc()    
    ile_L.biomass_yield_calc()    
    print '\n  **ile-L ms = ',ile_L.ms
    print '  **ile-L biomass yield = ',ile_L.biomass_yield,'\n'
    # Check if the bounds and objective function were set back to original values
    # after calculating ms and biomass yield
    iAF1260_ilvE.fba()

    print '\n**Test cooperative behavior ....'
    for rxn in iAF1260_ilvE.reactions:
        rxn.objective_coefficient = 0
    iAF1260_ilvE.get_reactions({'EX_lys-L(e)':'id'}).objective_coefficient = 1
    iAF1260_ilvE.fba(create_model = False)
    iAF1260_ilvE.get_reactions({'EX_lys-L(e)':'id'}).objective_coefficient = 0
    iAF1260_ilvE.biomass_reaction.objective_coefficient = 1

    # --- Define the metabolites available in the extracellular medium ---
    # These metabolites include glucose, arg-L and ile-L
    # Glucose
    exch_rxns_lysA = iAF1260_lysA.get_reactions({'EX_glc(e)':'id','EX_lys-L(e)':'id','EX_ile-L(e)':'id'}) 
    exch_rxns_ilvE = iAF1260_ilvE.get_reactions({'EX_glc(e)':'id','EX_lys-L(e)':'id','EX_ile-L(e)':'id'}) 

    # Glucose as a shared metabolite (concentration in mM)
    glucose = metabolite(id = 'glc-D', name = 'D-Glucose', Kegg_id = 'C00031', reactant_reactions = [exch_rxns_lysA['EX_glc(e)'],exch_rxns_ilvE['EX_glc(e)']],reactions = [exch_rxns_lysA['EX_glc(e)'],exch_rxns_ilvE['EX_glc(e)']],concentration = {0:111.01})    

    # Lysine as a shared metabolite (concentration in mM)
    lys_L = metabolite (id = 'lys-L',name = 'L-Lysine', Kegg_id = 'C00047', reactant_reactions = [exch_rxns_lysA['EX_lys-L(e)']],product_reactions = [exch_rxns_ilvE['EX_lys-L(e)']], concentration = {0:1e-5}) 
   
    # Isoleucine as a shared metabolite (concentration in mM)
    ile_L = metabolite(id = 'ile-L', name = 'L-Isoleucine' , Kegg_id = 'C00407', reactant_reactions = [exch_rxns_ilvE['EX_ile-L(e)']], product_reactions = [exch_rxns_lysA['EX_ile-L(e)']], concentration = {0:1e-5})

    DMMM_test = DMMM(community_members = [iAF1260_lysA,iAF1260_ilvE],shared_metabolites = [glucose,lys_L,ile_L],time_range = [0,0.5,10],screen_output = 'off')
    DMMM_test.run()
   
    # Print results in the output
    for t in sorted(glucose.concentration.keys()):
        print 't = ',t,
        for member in [iAF1260_lysA,iAF1260_ilvE]:
            print '  X(',member.organism.id,') = ',member.organism.cells_per_mL[t],

        for shared_metab in [glucose,lys_L,ile_L]:
            print '   C(',shared_metab.id,') = ',shared_metab.concentration[t],

        print '\n'

