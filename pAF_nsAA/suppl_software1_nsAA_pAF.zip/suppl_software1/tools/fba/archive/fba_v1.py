from __future__ import division
import re, sys, math, copy, time, random
sys.path.append('../../')
from coopr.pyomo import *
from coopr.opt import *
from tools.userError import *
from tools.pyomoSolverCreator import *
from tools.core.metabolite import metabolite
from tools.core.reaction import reaction
from tools.core.organism import organism
from tools.core.model import model

class fba(object):
    """
    Performs flux balance analysis

    Ali R. Zomorrodi - Segre Lab @ BU
    Last updated: 10-30-2014 
    """   

    def __init__(self,model, optSolverName = None, createModel = None, screenOutput = None, outputFile = None, reportLevel = None): 

        """
        INPUTS (required):
        ------
                      model: An instance of class model containing the information
                             about the metabolic model

        INPUTS (optional):
        ------
              optSolverName: Name of the LP solver to be used to solve the LP. Current 
                             allowable choices are cplex and gurobi
               screenOutput: By default (on) writes  a summary including the solve 
                             status, optimality status (if not optimal), objective 
                             function value and the elapsed time on the screen.
                             if set to a value of 'off' no resuults are written on 
                             the screen, in which case The user can instead specifiy 
                             an output fiile using the option outputFile, or store 
                             them in the variable runOutput (see the 'run' method for
                             details)
                createModel: A parameter indicating whether a pyomo model should be 
                             created (1) or not. Default is 1. The options is useful
                             for the cases a model is already created and one just 
                             wants to change some model attributes (e.g., flux bounds)
                             and rerun FBA. Setting this parameter to zero will save 
                             soem runtime as the model need not to be created again.
                 outputFile: Optional input. It is a string containg the path to a 
                             file and its name (e.g., 'results/fbaResults.txt'), where
                             the results should be written to. 
                reportLevel: Specifies what should be reported in the output file 
                             or in the output variable runOutput.
                             Takes three values:
                             (1)  None: Only exitflag and objective function value are
                                        reported
                             (2) 'all': exitflag, objective function value and the optimal
                                        values of all variables are reported
                                        in the form of a dictionary whose keys are the 
                                        specified variable names and the values are  
                                        their optiimal values
                             (3) A list containing the name of the selected variables: 
                                        exitflag, objective function value and the optimal
                                        values of the specified variables are reported
                                        in the form of a dictionary whose keys are the 
                                        specified variable names and the values are  
                                        their optiimal values
        """
       
        # Metabolic model
        self.model = model

        # Solver name
        if optSolverName == None:
            self.optSolverName = 'cplex'
        else:
            if optSolverName.lower() in ['cplex','gurobi']:
                self.optSolverName = optSolverName
            else:
                raise userError('**Error! Invalid solver name (eligible choices are cplex and gurobi)\n')          

        # Whether to create a pyomo model
        if createModel == None: 
            self.createModel = 1   
        elif createModel not in [0,1]:    
            raise userError('**Error! Inalid value for createModel! The allowable values are 0 and 1 ')
        else:
            self.createModel = createModel
               
        # Output to the screen 
        if screenOutput == None:
            self.screenOutput = 'on'
        elif type(screenOutput) is not str:
            raise userError("**Error! screenOutput should be a string ('on' or 'off')")
        elif screenOutput.lower() not in ['on','off']:
            raise userError("**Error! The only eligible values for screenOutput are 'on' and 'off'")
        else:
             self.screenOutput = screenOutput

        # Output file
        self.outputFile = outputFile

        # Report level
        if reportLevel != None and type(reportLevel) is not list:
            if reportLevel.lower() != 'all':
                raise userError("**Error! reportLevel should be the string 'all' or a list of the selected variables")
            else:
                self.reportLevel = reportLevel
        elif type(reportLevel) is list:
            self.reportLevel = reportLevel[:]
        else:
            self.reportLevel = reportLevel

    # Objective function
    def objectiveFunc_rule(self,fbaModel):
        # Reactions for which the objective coefficient has not bee assigned
        non_obj_rxns = [j.id for j in fbaModel.J if j.objective_coefficient == None]
        if len(non_obj_rxns) >= 1: 
            print("**Error! 'objective_coefficient' has not been defined for the following reacitons:")
            print non_obj_rxns
            raise userError()
        return sum(j.objective_coefficient*fbaModel.v[j] for j in fbaModel.J)
        

    # Mass balance 
    def massBalance_rule(self,fbaModel, i):
        return sum(j.stoichiometry[i]*fbaModel.v[j] for j in i.reactions) == 0 
        
    def createPyomoModel(self):
        """
        This fbaModel creates a pyomo model for FBA fbaModel
        """   
        #--- Create a pyomo model fbaModel ---
        fbaModel = ConcreteModel()
        
        #--- Define sets ---
        # Set of metabolites 
        fbaModel.I = Set(initialize = self.model.metabolites)   

        # Set of rxns  
        fbaModel.J = Set(initialize = self.model.reactions)     

        #--- Define the fbaModel variables --- 
        def assignFluxBounds(fbaModel,j):
            return j.flux_bounds 
        
        fbaModel.v = Var(fbaModel.J, domain=Reals, bounds = assignFluxBounds)
        
        #--- Defiine the objective function and constraints ----
         # Objective function
        fbaModel.objectiveFunc = Objective(rule=self.objectiveFunc_rule, sense = maximize)
        

        # Mass balance 
        fbaModel.massBalance_const = Constraint(fbaModel.I, rule=self.massBalance_rule)

        self.fbaModel = fbaModel 
    
    
    def run(self):
        """ 
        This method runs FBA. 
        OUTPUT:
        -------
        runOutput: A list of three items:
                       exitflag: A string, which can be 'globallyOptimal', 'solverError'
                                 or what is stored in OptSoln.solver.termination_condition
                       objValue: Optimal objective funtion value
                   optVarValues: Takes a value of None if the problem is not solved to 
                                 optimality and is a dictionary where keys are the reaction
                                 names and values are reaciton fluxes. If reportLevel is 'all'
                                 then it includes all reacitons and otherwise it includes only
                                 the selected reaction specified in reportLevel
        """

        start_fba = time.clock()

        #---- Creating and instantiating the fbaModel ----
        start_pyomo = time.clock()

        # Create the pyomo model fbaModel only if self.createModel == 1        
        if self.createModel == 1:
            self.createPyomoModel()

        # Instantiate the fbaModel
        self.fbaModel.preprocess()

        #---- Solve the model ----
        # Create a solver and set the options
        solverType = pyomoSolverCreator(self.optSolverName)

        elapsed_pyomo = (time.clock() - start_pyomo)

        #- Solve the fbaModel (tee=True shows the solver output) -

        try:
            start_solver = time.clock()
            OptSoln = solverType.solve(self.fbaModel,tee=False)
            solverFlag = 'normal'

        # In the case of an error switch the solver
        except:
            if self.screenOutput.lower() == 'on':
                print "**Warning! ",self.optSolverName," failed. An alternative solver is tried"        

            if self.optSolverName.lower() == 'gurobi':
                self.optSolverName = 'cplex'
            elif self.optSolverName.lower() == 'cplex':
                self.optSolverName = 'gurobi'

            # Try solving with the alternative solver
            solverType = pyomoSolverCreator(self.optSolverName)
            try:
                start_solver = time.clock()
                OptSoln = solverType.solve(self.fbaModel,tee=False)
                solverFlag = 'normal'
            except:
                solverFlag = 'solverError'
                if self.screenOutput.lower() == 'on':
                    print '**Warning! The alternative solver failed. No solution was returned'

        elapsed_solver = (time.clock() - start_solver)

        #----- Print the results in the output ------
        if solverFlag == 'normal' and str(OptSoln.solver.termination_condition).lower() == 'optimal':
        
            exitflag = 'globallyOptimal'

            # Load the results
            self.fbaModel.load(OptSoln)
        
            # Value of the objective function
            objValue = self.fbaModel.objectiveFunc()

            # Optimal values of variables
            optVarValues = {}

            # Print the results on the screen 
            if self.screenOutput.lower() == 'on':
                print "\nSolver.status = ",OptSoln.solver.termination_condition
                print "Optimality status = ",exitflag
                print "Objective value = ",objValue
            elif self.screenOutput.lower() == 'off':
                pass


            # Values of the selected variables
            if self.reportLevel == None:
                # Output of the run command    
                runOutput = [exitflag,objValue]
            elif type(self.reportLevel) is str:
                if self.reportLevel.lower() == 'all':
                    optVarValues = {}
                    for j in self.fbaModel.J.value:
                        optVarValues[j] = self.fbaModel.v[j].value

                runOutput = [exitflag,objValue,optVarValues]
            elif type(self.reportLevel) is list:
                for j in self.reportLevel:
                    optVarValues[j] = self.fbaModel.v[j].value

                runOutput = [exitflag,objValue,optVarValues]

            # Write the results into the output file 
            if self.outputFile != None:
                pass    # *** To be completed ***
            else:
                pass


        # If there was a solver error or if an optimal solution was not returned 
        else:
            if solverFlag == 'solverError':
                exitflag = solverFlag
            else:
                exitflag = str(OptSoln.solver.termination_condition)

            objValue = None 
            optVarValues = None 

            if self.screenOutput.lower() == 'on':
                print "\n\n** No optimal solutions found (solution.solver.status = ",OptSoln.Solution.status,", solver.status =",OptSoln.solver.status,", solver.termination_condition = ",OptSoln.solver.termination_condition,")\n"

            # Values of the selected variables
            if self.reportLevel == None:
                # Output of the run command    
                runOutput = [exitflag,objValue]
            else:
                runOutput = [exitflag,objValue,optVarValues]

            # Write the results into the output file
            if self.outputFile != None:
                pass    # *** To be completed ***
            else:
                pass
 
        # Time required to perform FBA
        elapsed_fba = (time.clock() - start_fba)

        if self.screenOutput.lower() == 'on':
           print 'elapsed time: (pyomo = ',elapsed_pyomo,'  ,  solver = ',elapsed_solver , '  ,  fba = ',elapsed_fba,')\n'

        return runOutput

#----------------------------
if __name__ == "__main__":

    import time
    from tools.io.read_gams_model import read_gams_model
    from tools.io.read_sbml_model import read_sbml_model
    from set_specific_bounds import set_specific_bounds
    from cobra import test
 
    # Solver name
    optSolverName = 'gurobi'

    #--- Test model ---
    print '--- Test model ---'
    testModel = read_gams_model(gams_model_file = '/fs/home06/alizom//models/test/testModelData.py',model_name = 'testModel',organism_name = 'testOrg',model_type = 'metabolic')

    # Growth medium
    testModel = set_specific_bounds(testModel,specific_bounds_file = '/fs/home06/alizom/models/test/testMedium.py')

    # Assign and objective function coefficients
    for rxn in testModel.reactions:
        rxn.objective_coefficient = 0

    for bm in testModel.biomass_reactions:
        bm.objective_coefficient = 1 
 
    fbaTest = fba(testModel, optSolverName = optSolverName, reportLevel = 'all') 
    runOutput = fbaTest.run()
    for r in runOutput[2].keys():
        print r.id,'   ',runOutput[2][r]

    #--- E. coli iAF1260 model ---
    print '--- iAF1260 model ---'
    print '   Read the gams model ...'
    start = time.clock()
    iAF1260 = read_gams_model(gams_model_file = '/fs/home06/alizom//models/Ecoli/iAF1260/iAF1260ModelData.py',model_name = 'iAF1260',organism_name = 'E. coli',model_type = 'metabolic')
    print '        Reading the gams model took ',str(time.clock() - start)

    # Growth medium
    print '   Set the growth meidum ...'
    iAF1260 = set_specific_bounds(iAF1260,specific_bounds_file = '/fs/home06/alizom/models/Ecoli/iAF1260/iAF1260_minimal_glucose_anaerobic.py',simulation_condition = 'minimal_glucose_anaerobic')

    # Assign and objective function coefficients
    for rxn in iAF1260.reactions:
        rxn.objective_coefficient = 0

    for bm in iAF1260.biomass_reactions:
        if bm.id == 'Ec_biomass_iAF1260_core_59p81M':
            bm.objective_coefficient = 1 
 
    print '   create the pyomo model ...'
    fbaiAF1260 = fba(iAF1260, optSolverName = optSolverName) 
    fbaiAF1260.run()


    #--- Salmonella ---
    print '--- Salmonella model ---'
    print '   Read the sbml model ...'
    salModel = read_sbml_model(sbml_model_file = test.salmonella_sbml,model_name = 'salmonella',organism_name = 'salmonella', model_type = 'metabolic',import_bounds = 1)
 
    # Assign and objective function coefficients
    for rxn in iAF1260.reactions:
        rxn.objective_coefficient = 0

    for bm in iAF1260.biomass_reactions:
        if bm.id == 'Ec_biomass_iAF1260_core_59p81M':
            bm.objective_coefficient = 1 
 
    print '   create the pyomo model ...'
    fbaSal = fba(iAF1260, optSolverName = optSolverName) 
    fbaSal.run()




