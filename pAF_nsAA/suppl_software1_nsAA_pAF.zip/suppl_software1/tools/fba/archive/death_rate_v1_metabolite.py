from __future__ import division
import sys, time
sys.path.append('../../')
from coopr.pyomo import *
from coopr.opt import *
from tools.userError import *
from tools.core.metabolite import metabolite
from tools.core.reaction import reaction
from tools.core.organism import organism
from tools.core.model import model

def death_rate(model,limiting_nutrients, flux_key = None, screen_output = 'on'):
    """
    Compute the death rate 

    INPUTS:
    -------
                 model: An object of type model
    limiting_nutrients: A list of objects of type metabolite containing 
                        the list of limiting nutrients
             flux_keys: The key for the dicitonary where fluxes are stored in the model,
                        e.g., time points (see fba.py for more info)
         screen_output: Prints in the output a summary if 'on'. Set it to 
                       'off' so nothing is printed in the output

    OUTPUT:
    -------
              mu_death: death_rate

    Ali R. Zomorrodi - Segre Lab @ BU
    Last updated: 12-01-2014 
    """   
    # Compute the death phase mu for each limiting nutrients
    mu_death = []

    for nutrient in limiting_nutrients:
        if nutrient.biomass_yield == None:
            # Compute Yx/s (biomass yield)
            nutrient.biomass_yield_calc()  

        if nutrient.ms == None:
            # Compute Yx/s (biomass yield)
            nutrient.ms_calc()  

        # Exchange (uptake) reaction for this metabolite
        exch_rxn = [r for r in nutrient.reactant_reactions if r.type.lower() == 'exchange']
        if len(exch_rxn) > 1:
            raise userError('metabolite ' + nutrient.id + ' has more than one exchange reaction')
        else:
            exch_rxn = exch_rxn[0]

        # Compute the lower bound on exchange reaction (upper bound on uptake)
        exch_rxn.kinetic_rate_calc()

        # mu_death = Yxs*(v_uptake - ms)
        if abs(exch_rxn.kinetic_rate) > abs(nutrient.ms):
            mu_death.append(0)
        else:
            mu_death.append((abs(exch_rxn.kinetic_rate) - abs(nutrient.ms))*nutrient.biomass_yield)

    # If more than one limitting nutrients have run out, set mu_death to the largest value
    # (the one with most negative value)
    mu_death = min(mu_death)

    if screen_output.lower() == 'on':
        print '    mu_death = ',mu_death
                                 
    return mu_death

