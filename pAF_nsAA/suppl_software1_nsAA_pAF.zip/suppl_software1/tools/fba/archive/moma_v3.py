from __future__ import division
import sys, time
sys.path.append('../../')
from coopr.pyomo import *
from coopr.opt import *
from tools.pyomoSolverCreator import *
from tools.userError import userError
from tools.core.compound import compound
from tools.core.reaction import reaction

# The following lines change the temporary directory for pyomo
from pyutilib.services import TempfileManager
TempfileManager.tempdir = '/tmp/'

class moma(object):
    """
    Performs flux balance analysis

    Ali R. Zomorrodi - Segre Lab @ Boston University
    Last updated: 08-10-2015 
    """   

    def __init__(self,model, distance_type = '2-norm',optimization_solver = 'gurobi', create_model = True, flux_key = None, store_opt_fluxes = True, warnings = True, stdout_msgs = True): 

        """
        INPUTS (required):
        ------
                      model: An instance of class model containing the information
                             about the metabolic model. Each reaction in the model 
                             model must have a field called wildtype_flux containing 
                             the reaciton fluxes for the wild-type

        INPUTS (optional):
        ------
              distance_type: The way to compute the distance between the fluxes.
                             Eligible cases are 'euclidean' or '2-norm' (default) 
                             and '1-norm'
        optimization_solver: Name of the LP solver to be used to solve the LP. Current 
                             allowable choices are cplex and gurobi
                   warnings: Can be 'on' or 'off' shwoing whether the warnings should be writtten to the 
                             screen or not
                stdout_msgs: By default (on) writes  a summary including the solve 
                             status, optimality status (if not optimal), objective 
                             function value and the elapsed time on the screen.
                             if set to a value of 'off' no resuults are written on 
                             the screen, in which case The user can instead specifiy 
                             an output fiile using the option outputFile, or store 
                             them in the variable solution (see the 'run' method for
                             details)
               create_model: A parameter indicating whether a pyomo model should be 
                             created (1) or not. Default is 1. The options is useful
                             for the cases a model is already created and one just 
                             wants to change some model attributes (e.g., flux bounds)
                             and rerun FBA. Setting this parameter to zero will save 
                             soem runtime as the model need not to be created again.
                   flux_key: Optimal reaction fluxes after performing FBA are saved into
                             reaction.flux where reaction is the reaction object in the 
                             input model. If flux key is provided, then reaction fluxes 
                             are stored reaction.flux, but reaction.flux in this case is
                             a dictionary instead of a scalar and the current flux value
                             is stored in the dictionary with the key specified by flux_key.
                             This is useful, for example, when performing dynamic FBA,
                             where fluxes should be stored for each time, e.g.,
                             reaction.flux = {0:0.25,0.5:0.24,...}, where keys are tiime points
                             and values are fluxes
           store_opt_fluxes: If True the optimal values of reaction fluxes are stored in 
                             the variable 'flux' of reaction objects. If False, the optimal
                             values of fluxes are not stored. The latter case is useful when
                             one is interested only in the optimal value of the objective function 
                   warnings: Can be True or False shwoing whether the warnings should be writtten to the 
                             screen or not. The default is True 
                stdout_msgs: Prints a summary of the FBA and a number of other messages in the output if 'on.
                             Eligible values are True and Flase and the default is True 

        OUTPUTS:
        ---------
        folution: A dictionary with the following keys:
                  exit_flag: A string, which can be 'globallyOptimal', 'solverError'
                            or what is stored in OptSoln.solver.termination_condition
                  objValue: Optimal objective funtion value

        Optimal flux values are stored directly into the 'flux' field of the reaction
        objects. The value of the flux will be None if the problem is not solved to 
        optimality. 

        These are the outputs of the method 'run'
        """
       
        # Metabolic model
        self.model = model

        # Check if the all reactions in the model have a field called 
        # flux_wildtype containing the wild-type reaction fluxes
        no_wt_flux_rxns = [r for r in self.model.reactions if 'wildtype_flux' not in dir(r)]
        if len(no_wt_flux_rxns) > 0:
                print '\n**ERROR! The following reactions have no field wildtype_flux:'
                counter = 0
                while counter <= 10:
                    print no_wt_flux_rxns[counter].id
                    counter += 1
                if len(no_wt_flux_rxns) > 10:
                    print '... and %d more\n' % (len(no_wt_flux_rxns) - 10)
                raise userError()

        # Type of distance
        if distance_type not in ['euclidean','2-norm','1-norm']:
            raise userError('**ERROR! Invalid dsitance_type (eligible inputs are euclidean or 2-norm and 2-norm)\n')
        else:
            self.distance_type = distance_type

        # Solver name
        if optimization_solver.lower() in ['cplex','gurobi']:
            self.optimization_solver = optimization_solver
        else:
            raise userError('**ERROR! Invalid solver name (eligible choices are cplex and gurobi)\n')          

        # Whether to create a pyomo model
        if create_model not in [True,False]:    
            raise userError('**ERROR! Inalid value for create_model! Allowable values are True and False')
        else:
            self.create_model = create_model
               
        # Warnings and messages in the standard output
        if not isinstance(stdout_msgs,bool):
            raise TypeError("stdout_msgs must be either True or False")
        else:
            self.stdout_msgs = stdout_msgs

        if not isinstance(warnings,bool):
            raise TypeError("warnings must be either True or False")
        else:
            self.warnings = warnings

        # flux_key
        self.flux_key = flux_key 

        # store_opt_fluxes
        self.store_opt_fluxes = store_opt_fluxes
        if self.store_opt_fluxes == False:
            for rxn in model.reactions:
                rxn.flux = None

    # Objective function
    def objectiveFunc_rule(self,pyomo_momaModel):
        # Reactions for which the objective coefficient has not bee assigned
        non_obj_rxns = [j.id for j in pyomo_momaModel.J if j.objective_coefficient == None]
        if len(non_obj_rxns) >= 1: 
            raise userError("ERROR! 'objective_coefficient' has not been defined for the following reactions: " + str(non_obj_rxns))
        if self.distance_type.lower() in ['euclidean','2-norm']:
            return sum(j.objective_coefficient*(pyomo_momaModel.v[j] - j.wildtype_flux)*(pyomo_momaModel.v[j] - j.wildtype_flux) for j in pyomo_momaModel.J)
        else:
            return sum(j.objective_coefficient*pyomo_momaModel.abs_vdiff[j] for j in pyomo_momaModel.J)
        

    # Define the flux bounds
    def assignFluxBounds(self,pyomo_momaModel,j):
        return tuple(j.flux_bounds) 
        
    # Mass balance 
    def massBalance_rule(self,pyomo_momaModel,i):
        return sum(j.stoichiometry[i]*pyomo_momaModel.v[j] for j in i.reactions) == 0 

    # Absolute value constraints
    def absolute_const1_rule(self,pyomo_momaModel,j):
        return pyomo_momaModel.abs_vdiff[j] >= pyomo_momaModel.v[j] - j.wildtype_flux 
    def absolute_const2_rule(self,pyomo_momaModel,j):
        return pyomo_momaModel.abs_vdiff[j] >= -(pyomo_momaModel.v[j] - j.wildtype_flux) 
        
    def createPyomoModel(self):
        """
        This creates a pyomo model for moma 
        """   
        #--- Create a pyomo model pyomo_momaModel ---
        pyomo_momaModel = ConcreteModel()
        
        #--- Define sets ---
        # Set of compounds 
        pyomo_momaModel.I = Set(initialize = self.model.compounds)   

        # Set of rxns  
        pyomo_momaModel.J = Set(initialize = self.model.reactions)     

        #--- Define the pyomo_momaModel variables --- 
        # Reaction fluxes
        pyomo_momaModel.v = Var(pyomo_momaModel.J, domain=Reals, bounds = self.assignFluxBounds)

        # abs(v - v_WT)
        pyomo_momaModel.abs_vdiff = Var(pyomo_momaModel.J, domain=Reals, bounds = (0,1000))
        
        #--- Defiine the objective function and constraints ----
         # Objective function
        pyomo_momaModel.objectiveFunc = Objective(rule=self.objectiveFunc_rule, sense = minimize)

        # Mass balance 
        pyomo_momaModel.massBalance_const = Constraint(pyomo_momaModel.I, rule=self.massBalance_rule)

        # Absolute value constraints
        if self.distance_type.lower() == '1-norm':
            pyomo_momaModel.absolute_const1 = Constraint(pyomo_momaModel.J, rule=self.absolute_const1_rule)
            pyomo_momaModel.absolute_const2 = Constraint(pyomo_momaModel.J, rule=self.absolute_const2_rule)


        self.pyomo_momaModel = pyomo_momaModel 
    
    def run(self):
        """ 
        This method runs FBA. 

        OUTPUT:
        -------
        folution: A dictionary with the following keys:
                  exit_flag: A string, which can be 'globallyOptimal', 'solverError'
                            or what is stored in OptSoln.solver.termination_condition
                  objValue: Optimal objective funtion value

        Optimal flux values are stored directly into the 'flux' field of the reaction
        objects. The value of the flux will be None if the problem is not solved to 
        optimality. 
        """

        # Processing and walltime
        start_moma_pt = time.clock()
        start_moma_wt = time.time()

        #---- Creating and instantiating the pyomo_momaModel ----
        start_pyomo_pt = time.clock()
        start_pyomo_wt = time.time()

        # Create the pyomo model pyomo_momaModel only if self.create_model == 1        
        if self.create_model == True:
            self.createPyomoModel()

        # Instantiate the pyomo_momaModel
        self.pyomo_momaModel.preprocess()

        #---- Solve the model ----
        # Create a solver and set the options
        solverType = pyomoSolverCreator(self.optimization_solver)

        elapsed_pyomo_pt = (time.clock() - start_pyomo_pt)
        elapsed_pyomo_wt = (time.time() - start_pyomo_wt)

        #- Solve the pyomo_momaModel (tee=True shows the solver output) -
        try:
            start_solver_pt = time.clock()
            start_solver_wt = time.time()
            OptSoln = solverType.solve(self.pyomo_momaModel,tee=False)
            solverFlag = 'normal'

        # In the case of an error switch the solver
        except  Exception, e:
            if self.warnings:
                print '**WARNING (moma.py)! {} failed with the following error: \n{} \nAn alternative solver is tried'.format(self.optimization_solver,e)

            if self.optimization_solver.lower() == 'gurobi':
                self.optimization_solver = 'cplex'
            elif self.optimization_solver.lower() == 'cplex':
                self.optimization_solver = 'gurobi'

            # Try solving with the alternative solver
            solverType = pyomoSolverCreator(self.optimization_solver)
            try:
                start_solver_pt = time.clock()
                start_solver_wt = time.time()
                OptSoln = solverType.solve(self.pyomo_momaModel,tee=False)
                solverFlag = 'normal'
            except  Exception, e:
                solverFlag = 'solverError'
                if self.warnings:
                    print '**WARNING (moma.py)! {} failed with the following error: \n{} \nAn alternative solver is tried'.format(self.optimization_solver,e)

        elapsed_solver_pt = (time.clock() - start_solver_pt)
        elapsed_solver_wt = (time.time() - start_solver_wt)

        #----- Print the results in the output ------
        if solverFlag == 'normal' and str(OptSoln.solver.termination_condition).lower() == 'optimal':
        
            exit_flag = 'globallyOptimal'

            # Load the results
            self.pyomo_momaModel.load(OptSoln)
        
            # Value of the objective function
            objValue = self.pyomo_momaModel.objectiveFunc()

            # Optimal values of variables
            optVarValues = {}

            # Print the results on the screen 
            if self.stdout_msgs:
                print "\nSolver.status = ",OptSoln.solver.termination_condition
                print "Optimality status = ",exit_flag
                print "Objective value = ",objValue
            elif self.stdout_msgs.lower() == 'off':
                pass

            # Store the optimal flux values in the variable 'flux' of the reaction objects
            if self.store_opt_fluxes == True:
                for rxn in self.model.reactions:
                    if self.flux_key is None:
                        rxn.flux = self.pyomo_momaModel.v[rxn].value
                    elif self.flux_key is not None and type(rxn.flux) is dict:
                        rxn.flux[self.flux_key] = self.pyomo_momaModel.v[rxn].value
                    else:
                        rxn.flux = {}
                        rxn.flux[self.flux_key] = self.pyomo_momaModel.v[rxn].value

            self.solution = {'exit_flag':exit_flag,'objective_value':objValue}

        # If there was a solver error or if an optimal solution was not returned 
        else:
            if solverFlag == 'solverError':
                exit_flag = solverFlag
            else:
                exit_flag = str(OptSoln.solver.termination_condition)

            objValue = None 
            optVarValues = None 

            if self.stdout_msgs:
                print "** No optimal solutions found (solution.solver.status = ",OptSoln.Solution.status,", solver.status =",OptSoln.solver.status,", solver.termination_condition = ",OptSoln.solver.termination_condition,")\n"

            self.solution = {'exit_flag':exit_flag,'objective_value':objValue}

            if self.store_opt_fluxes == True:
                for rxn in self.model.reactions:
                    if self.flux_key is None and type(rxn.flux) is not dict:
                        rxn.flux = None 
                    elif self.flux_key is not None and type(rxn.flux) is dict:
                        rxn.flux[self.flux_key] = None 
                    else:
                        if self.warnings:
                            print 'WARNING! The current reaction.flux is not in the formm of a dictionary for reaction ',rxn.id,' and will be overwritten'
                        rxn.flux = {}
                        rxn.flux[self.flux_key] = None 

        # Time required to perform FBA
        elapsed_moma_pt = (time.clock() - start_moma_pt)
        elapsed_moma_wt = (time.time() - start_moma_wt)

        if self.stdout_msgs:
           print 'MOMA elapsed (processing/wall) time (sec): pyomo = {:.3f}/{:.3f}  ,  solver = {:.3f}/{:.3f}  ,  moma = {:.3f}/{:.3f}\n'.format(elapsed_pyomo_pt,elapsed_pyomo_wt,elapsed_solver_pt,elapsed_solver_wt,elapsed_moma_pt,elapsed_moma_wt)

        return self.solution

#----------- Sample implementation -----------------
if __name__ == "__main__":

    import time
    from tools.io.read_gams_model import read_gams_model
    from tools.io.read_sbml_model import read_sbml_model
    from set_specific_bounds import set_specific_bounds
    from cobra import test
 
    # Solver name
    optimization_solver = 'gurobi'

    #--- E. coli iAF1260 model ---
    start = time.clock()
    WT = read_gams_model(gams_model_file = '/fs/home06/alizom//models/Ecoli/iAF1260/iAF1260ModelData.py',model_name = 'iAF1260',organism_name = 'E. coli',model_type = 'metabolic')
    print '        Reading the gams model took ',str(time.clock() - start)

    WT.biomass_reaction = WT.get_reactions({'Ec_biomass_iAF1260_core_59p81M':'id'})

    # Growth medium
    set_specific_bounds(WT,specific_bounds_file = '/data/alizom/models/Ecoli/iAF1260/iAF1260_minimal_glucose_anaerobic.py',simulation_condition = 'minimal_glucose_anaerobic')

    # Assign and objective function coefficients
    for rxn in WT.reactions:
        rxn.objective_coefficient = 0
    WT.biomass_reaction.objective_coefficient = 1

    print '   Perfomring FBA ...'
    WT.fba()

    print '   Perfomring MOMA ...'
    for rxn in WT.reactions:
        rxn.wildtype_flux = rxn.flux
        rxn.objective_coefficient = 1
    momaModel = moma(model = WT, distance_type = '1-norm', optimization_solver = 'cplex')
    momaModel.run()
    for rxn in WT.reactions:
        print rxn.id,'    fba = ',rxn.wildtype_flux,'  moma = ',rxn.flux,'\n'
