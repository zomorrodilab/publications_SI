from __future__ import division
import sys, time
sys.path.append('../../')
from tools.userError import userError 
from tools.core.compound import compound
from tools.core.reaction import reaction
from tools.core.organism import organism
from tools.core.model import model
from fba import fba
from death_rate import death_rate

class DMMM(object):
    """
    Performs dynamic multi-species metabolic modeling (DMMM) (PMID: 20668487) 

    Ali R. Zomorrodi - Daniel Segre Lab @ Boston University
    Last updated: 07-28-2015
    """   

    def __init__(self,community_members,shared_compounds,reactor_type = 'batch',time_range = [0,1,10],carrying_capacity_cells_per_mL = float('inf'), serial_dilution_params = {'dilution_factor':None,'time_between_dilutions':None}, store_dynamic_fluxes = False, screen_output = 'on'):

        """
        INPUTS:
        ------
          community_members: A list of objects of type model for each community member.
                             The object organism of the moell must have the following 
                             properties specified:
                             gDW_per_mL: Initial cell cencentration in gDW/mL in the form 
                                         of a dictionary where the key is the initial time
                                         point and the value is the initial cell concentraiton
                             The following optional properties can also be provided:
                             cells_per_mL: Initial cell cencentration in cells/mL in the form 
                                         of a dictionary where the key is the initial time
                                         point and the value is the initial cell concentraiton
                             gDW_per_cell: Gram of dry weight for one cell 
           shared_compounds: A list of objects of type compound containing the information
                             about shared compounds. The assigned compartment for these
                             compounds is 'shared', Each shared compound object must have the
                             following properties specified: 
                             reactant_reactions: Exchange reactions of community members taking
                             up this compound 
                             product_reactions: Echange reactions of community members producing 
                             this compound
                             reactions: reactant_reactions + product_reactions
                             concentration: Initial concentration in the form of a dictionary
                                            where the key is the initial time point and value
                                            is initial concentration in mM. Example: {0:0.1} 
               reactor_type: Type of reactor for simulations (batch, serial_dilution, life_cycle, chemostat)
                 time_range: Range of the simulation time. This is a list with 
                             either two or three elements.
                             Two-element format: [startTime,endTime]
                             Three-element format: [startTime,timeStep,endTime]. If the 
                             time step is not given a time step of one is used
    carrying_capacity_cells_per_ml: Carrying capacity in cells/ml of the system 
                             (for logistic growth)
     serial_dilution_params: Ia needed if reactor_type is "serial_dilution". It is a dictionary
                             with two keys 'dilution_factor' (e.g., 1000) and time_between_dilutions in hour
       store_dynamic_fluxes: If True, dynamic changes in flux of all reactions are stored 
                             in the 'flux' field by setting store_opt_fluxes for fba to True.
                             The default for this input is False. Note that even when the value
                             of this parameter is True, dynamic changes in fluxes for reaction
                             with store_flux = True are stored. 
                screenOuput: Prints a summary of the FBA in the output. Set it to 'off'
                             to turn it off.

        NOTE:
        -----
        Reaction fluxes and cell concentrations (organism.cells_per_mL) in the model as well as
        shared compound concentraitons (shared_cmp.concentration) should have already been
        stored in the form a dictionary. Keys of this dictionary are time points and 
        values are reactoin fluxes or concentraitons. This dictionary can be empty for
        fluxes at the begining but it must have one member for the other two 
        indicating the initial concentration of the shared compounds and initial cell 
        concentrations. For example, organsim.concentration = {0:10^5} or
        shared_cmp.concentraiton = [0:0.5]
        """

        self.community_members = community_members
        self.shared_compounds = shared_compounds

        if reactor_type not in ['batch','serial_dilution','life_cycle','chemostat']:
            raise ValueError('reactor_type must be batch, serial_dilution, life_cycle or chemostat.')
        else:
            self.reactor_type = reactor_type

        if store_dynamic_fluxes not in [True,False]:
            raise userError('**ERROR! store_dynamic_fluxes must be either True or False\n')
        else:
            self.store_dynamic_fluxes = store_dynamic_fluxes

        if screen_output not in ['on','off']:
            raise userError('**ERROR! screen_output must be either on or off.\n')
        else:
            self.screen_output = screen_output


        if len(time_range) == 3:
            # Initial time
            self._t0 = time_range[0]

            # Original dt. This mught be adjusted during the simulations
            self._dt = time_range[1]

            # Final simulation time
            self._tf = time_range[2]   
        elif len(time_range) == 2:
            # Initial time
            self._t0 = time_range[0]

            # Original dt. This mught be adjusted during the simulations
            self._dt = 1

            # Final simulation time
            self._tf = time_range[1]   # Final simulation time
        else:
            userError("**ERROR! Invalid time_range (allowable size of the vectors are two or three)") 

        # Carrying capacity
        if carrying_capacity_cells_per_mL != float('inf') and carrying_capacity_cells_per_mL <= 0:
            raise userError('Invalid carrying capacity (should be inf or a positive value)')
        else:
            self.carrying_capacity_cells_per_mL = carrying_capacity_cells_per_mL
            # Average gDW/cell
            gDW_per_cell_ave = sum([member.organism.gDW_per_cell for member in self.community_members])/len(self.community_members)
            self.carrying_capacity_gDW_per_mL = carrying_capacity_cells_per_mL*gDW_per_cell_ave

        #-- Serial dilution parameters ---
        if not isinstance(serial_dilution_params,dict):
            raise TypeError('serial_dilution_params must a dictionary.')
        else:
            self.serial_dilution_params = serial_dilution_params

        #-- Check if an initial concentration for the shared compounds and cells --
        # have been provided. If the initial concentrations are provided but they 
        # are in the form of a single value, instead of a dictionary, they are assigned
        # to the first time point as a dictionary. 

        # The initial concentration can be given for a cell can be given in gDW/mL
        # or in cells_per_mL
        no_conc_members = []
        for member in self.community_members:
            if member.organism.cells_per_mL is None and member.organism.gDW_per_mL is None:
                no_conc_members.append(member)

            elif member.organism.cells_per_mL is not None and member.organism.gDW_per_mL is None:
                if type(member.organism.cells_per_mL) is not dict:
                    member.organism.cells_per_mL = {self._t0:member.organism.cells_per_mL}

                member.organism.gDW_per_mL = {self._t0:member.organism.cells_per_mL[self._t0]*member.organism.gDW_per_cell}

            elif member.organism.cells_per_mL is None and member.organism.gDW_per_mL is not None:
                if type(member.organism.gDW_per_mL) is not dict:
                    member.organism.gDW_per_mL = {self._t0:member.organism.gDW_per_mL}
                # If initial concentration is given in terms of gDW_per_mL, then there is no need
                # for DMMM to have gDW_per_cell
                if member.organism.gDW_per_cell is not None:
                    member.organism.cells_per_mL = {self._t0:member.organism.gDW_per_mL[self._t0]/member.organism.gDW_per_cell}

            elif member.organism.cells_per_mL is not None and member.organism.gDW_per_mL is not None:
                if type(member.organism.cells_per_mL) is not dict:
                    member.organism.cells_per_mL = {self._t0:member.organism.cells_per_mL}
                if type(member.organism.gDW_per_mL) is not dict:
                    member.organism.gDW_per_mL = {self._t0:member.organism.gDW_per_mL}

        if len(no_conc_members) > 0:
            print 'Initial biomass concnetration was not provided for the following community members:'
            for member in no_conc_members:
                print member.id
            raise userError()

        # Check initial concentration for shared compounds
        non_conc_cmp = []
        for shared_cmp in self.shared_compounds:
            if shared_cmp.concentration is None:
                non_conc_cmp.append(shared_meetab)
            # If the initial concentration has been provided but not in the form of
            # a dicitonary, convert it into a dicitonary and assigne it to the initial
            # time point specified by time_range[0]
            elif type(shared_cmp.concentration) is not dict:
                shared_cmp.concentration = {self._t0:shared_cmp.concentration}

        # Initialize mu for each community members
        for member in self.community_members:
            if member.organism.mu == None:
                member.organism.mu = {} 

    def uptake_rate_UB_calc(self):
        """ 
        Compute the upper bound on the uptake rates of the shared compounds 
        (LB on exchange fluxes) using kinetic expressions 
        """ 
        for shared_cmp in self.shared_compounds:
            for uptake_reaction in shared_cmp.reactant_reactions:         
                # Assume uptake reactions are exchange reactions with only one
                # reactant 
                uptake_reaction.reactants[0].concentration = shared_cmp.concentration[self._t] 
                uptake_reaction.kinetic_rate_calc(assignLB = True) 

    def update_fba_model(self):
        """ 
        This is an abstract method that can be defined by subclasses. This is useful
        for cases one needs to solve a different fba model (i.e., different objective
        function or different constriants) at each time point
        """ 
        pass 

    def mu_uptake_export_calc(self):
        """ 
        Compute the specific growth rate of community members and the uptake
        and export rates of shared compounds 
        """ 
        for member in self.community_members:
            member.fba(create_model = False, store_opt_fluxes = self.store_dynamic_fluxes, flux_key = self._t, screen_output = 'off')
            if member.fba_model.solution['exit_flag'] == 'globallyOptimal':
                member.organism.mu[self._t] = member.biomass_reaction.flux[self._t] + member.organism.mortality_rate
            else:
                if self.screen_output.lower() == 'on':
                    print '   Death rate ...'
                # Find the limiting nutrients that this member takes up 
                limiting_nutrients = [uptake_rxn.reactants[0] for shared_cmp in self.shared_compounds for uptake_rxn in shared_cmp.reactant_reactions if uptake_rxn in member.reactions]
                mu_death = death_rate(limiting_nutrients = limiting_nutrients,ms_biomassYield_calc = False, wildType_max_biomass = member.wildType_max_biomass, screen_output = 'off') 
                member.organism.mu[self._t] = mu_death + member.organism.mortality_rate

                # Set the flux of all reactions (including export reactions for shared compounds)
                # to zero
                for r in member.reactions:
                    r.flux[self._t] = 0

    def update_concentrations_batch(self):
        """ 
        Updates cell concentrationns and the concentration of extracellular compounds
        for a batch reactor 
        """  
        #--- Update the cell concentrations ---
        # dX_i/dt = mu_i*(X_i - sum(i,X(i))/carrying_capacity) or 
        # (X_i(t+dt) - X_i(t))/dt = mu*(X_i(t) - sum(i,X_i(t))/carrying_capacity)
        # If concentration is negative set it to zero
        members_gDW_per_mL_total = sum([member.organism.gDW_per_mL[self._t] for member in self.community_members])
        if len([member for member in self.community_members if member.organism.cells_per_mL != None]) == len(self.community_members):
            members_cells_per_mL_total = sum([member.organism.cells_per_mL[self._t] for member in self.community_members])
        for member in self.community_members:
            # We always need gDW_per_mL to update compound concentrations but
            # providing cells_per_mL is optional
            member.organism.gDW_per_mL[self._t + self._dt] = max(member.organism.mu[self._t]*(member.organism.gDW_per_mL[self._t] - members_gDW_per_mL_total/self.carrying_capacity_gDW_per_mL)*self._dt + member.organism.gDW_per_mL[self._t],0)

            if member.organism.cells_per_mL is not None:
                member.organism.cells_per_mL[self._t + self._dt] = max(member.organism.mu[self._t]*(member.organism.cells_per_mL[self._t] - members_cells_per_mL_total/self.carrying_capacity_cells_per_mL)*self._dt + member.organism.cells_per_mL[self._t],0)

        #--- Update shared compound concentrations ---
        # dC/dt = f where, f = sum(k,v_export_k*X_k) - sum(k,v_uptake_k*X_k)
        # (C(t+dt) - c(t))/dt = sum(k,v_export_k*X_k) - sum(k,v_uptake_k*X_k)
        self.f = dict([(cmp,None) for cmp in self.shared_compounds])
        for shared_cmp in self.shared_compounds:
            f = sum([r.flux[self._t]*r.model.organism.gDW_per_mL[self._t] for r in shared_cmp.reactions])
            self.f[shared_cmp] = f

            # if concentration at the previous time piont is zero (allow for a teolerance of 1e-9)
            # and f < 0 then c(t+dt) = f*dt < 0 and c(t+dt) should be set to zero
            if abs(shared_cmp.concentration[self._t]) <= 1e-9 and f < 0:
                conc = 0
            else:
                conc = f*self._dt + shared_cmp.concentration[self._t]

            if conc >= 0 or (conc < 0 and abs(conc) <= 1e-9):
                conc = max(conc,0)

            # If the concentration is negative and the time to reach a zero concentration is too 
            # small (this happens when you have two many cells consuming a very low concentration of
            # that compound), then set the concentration to zero.
            # The time to reach a zero concentration is found as follows:
            # C(t + dt) = f*dt + C(t) = 0  ==> dt = (0 - C(t))/f
            #elif conc < 0 and (0 - shared_cmp.concentration[self._t])/f > 0 and (0 - shared_cmp.concentration[self._t])/f <= 1e-5:
            #    conc = 0

            shared_cmp.concentration[self._t + self._dt] = conc


    def create_dt_frac(self):
        """
        This function creates the fractional time intervals to avoid getting 
        negative concentrations. This is done by divding the original time 
        interval into smaller ones, if any of the compound concentrations turns out 
        to be negative. This information is stored in dt_zero_conc. For example, the 
        original dt could be one, and dt's stored in dt_zero_conc can be 0.3 and 0.7. 
        Then we should do one simulation with a dt of 0.3, a second simulation with 
        dt of 0.7 - 0.3 = 0.4 and a last simulation with dt of 1 - 0.7 = 0.3
        """
        # A dictionary with keys and values as follows:
        #   Keys: compounds that get a negative concentration upon update
        # Values: The time interval needed for the concentration of compounds 
        #         to become zero
        dt_zero_conc = {}

        for shared_cmp in [cmp for cmp in self.shared_compounds if cmp.concentration[self._t + self._dt] < 0]:
            # find the time interval needed to get a zero concentration
            # C(t + dt) = f*dt + C(t) = 0  ==> dt = (0 - C(t))/f
            dt_zero_conc_curr = (0 - shared_cmp.concentration[self._t])/self.f[shared_cmp]
    
            if dt_zero_conc_curr < 0:
                raise userError('\nNegative dt for compound ' + shared_cmp.id + '  (dt = ' + str(dt_zero_conc_curr) + '  conc(t) = ' + str(conc) + '  f = ' + str(f) + '\n')
            elif dt_zero_conc_curr > self._dt:
                raise userError('The obtained modified dt for the shared compound ' + shared_cmp.id + ' (dt = ' + str(dt_zero_conc_curr) + ') is smaller than the original time interval (dt = ' + str(self._dt) + ')')
            else:
                dt_zero_conc[shared_cmp.id] = dt_zero_conc_curr

        # Add zero and the original dt to the list and sort it
        #**all_dts = sorted(dt_zero_conc.keys() + [0,self._dt])
        dt_zero_conc['start'] = 0
        dt_zero_conc['end'] = self._dt
 
        # Find out smaller dt's required for simulations (a fraction of the original dt)
        dt_zero_conc_sorted = sorted(dt_zero_conc.values())
        self.dt_fracs = [dt_zero_conc_sorted[i] - dt_zero_conc_sorted[i-1] for i in range(1,len(dt_zero_conc))]

        if self.screen_output.lower() == 'on':
            print 'Redoing simulations by dividng the original time interval into smaller ones to avoid getting a negative concentration ...'
            print '\tdt_zero_conc = ',dict([(shared_cmp,dt_zero_conc[shared_cmp]) for shared_cmp in dt_zero_conc.keys()]),'\n'
            print '\tdt_fracs = ',dict([([k for k in dt_zero_conc.keys() if dt_zero_conc[k] == dt_zero_conc_sorted[i]][0],dt_zero_conc_sorted[i] - dt_zero_conc_sorted[i-1]) for i in range(1,len(dt_zero_conc))]) 

    def update_time(self):
        """
        This function updates the time point
        """   
        # Shared compounds with negative concentrations
        negative_conc_comps = [(shared_cmp.id,shared_cmp.concentration[self._t + self._dt]) for shared_cmp in self.shared_compounds if shared_cmp.concentration[self._t + self._dt] < 0]

        # Update time, if there is no negative concentrations
        if len(negative_conc_comps) == 0:
            self._t += self._dt
            if self.screen_output.lower() == 'on':
                print 't = ',self._t

            #--- Sepcify the correct dt for the next time step, if needed ---
            if not hasattr(self,'dt_fracs') or len(self.dt_fracs) == 0:
                self._dt = self._dt_orig

            # If the current fractional dt has already been examined remove it 
            # from dt_fracs
            elif len(self.dt_fracs) > 0 and self._dt in self.dt_fracs:
                del self.dt_fracs[self.dt_fracs.index(self._dt)]
                if len(self.dt_fracs) > 0:
                    self._dt = self.dt_fracs[0]
                else:
                    self._dt = self._dt_orig

            elif len(self.dt_fracs) > 0 and self._dt not in self.dt_fracs:
                 raise userError('Unknown dt (dt = ' + str(self._dt) + ') not in dt_fracs = ' + str(self.dt_fracs))

        # Otherwise find the fractional time points
        else:
            # If we already work with fractional dt no concentrations should
            # become negative
            if self._dt != self._dt_orig:
                raise userError('Negative concentration observed for even though working with fractional dt:' + str(negative_conc_comps)) 
               
            # Otherwise create fractional dt's
            else:
                self.create_dt_frac()

            # First remove all previously computed values for self._t + self._dt
            for member in self.community_members:
                del member.organism.cells_per_mL[self._t + self._dt] 
                del member.organism.gDW_per_mL[self._t + self._dt] 

            for shared_cmp in self.shared_compounds:
                 del shared_cmp.concentration[self._t + self._dt] 

            # Use dt_frac instead of dt_orig
            self._dt = self.dt_fracs[0]

    def dilute(self):
        """ 
        Performs dilution (used when reactor_type is serial_dilution 
        """ 
        #--- Cell concentrations are divided by the dilution factor ---
        for member in self.community_members:
            member.organism.gDW_per_mL[self._t] = member.organism.gDW_per_mL[self._t]/self.serial_dilution_params['dilution_factor']
            if member.organism.cells_per_mL is not None:
                member.organism.cells_per_mL[self._t] = int(member.organism.cells_per_mL[self._t]/self.serial_dilution_params['dilution_factor']) 

        #--- shared metabolite concentrations are set to those at the initial time point ---
        for shared_cmp in self.shared_compounds:
            shared_cmp.concentration[self._t] = shared_cmp.concentration[self._t0]

    def run_batch(self):
        """ 
        This function runs dynamic FBA ssimulations for a batch culture 
        """
        while self._t < self._tf:
            # Compute the upper bound on the uptake rates of 
            # the shared compounds using kinetic expressions
            self.uptake_rate_UB_calc()

            # Update the fba model for the initial point
            self.update_fba_model()

            # Compute the specific growth rate (mu) for each species using FBA 
            # as well as the export rates 
            self.mu_uptake_export_calc()

            # Update concentrations in the next time point 
            self.update_concentrations_batch()

            # Update time
            self.update_time()

    def run_serial_dilution(self):
        """ 
        This function runs dynamic FBA ssimulations for a batch culture with serial dilutions 
        """
        # Time points where dilutioning is performed. The final time should not be included. 
        # For example, if t0 = 0, tf = 118 h and 
        # serial_dilution_params['time_between_dilutions'] = 24 h, then 
        # dilution_times = [34, 58, 82, 106]. dilution_times may or may not include the last time point
        self._dilution_times = [self._t0 + self.serial_dilution_params['time_between_dilutions']*f for f in range(1,int((self._tf - self._t0)/self.serial_dilution_params['time_between_dilutions']) + 1)]
        if self._tf in self._dilution_times:
            del self._dilution_times[self._dilution_times.index(self._tf)]
         

        while self._t < self._tf:
            # Perform dilutioning
            # The second condition imposed in the following abs(t - self._t) <= 1e-6 is to take care of cases
            # where we make an adjustment to delta_t and self._t may not be exactly equal to the time points 
            # in self._dilution_times
            #if self._t in self._dilution_times or len([t for t in self._dilution_times if abs(t - self._t) <= 1e-6]) == 1:
            if self._t in self._dilution_times:
                if self.screen_output.lower() == 'on':
                    print '\tDilutioning at time t = {} ...'.format(self._t)
                self.dilute()

            # Compute the upper bound on the uptake rates of 
            # the shared compounds using kinetic expressions
            self.uptake_rate_UB_calc()

            # Update the fba model for the initial point
            self.update_fba_model()

            # Compute the specific growth rate (mu) for each species using FBA 
            # as well as the export rates 
            self.mu_uptake_export_calc()

            # Update concentrations in the next time point 
            self.update_concentrations_batch()

            # Update time
            self.update_time()

    def run_life_cycle(self):
        """ 
        This function runs dynamic FBA ssimulations for microbial life cycle 
        """
        pass

    def run_chemostat(self):
        """ 
        This function runs FBA ssimulations for a chemostat 
        """
        pass

    def run(self):
        """ 
        This function runs the dynamic ssimulations. 
        """

        if self.screen_output == 'on':
            print 'Start running DMMM ...'

        start_DMMM = time.clock()

        self._t = self._t0

        # Original delta_t 
        self._dt_orig = self._dt

        if self.reactor_type.lower() == 'batch':
            self.run_batch()
        elif self.reactor_type.lower() == 'serial_dilution':
            self.run_serial_dilution()
        elif self.reactor_type.lower() == 'life_cycle':
            self.run_life_cycle()
        elif self.reactor_type.lower() == 'chemostat':
            self.run_chemostat()

        # Compute the update rates and mu at the last time point in case they are 
        # needed to be reported 
        self.uptake_rate_UB_calc()
        self.update_fba_model()
        self.mu_uptake_export_calc()

        # Elapsed time to run DMMM
        elapsed_DMMM = time.clock() - start_DMMM

        if self.screen_output.lower() == 'on':
           print '\nelapsed time (sec) for DMMM = ',elapsed_DMMM,'\n'

#---------- Test DMMM ---------------
if __name__ == "__main__":
    from copy import deepcopy
    from tools.io.read_sbml_model import read_sbml_model
    from set_specific_bounds import set_specific_bounds

    # Increse the recursion limit, otherwise deepcopy will complain
    sys.setrecursionlimit(10000)

    # Model path
    model_path = '/data/alizom/models/Escherichia_coli/iAF1260/'

    # Define the organism
    model_organism = organism(id = 'Ecoli', name = 'Escherichia coli',domain = 'Bacteria', genus = 'Escherichia', species = 'coli', strain = 'MG1655')

    iAF1260 = read_sbml_model(file_name = model_path + 'iAF1260_updated.xml', model_id = 'iAF1260',model_organism = model_organism,model_type = 'metabolic')
    
    #--- E. coli iAF1260 model ---
    print '\n--- Wild-type E.coli (iAF1260 model) ----'
    iAF1260.biomass_reaction = iAF1260.get_reactions({'Ec_biomass_iAF1260_core_59p81M':'id'}) 
    iAF1260.all_biomass_reactions = {'core':iAF1260.get_reactions({'Ec_biomass_iAF1260_core_59p81M':'id'}),'WT':iAF1260.get_reactions({'Ec_biomass_iAF1260_WT_59p81M':'id'})} 
    iAF1260.organism.gDW_per_cell = 2.8e-13
 
    # Assign a general Michaelis-Menten type uptake kinetics to all exchange reactions
    # Example: EX_glc(E): glc__D_e <==>    Vmax*C['glc__D_e']/(Km + C['glc__D_e']) 
    # Use a Vmax value of 10 mmole/gDW.h and a Km value of 10 micro-M 
    for reaction in [r for r in iAF1260.reactions if r.type.lower() == 'exchange']:
        # The id of compound participating in the exchange reaction
        metab_id = [m.id for m in reaction.compounds][0]
        reaction.kinetics = "10*C['" + metab_id + "']/(10 + C['" + metab_id + "'])"

    # Glucose uptake kinetics 
    exch_rxns = iAF1260.get_reactions({'EX_glc(e)':'id','EX_lys_L(e)':'id','EX_ile_L(e)':'id'})
    exch_rxns['EX_glc(e)'].kinetics = "10*C['glc__D_e']/(0.15 + C['glc__D_e'])"
    exch_rxns['EX_lys_L(e)'].kinetics = "0.1964*C['lys__L_e']/(5e-4 + C['lys__L_e']) + 0.3055*C['lys__L_e']/(1e-2 + C['lys__L_e'])"
    exch_rxns['EX_ile_L(e)'].kinetics = "0.0346*C['ile__L_e']/(1.22e-3 + C['ile__L_e'])"
   
    # Growth medium
    set_specific_bounds(model = iAF1260,file_name = model_path + 'iAF1260_minimal_glucose_aerobic.py',simulation_condition = 'minimal_glucose_aerobic')

    # Assign and objective function coefficients
    for rxn in iAF1260.reactions:
        rxn.objective_coefficient = 0
    iAF1260.biomass_reaction.objective_coefficient = 1

    # Perform FBA for the wild-type
    iAF1260.fba(assign_wildType_max_biomass = True)

    # Compute ms and biomass yield for glucose
    glc_D = iAF1260.get_compounds({'glc__D_e':'id'})
    glc_D.ms_calc() 
    glc_D.biomass_yield_calc() 
    print '\n  **glc-D ms = ',glc_D.ms
    print '  **glc-D biomass yield = ',glc_D.biomass_yield,'\n'
    # Check if the bounds and objective function were set back to original values
    # after calculating ms and biomass yield
    iAF1260.fba()

    #--- DMMM for the co-culture of lysA and ilvE mutants ---
    print '\n--- lysA mutant ----'
    # lysA mutant and related reaction whose flux should be set to zero 
    iAF1260_lysA = deepcopy(iAF1260)
    iAF1260_lysA.organism.id = 'lysA_Ecoli'
    iAF1260_lysA.organism.cells_per_mL = {0:7.5e6}
    iAF1260_lysA.organism.gDW_per_mL = {0:7.5e6*iAF1260_lysA.organism.gDW_per_cell}
    DAPDC = iAF1260_lysA.get_reactions({'DAPDC':'id'})
    DAPDC.flux_bounds = [0,0]
    iAF1260_lysA.fba(create_model = False)
    # Compute ms and biomass yield for lys_L
    lys_L = iAF1260_lysA.get_compounds({'lys__L_e':'id'})
    lys_L.ms_calc()    
    lys_L.biomass_yield_calc()    
    print '\n  **lys_L ms = ',lys_L.ms
    print '  **lys_L biomass yield = ',lys_L.biomass_yield,'\n'
    # Check if the bounds and objective function were set back to original values
    # after calculating ms and biomass yield
    iAF1260_lysA.fba()

    print '\n**Test cooperative behavior ....'
    for rxn in iAF1260_lysA.reactions:
        rxn.objective_coefficient = 0
    iAF1260_lysA.get_reactions({'EX_ile_L(e)':'id'}).objective_coefficient = 1
    iAF1260_lysA.fba(create_model = False)
    iAF1260_lysA.biomass_reaction.objective_coefficient = 1

    # ilvE mutant and related reaction whose flux should be set to zero 
    print '\n--- ilvE mutant ----'
    iAF1260_ilvE = deepcopy(iAF1260)
    iAF1260_ilvE.organism.id = 'ilvE_Ecoli'
    iAF1260_ilvE.organism.cells_per_mL = {0:7.5e6}
    iAF1260_ilvE.organism.gDW_per_mL = {0:7.5e6*iAF1260_ilvE.organism.gDW_per_cell}
    ILETA = iAF1260_ilvE.get_reactions({'ILETA':'id'})
    VALTA = iAF1260_ilvE.get_reactions({'VALTA':'id'})
    ILETA.flux_bounds = [0,0]
    VALTA.flux_bounds = [0,0]
    iAF1260_ilvE.fba(create_model = False)
    # Compute ms and biomass yield for ile_L
    ile_L = iAF1260_ilvE.get_compounds({'ile__L_e':'id'})
    ile_L.ms_calc()    
    ile_L.biomass_yield_calc()    
    print '\n  **ile_L ms = ',ile_L.ms
    print '  **ile_L biomass yield = ',ile_L.biomass_yield,'\n'
    # Check if the bounds and objective function were set back to original values
    # after calculating ms and biomass yield
    iAF1260_ilvE.fba()

    print '\n**Test cooperative behavior ....'
    for rxn in iAF1260_ilvE.reactions:
        rxn.objective_coefficient = 0
    iAF1260_ilvE.get_reactions({'EX_lys_L(e)':'id'}).objective_coefficient = 1
    iAF1260_ilvE.fba(create_model = False)
    iAF1260_ilvE.get_reactions({'EX_lys_L(e)':'id'}).objective_coefficient = 0
    iAF1260_ilvE.biomass_reaction.objective_coefficient = 1

    # --- Define the compounds available in the extracellular medium ---
    # These compounds include glucose, arg-L and ile_L
    # Glucose
    exch_rxns_lysA = iAF1260_lysA.get_reactions({'EX_glc(e)':'id','EX_lys_L(e)':'id','EX_ile_L(e)':'id'}) 
    exch_rxns_ilvE = iAF1260_ilvE.get_reactions({'EX_glc(e)':'id','EX_lys_L(e)':'id','EX_ile_L(e)':'id'}) 

    # Glucose as a shared compound (concentration in mM)
    glucose = compound(id = 'glc-D', name = 'D-Glucose', Kegg_id = 'C00031', reactant_reactions = [exch_rxns_lysA['EX_glc(e)'],exch_rxns_ilvE['EX_glc(e)']],reactions = [exch_rxns_lysA['EX_glc(e)'],exch_rxns_ilvE['EX_glc(e)']],concentration = {0:111.01})    
    # Lysine as a shared compound (concentration in mM)
    lys_L = compound (id = 'lys_L',name = 'L-Lysine', Kegg_id = 'C00047', reactant_reactions = [exch_rxns_lysA['EX_lys_L(e)']],product_reactions = [exch_rxns_ilvE['EX_lys_L(e)']], concentration = {0:1e-5}) 
   
    # Isoleucine as a shared compound (concentration in mM)
    ile_L = compound(id = 'ile_L', name = 'L-Isoleucine' , Kegg_id = 'C00407', reactant_reactions = [exch_rxns_ilvE['EX_ile_L(e)']], product_reactions = [exch_rxns_lysA['EX_ile_L(e)']], concentration = {0:1e-5})

    DMMM_test = DMMM(community_members = [iAF1260_lysA,iAF1260_ilvE],shared_compounds = [glucose,lys_L,ile_L],time_range = [0,0.5,10],reactor_type = 'batch',screen_output = 'on')
    #DMMM_test = DMMM(community_members = [iAF1260_lysA,iAF1260_ilvE],shared_compounds = [glucose,lys_L,ile_L],time_range = [0,1.0,96],reactor_type = 'serial_dilution',serial_dilution_params = {'dilution_factor':1000,'time_between_dilutions':24},screen_output = 'on')
    DMMM_test.run()
   
    # Print results in the output
    for t in sorted(glucose.concentration.keys()):
        print 't = ',t,
        for member in [iAF1260_lysA,iAF1260_ilvE]:
            print '  X(',member.organism.id,') = ',member.organism.cells_per_mL[t],

        for shared_cmp in [glucose,lys_L,ile_L]:
            print '   C(',shared_cmp.id,') = ',shared_cmp.concentration[t],

        print '\n'

