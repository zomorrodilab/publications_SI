from __future__ import division
import sys, time
sys.path.append('../../')
from coopr.pyomo import *
from coopr.opt import *
from coopr.environ import *
from tools.pyomoSolverCreator import *
from tools.userError import userError
from tools.core.compound import compound
from tools.core.reaction import reaction

# The following lines change the temporary directory for pyomo
from pyutilib.services import TempfileManager
TempfileManager.tempdir = '/tmp/'

class fbaTools(object):
    """
    A general class for performing various types of FBA methods (FBA, FVA, MOMA, etc) 

    Ali R. Zomorrodi - Segre Lab @ Boston University
    Last updated: 12-07-2015 
    """   

    def __init__(self,model, optimization_solver = 'gurobi', build_new_optModel = True, flux_key = None, store_opt_fluxes = True, stdout_msgs = True, simulation_conditions = None, warnings = True,  **additional_args): 
        """
        INPUTS (required):
        ------
                      model: An instance of class model containing the information
                             about the metabolic model

        INPUTS (optional):
        ------
        optimization_solver: Name of the LP solver to be used to solve the LP. Current 
                             allowable choices are cplex and gurobi
                stdout_msgs: By default (on) writes  a summary including the solve 
                             status, optimality status (if not optimal), objective 
                             function value and the elapsed time on the screen.
                             if set to a value of 'off' no resuults are written on 
                             the screen, in which case The user can instead specifiy 
                             an output fiile using the option outputFile, or store 
                             them in the variable solution (see the 'run' method for
                             details)
         build_new_optModel: A parameter indicating whether a new pyomo optimizaiton model should be 
                             created (True) or or an existing one should be used (False). The options is useful
                             for the cases a model is already created and one just 
                             wants to change some model attributes (e.g., flux bounds)
                             and rerun FBA. Setting this parameter to False will save 
                             some runtime as the model need not to be created again.
                   flux_key: Optimal reaction fluxes after performing FBA are saved into
                             reaction.flux where reaction is the reaction object in the 
                             input model. If flux key is provided, then reaction fluxes 
                             are stored reaction.flux, but reaction.flux in this case is
                             a dictionary instead of a scalar and the current flux value
                             is stored in the dictionary with the key specified by flux_key.
                             This is useful, for example, when performing dynamic FBA,
                             where fluxes should be stored for each time, e.g.,
                             reaction.flux = {0:0.25,0.5:0.24,...}, where keys are tiime points
                             and values are fluxes
           store_opt_fluxes: If True, it sets the value of store_flux for all reactions to True 
                             and the optimal values of reaction fluxes are stored in 
                             field 'flux' of reaction objects. If False, the optimal
                             values of fluxes are stored only for reactions for which store_flux is
                             True. The latter case is useful when one is interested only in the
                             optimal value of the objective function or those of certain reaction fluxes 
        simulation_conditions: A string describing simulation conditions
                   warnings: Can be True or False shwoing whether the warnings should be writtten to the 
                             screen or not. The default is True  
                stdout_msgs: Prints a summary of the FBA and a number of other messages in the output if 'on.
                             Eligible values are True and False and the default is True 
            additional_args: Additional arguments should be entered as normal but they are 
                             converted to a dictionary whose keys are the names of the arguments and 
                             values are the values of  those arguments

        OUTPUTS:
        ---------
        solution: A dictionary with the following keys:
                  exit_flag: A string, which can be 'globallyOptimal', 'solverError'
                            or what is stored in OptSoln.solver.termination_condition
                  objValue: Optimal objective funtion value

        Optimal flux values are stored directly into the 'flux' field of the reaction
        objects. The value of the flux will be None if the problem is not solved to 
        optimality. 

        These are the outputs of the method 'run'
        """
       
        # Metabolic model
        self.model = model

        # Solver name
        self.optimization_solver = optimization_solver

        # Whether to create a pyomo model
        self.build_new_optModel = build_new_optModel
               
        # Warnings and messages in the standard output
        self.stdout_msgs = stdout_msgs
        self.warnings = warnings

        # flux_key
        self.flux_key = flux_key 

        # store_opt_fluxes
        self.store_opt_fluxes = store_opt_fluxes
        if self.store_opt_fluxes:
            for rxn in model.reactions:
                rxn.store_flux = True 

        # Simulation conditions
        self.simulation_conditions = simulation_conditions

        # Additoinal arguments. Additional arguments should be entered as normal but they are 
        # converted to a dictionary whose keys are the names of the arguments and values are 
        # the values of  those arguments
        argnames = additional_args.keys()
        argvals = additional_args.values()
        for argname in argnames:
           exec "self." + argname + " = " +"additional_args['" + argname + "']"

    def check_attr(self,attr_name,attr_value):
        """
        Checks the conditions on the class attributes
 
        INPUTS:
        -------
         attr_name: Attribute name
        attr_value: Attribute vlaue
        """
        # Solver name
        if attr_name == 'optimization_solver' and attr_value.lower() not in ['cplex','gurobi']:
            raise userError('Invalid solver name (eligible choices are cplex and gurobi)\n')

        # Simulation conditions name
        if attr_name == 'simulation_conditions' and (attr_value is not None and not isinstance(attr_value,str)): 
            raise userError('Invalid simulation_conditions for fba model. simulation_conditions must be a striing')

        # Warnings and messages in the standard output
        if attr_name == 'build_new_optModel' and not isinstance(attr_value,bool):
            raise TypeError("build_new_optModel must be either True or False")

        # Warnings and messages in the standard output
        if attr_name == 'stdout_msgs' and not isinstance(attr_value,bool):
            raise TypeError("stdout_msgs must be either True or False")

        if attr_name == 'warnings' and not isinstance(attr_value,bool):
            raise TypeError("warnings must be either True or False")

    def __setattr__(self,attr_name,attr_value):
       """
       Redefines funciton __setattr__
       INPUTS:
       -------
       attr_name: Attribute name
       attr_value: Attribute value
       """
       if attr_name in ['model','optimization_solver','build_new_optModel','flux_key','store_opt_fluxes','simulation_conditions','stdout_msgs','warnings']:
           self.check_attr(attr_name,attr_value)
       self.__dict__[attr_name] = attr_value

    def objectiveFunc_rule(self,optModel):
        """
        Objective function
        """
        pass

    def assignFluxBounds(self,optModel,j):
        """
        Define the flux bounds
        """
        return j.flux_bounds 
        
    def massBalance_rule(self,optModel,i):
        """
        Mass balance 
        """
        return sum(j.stoichiometry[i]*optModel.v[j] for j in i.reactions) == 0 
        
    def build_optModel(self):
        """
        This optModel creates a pyomo model for FBA optModel
        """   
        #--- Create a pyomo model optModel ---
        optModel = ConcreteModel()
        
        #--- Define sets ---
        # Set of compounds 
        optModel.I = Set(initialize = self.model.compounds)   

        # Set of rxns  
        optModel.J = Set(initialize = self.model.reactions)     

        #--- Define the optModel variables --- 
        optModel.v = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)
        
        #--- Defiine the objective function and constraints ----
         # Objective function
        optModel.objectiveFunc = Objective(rule=self.objectiveFunc_rule, sense = maximize)

        # Mass balance 
        optModel.massBalance_const = Constraint(optModel.I, rule=self.massBalance_rule)

        self.optModel = optModel 
    
    def run(self):
        """ 
        This method runs the FBA tool. 

        OUTPUT:
        -------
        solution: A dictionary with the following keys:
                        exit_flag: A string, which can be 'globallyOptimal', 'solverError'
                                   or what is stored in OptSoln.solver.termination_condition
                  objective_value: Optimal objective funtion value

        Optimal flux values are stored directly into the 'flux' field of the reaction
        objects. The value of the flux will be None if the problem is not solved to 
        optimality. 
        """

        # Total processing and wall time required to create the pyomo model, solve it and store the results
        start_total_pt = time.clock()
        start_total_wt = time.time()

        #---- Creating and instantiating the optModel ----
        start_pyomo_pt = time.clock()
        start_pyomo_wt = time.time()

        # Create the pyomo model optModel only if self.build_new_optModel == 1        
        if self.build_new_optModel:
            self.build_optModel()

        # Instantiate the optModel
        self.optModel.preprocess()

        #---- Solve the model ----
        # Create a solver and set the options
        solverType = pyomoSolverCreator(self.optimization_solver)

        elapsed_pyomo_pt = (time.clock() - start_pyomo_pt)
        elapsed_pyomo_wt = (time.time() - start_pyomo_wt)

        #- Solve the optModel (tee=True shows the solver output) -
        try:
            # Time to solve the model
            start_solver_pt = time.clock()
            start_solver_wt = time.time()
            OptSoln = solverType.solve(self.optModel,tee=False)
            solverFlag = 'normal'

        # In the case of an error switch the solver
        except  Exception, e:
            if self.warnings:
                print '**WARNING (fba.py)! {} failed with the following error: \n{} \nAn alternative solver is tried'.format(self.optimization_solver,e)

            if self.optimization_solver.lower() == 'gurobi':
                self.optimization_solver = 'cplex'
            elif self.optimization_solver.lower() == 'cplex':
                self.optimization_solver = 'gurobi'

            # Try solving with the alternative solver
            solverType = pyomoSolverCreator(self.optimization_solver)
            try:
                start_solver_pt = time.clock()
                start_solver_wt = time.time()
                OptSoln = solverType.solve(self.optModel,tee=False)
                solverFlag = 'normal'
            except   Exception, e:
                solverFlag = 'solverError'
                if self.warnings:
                    print '**WARNING (fba.py)! {} failed with the following error: \n{} \nAn alternative solver is tried'.format(self.optimization_solver,e)

        elapsed_solver_pt = (time.clock() - start_solver_pt)
        elapsed_solver_wt = (time.time() - start_solver_wt)

        #----- Print the results in the output ------
        if solverFlag == 'normal' and str(OptSoln.solver.termination_condition).lower() == 'optimal':
        
            exit_flag = 'globallyOptimal'

            # Load the results
            self.optModel.load(OptSoln)
        
            # Value of the objective function
            opt_objValue = self.optModel.objectiveFunc()

            # Print the results on the screen 
            if self.stdout_msgs:
                print "\nSolver.status = ",OptSoln.solver.termination_condition
                print "Optimality status = ",exit_flag
                print "Objective value = ",opt_objValue

            # Store the optimal flux values in the variable 'flux' of the reaction objects
            for rxn in [r for r in self.model.reactions if r.store_flux]:
                if self.flux_key is None:
                    rxn.flux = self.optModel.v[rxn].value
                elif self.flux_key is not None and type(rxn.flux) is dict:
                    rxn.flux[self.flux_key] = self.optModel.v[rxn].value
                else:
                    rxn.flux = {}
                    rxn.flux[self.flux_key] = self.optModel.v[rxn].value

            # Set the flux of any reaction whose store_flux is False to None. This is needed as somethimes
            # the flux values are stored from a previous run of fba and might be confused with the results of
            # the current fba problem
            for rxn in [r for r in self.model.reactions if not r.store_flux]:
                r.flux = None

        # If there was a solver error or if an optimal solution was not returned 
        else:
            if solverFlag == 'solverError':
                exit_flag = solverFlag
            else:
                exit_flag = str(OptSoln.solver.termination_condition)

            opt_objValue = None 

            if self.stdout_msgs:
                print "\n\n** No optimal solutions found (solution.solver.status = ",OptSoln.Solution.status,", solver.status =",OptSoln.solver.status,", solver.termination_condition = ",OptSoln.solver.termination_condition,")\n"

            for rxn in [r for r in self.model.reactions if r.store_flux == True]:
                if self.flux_key is None and type(rxn.flux) is not dict:
                    rxn.flux = None 
                elif self.flux_key is not None and type(rxn.flux) is dict:
                    rxn.flux[self.flux_key] = None 
                else:
                    rxn.flux = {}
                    rxn.flux[self.flux_key] = None 

        self.solution = {'exit_flag':exit_flag,'objective_value':opt_objValue}

        # Time required to perform FBA
        elapsed_total_pt = (time.clock() - start_total_pt)
        elapsed_total_wt = (time.time() - start_total_wt)

        if self.stdout_msgs:
           print 'FBA elapsed (processing/wall) time (sec): pyomo = {:.3f}/{:.3f}  ,  solver = {:.3f}/{:.3f}  ,  Total = {:.3f}/{:.3f}\n'.format(elapsed_pyomo_pt,elapsed_pyomo_wt,elapsed_solver_pt,elapsed_solver_wt,elapsed_total_pt,elapsed_total_wt)

        return self.solution

#----------- Sample implementation -----------------
if __name__ == "__main__":
    pass 
