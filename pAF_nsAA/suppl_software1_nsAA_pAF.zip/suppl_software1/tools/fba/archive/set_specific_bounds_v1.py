from __future__ import division
import sys
sys.path.append('../../')
from tools.userError import userError
from tools.core.compound import compound 
from tools.core.reaction import reaction
from tools.core.model import model
from models import *
from imp import load_source


def set_specific_bounds(model, excess_nutrients = {}, limiting_nutrients = {}, trace_nutrients = {}, ngam_atp = {} , regulation = {}, experimental_meas = {}, others = {}, all_specific_bounds = {}, file_name = None, simulation_condition = None, reset_flux_bounds = True): 
    """
    A function to read a gams growth medium information stored 
    in python-formatted and then to convert it into the format 
    that we need

    INPUTS:
    ------
                  model: A model object

    The rest of the inputs should be in the form of a dicntionary with reaciton ids
    as keys and a list {LB,UB} containing the lower and upper bounds on reactions
        excess_nutrients: Exchange reactions for nutrients available in the meidum
                          in excess amounts 
     limitting_nutrients: Exchange reactions for limitting nutrients
         trace_nutrients: Exchange reactions for nutrients available in trace amounts 
                ngam_atp: Non-growth associated maintenance ATP
              regulation: Reactions affected due to regulaiton under this specifc medium 
       experimental_meas: Reactions with experimental flux measurements 
                  others: Other reacitons with specific flux bounds
     all_specific_bounds: The useer has the option of providing all specific flux bounds in 
                          a single field called medium_flux_bounds
        file_name: A file name containing the same data that can be provided as an 
                          input to the function. Note that if the smae field that is the 
                          input file is assigned as the input to the function,  then the 
                          latter overwrites those in the input file
    simulation_condition: Name of the simulation condition (string)
       reset_flux_bounds: Resets the flux bonds to default if True

    Ali R. Zomorrodi - Segre Lab @ BU
    Last updated: 07-13-2015
    """
    # First reset all reaction bounds
    if reset_flux_bounds:
        model.restore_flux_bounds()

    # Next, check if all general flux bounds have been assigned
    non_bound_rxns = [r for r in model.reactions if r.flux_bounds == None]
    if len(non_bound_rxns) > 0:
        raise ValueError('**Error! General flux bounds have not been assigned from the following reactions:' + str(non_bound_rxn))

    # Import the data in the module stored in file_name
    if type(file_name) == str:
        load_source('dataFile',file_name)
        import dataFile 

        if 'excess_nutrients' in dir(dataFile):
             excess_nutrients = dataFile.excess_nutrients
        if 'limiting_nutrients' in dir(dataFile):
             limiting_nutrients = dataFile.limiting_nutrients
        if 'trace_nutrients' in dir(dataFile):
             trace_nutrients = dataFile.trace_nutrients
        if 'ngam_atp' in dir(dataFile):
             ngam_atp = dataFile.ngam_atp
        if 'regulation' in dir(dataFile):
             regulation = dataFile.regulation
        if 'experimental_meas' in dir(dataFile):
             experimental_meas = dataFile.experimental_meas
        if 'others' in dir(dataFile):
             others = dataFile.others
        if 'all_specific_bounds' in dir(dataFile):
             all_specific_bounds = dataFile.all_specific_bounds

        # Check if there are additional items stored in the file
        additional = [m for m in dir(dataFile) if m not in ['__builtins__', '__doc__', '__file__', '__name__', '__package__', 'excess_nutrients', 'limiting_nutrients','trace_nutrients','ngam_atp','regulation','experimental_meas','others','all_specific_bounds']]
        if len(additional) > 0:
            print 'The following additional data are in the data file. They should be commented out ...',additional
            raise userError()

    # Inputs of the function
    if all_specific_bounds == {}:
        # Combine all dictionaries into one 
        all_specific_bounds = dict(excess_nutrients.items() + limiting_nutrients.items() + trace_nutrients.items() + ngam_atp.items() + regulation.items() + experimental_meas.items() + others.items())

    for rxn_id in all_specific_bounds.keys(): 
        rxn = model.get_reactions({rxn_id:'id'})
        if rxn == None:
            raise ValueError('Reaction ' + rxn_id + ' was not found in the model.')
        else:
            rxn.flux_bounds = all_specific_bounds[rxn_id]
 
    model.simulation_condition = simulation_condition



