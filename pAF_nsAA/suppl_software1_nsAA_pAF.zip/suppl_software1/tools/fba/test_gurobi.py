from __future__ import division
from pyomo.environ import *
from pyomo.opt import *

if __name__ == "__main__":

    # Define an optimization problem
    # This is an example given in section 4.5 of pyomo manual at
    # https://software.sandia.gov/downloads/pub/pyomo/PyomoOnlineDocs.html#_a_simple_concrete_pyomo_model
    model = ConcreteModel()

    model.x = Var([1,2], domain=NonNegativeReals)

    model.OBJ = Objective(expr = 2*model.x[1] + 3*model.x[2], sense = minimize)

    model.Constraint1 = Constraint(expr = 3*model.x[1] + 4*model.x[2] >= 1)
    
    # Create pyomo solver object
    #optSolver = SolverFactory('cplex')
    optSolver = SolverFactory('gurobi')

    # Solve the optimization problem
    optSolver.solve(model, tee = True)

