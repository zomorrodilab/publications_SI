from __future__ import division
import sys,os, time
sys.path.append('../../../')
from copy import deepcopy
from datetime import timedelta  # To convert elapsed time to hh:mm:ss format
from shared_data_holder import shared_data_holder
from MUST_doubles import MUST_doubles
from tools.userError import userError
from tools.globalVariables import *
from tools.pyomoSolverCreator import pyomoSolverCreator
from tools.io.read_sbml_model import read_sbml_model
from tools.core.compound import compound
from tools.core.reaction import reaction
from tools.core.organism import organism
from tools.core.model import model
from tools.fba.create_model import create_model
from tools.fba.fba import fba
from tools.fba.fva import fva
from tools.fba.set_specific_bounds import set_specific_bounds
from imp import load_source
from coopr.pyomo import *
from coopr.opt import *
# Increse the recursion limit, otherwise deepcopy will complain
sys.setrecursionlimit(10000)

class OptForce(object):
    """
    Checks whether a given flux data leads to a feasible FBA for a given metabolic model
    """
    def __init__(self, model, product_exchrxn_id, exp_flux_bounds, product_targetYield_percent = 80, min_biomass_percent = 10, growthMedium_flux_bounds = {'flux_bounds_filename':None, 'flux_bounds_dict': {}}, save_flux_bounds_toThisFile = '', read_flux_bounds_fromThisFile = '', save_MUST_singles_toThisFile = '', read_MUST_singles_fromThisFile = '', save_MUST_doubles_toThisFile = '', read_MUST_doubles_fromThisFile = '', save_FORCE_sets_toThisFile = '', optimization_solver = 'gurobi', simulation_condition = '', stdout_msgs = True, warnings = True):
        """
        INPUTS:
        ------
                          model: An instance of class model
             product_exchrxn_id: The id of the exchange reaction for the product of interest (a string)
                exp_flux_bounds: A dictionary with keys and values as follows:
                                   keys: Id of reactions with available flux data
                                 values: A list of two elements in the form [LB,UB]
                                         containing the LB and UB on reaction fluxes. 
                                         LB and UB can be None as well (if there is no
                                         experimental data for reaction fluxes)
        product_targetYield_percent: Desired target yield for the product of interest in the form of the percent of maximum theoretical yield
            min_biomass_percent: Min required biomass formation flux in the form of the percent of the max theoretical biomass formation flux
        growthMedium_flux_bounds: Information about growth media
                                 read_flux_bounds_fromThisFile: Name of and path of the file containing the flux bounds
                                                      file for exchange reactions corresponding to compounds in 
                                                       in the growth media
                                 flux_bounds_dict: A dictionary containing the flux bounds for other reactions (such as carbon
                                                  source uptake, oxygen uptake, etc), that have to be set for reactions not 
                                                   in flux_data_filenam or media_filename
        Ali R. Zomorrodi - Segre's Lab @ BU
        save_flux_bounds_toThisFile: The file to store the flux bounds. If an empty string is provided, the results are not save.
        read_flux_bounds_fromThisFile: A string containing the filename (including path) from which the  
                                 flux bounds for the reference and overproducing strains from is read (see function
                                 find_ref_overprod_flux_bounds for how the flux bounds are stored in files). 
                                 If an empty string is provided, the flux bounds are computed
        save_MUST_singles_toThisFile: A string containing the filename to store the MUST single sets of reactions.
                                 The resutls are not saved, if an empty string is provided
        read_MUST_singles_fromThisFile: A string containing the filename (including path) from which the  
                                 information for reactons appearing in MUST_X, MUST_L and MUST_U sets is read.
                                 (see function find_MUST_singles for how MUST single are stored in files).
                                 If an empty string is provided, the MUST sets are computed.
        save_MUST_doulbes_toThisFile: A string containing the name of the file to save the MUST doubles sets of reactions.
                                 The resutls are not saved, if an empty string is provided.
        read_MUST_doubles_fromThisFile: A string containing the filename (including path) from which the 
                                 information for reactons appearing in MUST_LL, MUST_UU and MUST_LU 
                                 sets is read (see class MUST_doubles for how MUST doubles are stored 
                                 in files). If an empty string is provided, MUST double sets are computed
         save_FORCE_sets_toThisFile: A string containing the filename to store the FORCE sets of reactions.
                                 The resutls are not saved, if an empty string is provided.
            optimization_solver: A string containing showing which optimization solver to use
                                 Allowed choices are 'gurobi' and 'cplex'
           simulation_condition: A string representing the simulation conditon 
                       warnings: Can be True or False shwoing whether the warnings should be 
                                 writtten to the 
                                 screen or not. The default is True  
                    stdout_msgs: Prints a summary of the FBA and a number of other messages 
                                 in the output if 'on.
       
        Ali R. Zomorrodi - Segre's Lab @ BU
        Last updated: 03-28-2016
        """
        self.shared_data = shared_data_holder(model = model, product_exchrxn_id = product_exchrxn_id, exp_flux_bounds = exp_flux_bounds, product_targetYield_percent = product_targetYield_percent, min_biomass_percent = min_biomass_percent, growthMedium_flux_bounds = growthMedium_flux_bounds, save_flux_bounds_toThisFile = save_flux_bounds_toThisFile,  read_flux_bounds_fromThisFile =  read_flux_bounds_fromThisFile, save_MUST_singles_toThisFile = save_MUST_singles_toThisFile, read_MUST_singles_fromThisFile = read_MUST_singles_fromThisFile, save_MUST_doubles_toThisFile = save_MUST_doubles_toThisFile, read_MUST_doubles_fromThisFile =  read_MUST_doubles_fromThisFile, save_FORCE_sets_toThisFile = save_FORCE_sets_toThisFile, optimization_solver =  optimization_solver, simulation_condition = simulation_condition, warnings = warnings, stdout_msgs =  stdout_msgs)

    def __setattr__(self,attr_name,attr_value):
        """
        Redefines funciton __setattr__
        INPUTS:
        -------
         attr_name: Attribute name
        attr_value: Attribute value
        """
        if attr_name == 'shared_data' and not isinstance(attr_value,shared_data_holder):
            raise TypeError('shared_data must be instance of class shared_data_holder')

        if attr_name != 'shared_data':
            self.shared_data.__dict__[attr_name] = attr_value 

        self.__dict__[attr_name] = attr_value

    def find_maxBiomass_flux(self):
        """
        Finds the maximum thoeretical biomass flux
        """
        for rxn in self.shared_data.model.reactions:
            rxn.objective_coefficient = 0
        self.shared_data.model.biomass_reaction.objective_coefficient = 1

        set_specific_bounds(model = self.shared_data.model, file_name = self.shared_data.growthMedium_flux_bounds['flux_bounds_filename'], flux_bounds = self.shared_data.growthMedium_flux_bounds['flux_bounds_dict'], reset_flux_bounds = True)

        self.shared_data.model.fba(build_new_optModel = True, store_opt_fluxes = False, stdout_msgs = False, warnings = True)
        if self.shared_data.model.fba_model.solution['exit_flag'] == 'globallyOptimal':
            self.shared_data.max_biomass_flux = self.shared_data.model.fba_model.solution['objective_value']
            if self.shared_data.stdout_msgs:
                print 'OptForce: Theoretical maximum biomass formation flux = {}'.format(self.shared_data.max_biomass_flux)
        else:    
            raise userError('The FBA problem for finding the maximum theoretical biomass flux was not solved to optimality!')

    def find_prod_max_theor_yield(self):
        """
        Finds the maximum thoeretical yield for the product of interest (this is the max flux of the exchange reactions for the product)
        """
        for rxn in self.shared_data.model.reactions:
            rxn.objective_coefficient = 0
        self.shared_data.model.reactions_by_id[self.shared_data.product_exchrxn_id].objective_coefficient = 1

        set_specific_bounds(model = self.shared_data.model, file_name = self.shared_data.growthMedium_flux_bounds['flux_bounds_filename'], flux_bounds = self.shared_data.growthMedium_flux_bounds['flux_bounds_dict'], reset_flux_bounds = True)

        self.shared_data.model.fba(build_new_optModel = True, store_opt_fluxes = False, stdout_msgs = False, warnings = True)
        if self.shared_data.model.fba_model.solution['exit_flag'] == 'globallyOptimal':
            self.shared_data.product_max_theor_yield = self.shared_data.model.fba_model.solution['objective_value']
            if self.shared_data.stdout_msgs:
                print 'OptForce: Theoretical maximum product yield = {}'.format(self.shared_data.product_max_theor_yield)
        else:    
            raise userError('The FBA problem for finding the theoretical maximum product yield was not solved to optimality!')

    def find_ref_overprod_flux_bounds(self):
        """
        Finds the flux bounds for the reference and overproducing strains 
        """
        #-- Finds flux bounds for the reference strain -- 

        if self.shared_data.stdout_msgs:
            print 'OptForce: Finding flux bounds in the reference strain ...',
            start_refBnd_pt = time.clock()
            start_refBnd_wt = time.time()

        # Growth medium
        set_specific_bounds(model = self.shared_data.model, file_name = self.shared_data.growthMedium_flux_bounds['flux_bounds_filename'], flux_bounds = self.shared_data.growthMedium_flux_bounds['flux_bounds_dict'], reset_flux_bounds = True)
        # Experimental flux data
        set_specific_bounds(model = self.shared_data.model, flux_bounds = self.shared_data.exp_flux_bounds, reset_flux_bounds = False)
    
        self.shared_data.flux_bounds_ref = fva(model = self.shared_data.model, store_fva_flux_bounds = False, stdout_msgs = False) 

        if self.shared_data.stdout_msgs:
            elapsed_refBnd_pt = str(timedelta(seconds = time.clock() - start_refBnd_pt))
            elapsed_refBnd_wt = str(timedelta(seconds = time.time() - start_refBnd_wt))
            print ' took {} of processing time and {} of wall time'.format(elapsed_refBnd_pt, elapsed_refBnd_wt)

        #-- Finds flux bounds for the overproducing strain -- 
        if self.shared_data.stdout_msgs:
            print 'OptForce: Finding flux bounds in the overproducing strain ...',
            start_opsBnd_pt = time.clock()
            start_opsfBnd_wt = time.time()

        # Growth medium
        set_specific_bounds(model = self.shared_data.model, file_name = self.shared_data.growthMedium_flux_bounds['flux_bounds_filename'], flux_bounds = self.shared_data.growthMedium_flux_bounds['flux_bounds_dict'], reset_flux_bounds = True)
        # Impost constraints on product yield and min biomass formation flux
        set_specific_bounds(model = self.shared_data.model, flux_bounds = {self.shared_data.biomass_rxn_id:[(self.shared_data.min_biomass_percent/100)*self.shared_data.max_biomass_flux,None], self.shared_data.product_exchrxn_id:[(self.shared_data.product_targetYield_percent/100)*self.shared_data.product_max_theor_yield,None]}, reset_flux_bounds = False)
    
        self.shared_data.flux_bounds_overprod = fva(model = self.shared_data.model, store_fva_flux_bounds = False, stdout_msgs = False) 

        if self.shared_data.stdout_msgs:
            elapsed_opsBnd_pt = str(timedelta(seconds = time.clock() - start_opsBnd_pt))
            elapsed_opsBnd_wt = str(timedelta(seconds = time.time() - start_opsBnd_wt))
            print ' took {} of processing time and {} of wall time'.format(elapsed_opsBnd_pt, elapsed_opsBnd_wt)

        #-- Save the flux bounds results into a file --
        if self.shared_data.save_flux_bounds_toThisFile != '':
            with open(self.shared_data.save_flux_bounds_toThisFile,'w') as f:
                f.write('flux_bounds_ref = {\n')
                for rxn in self.shared_data.model.reactions:
                    f.write("'{}':{},\n".format(rxn.id,self.shared_data.flux_bounds_ref[rxn.id]))
                f.write('}\n')

                f.write('\nflux_bounds_overprod = {\n')
                for rxn in self.shared_data.model.reactions:
                    f.write("'{}':{},\n".format(rxn.id,self.shared_data.flux_bounds_overprod[rxn.id]))
                f.write('}\n')

        if self.shared_data.stdout_msgs:
            print '\tFlux bounds for the reference and overproducing strains were written into {}'.format(self.shared_data.save_flux_bounds_toThisFile)

    def find_MUST_singles(self):
        """
        Finds MUST single sets (MUST_L, MUST_U and MUST_X) 
        """
        if self.shared_data.stdout_msgs:
            print 'OptForce: Finding MUST singles ...',
            start_mustSingl_pt = time.clock()
            start_mustSingl_wt = time.time()

        # A threshold below which the flux value is considered to be practically zero
        zero_flux_thr = 1e-4

        self.shared_data.MUST_X, self.shared_data.MUST_L, self.shared_data.MUST_U = [], [], []
        for rxn in [r for r in self.shared_data.model.reactions if r.reversibility.lower() != 'exchange']:
            # MUST X: abs(LB_overprod) < zero_flux_thr and abs(UB_overprod) < zero_flux_thr and (abs(LB_ref) > zero_flux_thr or abs(UB_ref) > zero_flux_thr) 
            if (self.shared_data.flux_bounds_overprod[rxn.id][0] != None and self.shared_data.flux_bounds_overprod[rxn.id][1] != None and abs(self.shared_data.flux_bounds_overprod[rxn.id][0]) < zero_flux_thr and abs(self.shared_data.flux_bounds_overprod[rxn.id][1] < zero_flux_thr)) and (abs(self.shared_data.flux_bounds_ref[rxn.id][0]) > zero_flux_thr or abs(self.shared_data.flux_bounds_ref[rxn.id][1]) > zero_flux_thr):
                self.shared_data.MUST_X.append(rxn)

            # MUST_U: UB_ref < LB_oveprod
            elif self.shared_data.flux_bounds_ref[rxn.id][1] != None and self.shared_data.flux_bounds_overprod[rxn.id][0] != None and self.shared_data.flux_bounds_ref[rxn.id][1] < self.shared_data.flux_bounds_overprod[rxn.id][0]:
                self.shared_data.MUST_U.append(rxn)

            # MUST_L: UB_overprod < LB_ref
            elif self.shared_data.flux_bounds_overprod[rxn.id][1] != None and self.shared_data.flux_bounds_ref[rxn.id][0] != None and self.shared_data.flux_bounds_overprod[rxn.id][1] < self.shared_data.flux_bounds_ref[rxn.id][0]:
                self.shared_data.MUST_L.append(rxn)

        if self.shared_data.stdout_msgs:
            elapsed_mustSingl_pt = str(timedelta(seconds = time.clock() - start_mustSingl_pt))
            elapsed_mustSingl_wt = str(timedelta(seconds = time.time() - start_mustSingl_wt))
            print ' took {} of processing time and {} of wall time'.format(elapsed_mustSingl_pt, elapsed_mustSingl_wt)

        #-- Save the MUST single results into a file --
        if self.shared_data.save_MUST_singles_toThisFile != '':
            with open(self.shared_data.save_MUST_singles_toThisFile,'w') as f:
                f.write('MUST_X_details = {\n')
                for rx in self.shared_data.MUST_X:
                    f.write("'{}':{{'name':'{}', 'gpr':'{}', 'ref_bounds':{}, 'overprod_bounds':{}}},\n".format(rx.id,rx.name, rx.gene_reaction_rule, self.shared_data.flux_bounds_ref[rx.id],self.shared_data.flux_bounds_overprod[rx.id]))               
                f.write('}\n')

                f.write('\nMUST_L_details = {\n')
                for rl in self.shared_data.MUST_L:
                    f.write("'{}':{{'name':'{}', 'gpr':'{}', 'ref_bounds':{}, 'overprod_bounds':{}}},\n".format(rl.id,rl.name, rl.gene_reaction_rule, self.shared_data.flux_bounds_ref[rl.id],self.shared_data.flux_bounds_overprod[rl.id]))               
                f.write('}\n')

                f.write('\nMUST_U_details = {\n')
                for ru in self.shared_data.MUST_U:
                    f.write("'{}':{{'name':'{}', 'gpr':'{}', 'ref_bounds':{}, 'overprod_bounds':{}}},\n".format(ru.id,ru.name, ru.gene_reaction_rule, self.shared_data.flux_bounds_ref[ru.id],self.shared_data.flux_bounds_overprod[ru.id]))               
                f.write('}\n')

        if self.shared_data.stdout_msgs:
            print '\tMUST single reactions were written into {}'.format(self.shared_data.save_MUST_singles_toThisFile)

    def find_MUST_doubles(self):
        """
        Finds MUST double sets (MUST_LU, MUST_UU and MUST_LL) 
        """
        results_filename = self.shared_data.save_MUST_doubles_toThisFile

        # MUST_LU
        if self.shared_data.stdout_msgs:
            print 'OptForce: Finding MUST LUs ...',
            start_mustlu_pt = time.clock()
            start_mustlu_wt = time.time()

        must_LU_inst = MUST_doubles(shared_data = self.shared_data, MUST_double_type = 'MUST_LU', build_new_optModel = True, objective_thr = 1e-3, validate_results = True, results_filename = results_filename, create_new_results_file = True, stdout_msgs = True)
        (solutions, termination_condition) = must_LU_inst.run()
        self.shared_data.MUST_LU_L = []
        self.shared_data.MUST_LU_U = []
        for soln in solutions:
            self.shared_data.MUST_LU_L.append(soln['L'])
            self.shared_data.MUST_LU_U.append(soln['U'])

        if self.shared_data.stdout_msgs:
            elapsed_mustlu_pt = str(timedelta(seconds = time.clock() - start_mustlu_pt))
            elapsed_mustlu_wt = str(timedelta(seconds = time.time() - start_mustlu_wt))
            print ' {} solutions found, ended with {} and took {} of processing time and {} of wall time'.format(len(solutions), termination_condition, elapsed_mustlu_pt, elapsed_mustlu_wt)

        # MUST_UU
        if self.shared_data.stdout_msgs:
            print 'OptForce: Finding MUST UUs ...',
            start_mustuu_pt = time.clock()
            start_mustuu_wt = time.time()

        must_UU_inst = MUST_doubles(shared_data = self.shared_data, MUST_double_type = 'MUST_UU', build_new_optModel = True, objective_thr = 1e-3, validate_results = True, results_filename = results_filename, create_new_results_file = False, stdout_msgs = False)
        (solutions, termination_condition) = must_UU_inst.run()
        self.shared_data.MUST_UU_U1 = []
        self.shared_data.MUST_UU_U2 = []
        for soln in solutions:
            self.shared_data.MUST_UU_U1.append(soln['U1'])
            self.shared_data.MUST_UU_U2.append(soln['U2'])

        if self.shared_data.stdout_msgs:
            elapsed_mustuu_pt = str(timedelta(seconds = time.clock() - start_mustuu_pt))
            elapsed_mustuu_wt = str(timedelta(seconds = time.time() - start_mustuu_wt))
            print ' {} solutions found, ended with {} and took {} of processing time and {} of wall time'.format(len(solutions), termination_condition, elapsed_mustuu_pt, elapsed_mustuu_wt)

        # MUST_LL
        if self.shared_data.stdout_msgs:
            print 'OptForce: Finding MUST LLs ...',
            start_mustll_pt = time.clock()
            start_mustll_wt = time.time()

        must_LL_inst = MUST_doubles(shared_data = self.shared_data, MUST_double_type = 'MUST_LL', build_new_optModel = True, objective_thr = 1e-3, validate_results = True, results_filename = results_filename, create_new_results_file = False, stdout_msgs = False)
        (solutions, termination_condition) = must_LL_inst.run()
        self.shared_data.MUST_LL_L1 = []
        self.shared_data.MUST_LL_L2 = []
        for soln in solutions:
            self.shared_data.MUST_LL_L1.append(soln['L1'])
            self.shared_data.MUST_LL_L2.append(soln['L2'])

        if self.shared_data.stdout_msgs:
            elapsed_mustll_pt = str(timedelta(seconds = time.clock() - start_mustll_pt))
            elapsed_mustll_wt = str(timedelta(seconds = time.time() - start_mustll_wt))
            print ' {} solutions found, ended with {} and took {} of processing time and {} of wall time'.format(len(solutions), termination_condition, elapsed_mustll_pt, elapsed_mustll_wt)

    def run(self):
        """
        Runs the entire OptForce procedure 
        """
        if self.shared_data.stdout_msgs:
            print '\nStart running OptForce ...'

        # Find the maximum biomass flux
        self.find_maxBiomass_flux() 

        # Find the maximum theoretical yield of the product
        self.find_prod_max_theor_yield()

        # Find flux bounds in the wild-type and overproducing strains
        if self.read_flux_bounds_fromThisFile == '':
            self.find_ref_overprod_flux_bounds() 
        else:
            load_source('dataFile',self.shared_data.read_flux_bounds_fromThisFile)
            import dataFile
            self.shared_data.flux_bounds_ref = dataFile.flux_bounds_ref
            self.shared_data.flux_bounds_overprod = dataFile.flux_bounds_overprod

        # Find MUST singles (MUST_L, MUST_U and MUST_X)
        if self.shared_data.read_MUST_singles_fromThisFile == '':
            self.find_MUST_singles()
        else:
            load_source('dataFile',self.shared_data.read_MUST_singles_fromThisFile)
            import dataFile
            self.shared_data.MUST_X = dataFile.MUST_X_details.keys()
            self.shared_data.MUST_L = dataFile.MUST_L_details.keys()
            self.shared_data.MUST_U = dataFile.MUST_U_details.keys()

        # Find MUST doubles (MUST_LU, MUST_UU and MUST_LU)
        if self.shared_data.read_MUST_singles_fromThisFile == '':
            self.find_MUST_doubles()
        else:
            load_source('dataFile',self.shared_data.read_MUST_doubles_fromThisFile)
            import dataFile
            # MUST_LU
            MUST_LU_details = dataFile.MUST_LU_details
            self.shared_cmp.MUST_LU_L = []
            self.shared_cmp.MUST_LU_U = []
            for MUST_LU in MUST_LU_details:
                self.shared_cmp.MUST_LU_L.append(MUST_LU_details['L'])
                self.shared_cmp.MUST_LU_U.append(MUST_LU_details['U'])

            # MUST_UU
            MUST_UU_details = dataFile.MUST_UU_details
            self.shared_cmp.MUST_UU_U1 = []
            self.shared_cmp.MUST_UU_U2 = []
            for MUST_UU in MUST_UU_details:
                self.shared_cmp.MUST_UU_U1.append(MUST_UU_details['U1'])
                self.shared_cmp.MUST_UU_U2.append(MUST_UU_details['U2'])

            # MUST_LL
            MUST_LL_details = dataFile.MUST_LL_details
            self.shared_cmp.MUST_LL_L1 = []
            self.shared_cmp.MUST_LL_L2 = []
            for MUST_LL in MUST_LL_details:
                self.shared_cmp.MUST_LL_L1.append(MUST_LL_details['L1'])
                self.shared_cmp.MUST_LL_L2.append(MUST_LL_details['L2'])

#-----------------------------------------
class MUST_doubles(object):
    """
    This class defines the optimization problem to identify the MUST double sets 
    of reactions, i.e., MUST_LU (or MUST_UL), MUST_LL and MUST_UU

    Ali R. Zomorrodi - Segre Lab @ BU
    Last updated: March 23, 2016
    """
    def __init__(self,shared_data, MUST_double_type, build_new_optModel = True, objective_thr = 5, validate_results = False, results_filename = '', create_new_results_file = True, stdout_msgs = True, warnings = True): 
        """
        All inputs are a subset of those for OptForce

        INPUTS:
        ------
               shared_data: An instance of class shared_data_holder
          MUST_double_type: Tyype of MUST doulbe to find. Allowed choices include: MUST_LU 
                            (or MUST_UL), MUST_LL and MUST_UU
        build_new_optModel: If True ia new optimization model is created
             objective_thr: If the outer objective function is less than this threshold the
                            code stops
          validate_results: If True each obtained solution is validated before finding the next
                            one
          results_filename: A string containing the name of the file where the results should
                            be written in
          create_new_results_file: If True the results are written in a new file and if False they 
                            are appended to an existing file specified by results_filename
        
        MUST_LU:  Max_OP(v1 - v2) < Min_WT(v1 - v2)
                                           v1 - v2
        Wild-type                          |-----|
        over-producing             |-----|

        MUST_UL: Min_OP(v1 - v2) > Max_WT(v1 - v2)
                            v1 - v2
        Wild-type           |-----|
        over-producing               |-----|

        MUST_UU: Min_OP(v1 + v2) > Max_WT(v1 + v2)
                            v1 + v2
        Wild-type           |-----|
        over-producing               |-----|

        MUST_LL: Max_OP(v1 + v2) < Min_WT(v1 + v2)
                                           v1 + v2
        Wild-type                          |-----|
        over-producing             |-----|


        Therefore, the objective of function of the inner problem is maximized for MUST_LU and MUST_LL and it is 
        minimized for MUST_UL and MUST_UL
        """
        # Shared_data 
        self.shared_data = shared_data

        # Type of MUST doubles to identify
        self.MUST_double_type = MUST_double_type

        # build_new_optModel
        self.build_new_optModel = build_new_optModel

        # outer objective threshold
        self.objective_thr = objective_thr

        # validate results
        self.validate_results = validate_results

        # results file name
        self.results_filename = results_filename

        # create_new_results_file
        self.create_new_results_file = create_new_results_file

        # warnings
        self.warnings = warnings

        # stdout_msgs
        self.stdout_msgs = stdout_msgs

    def __setattr__(self,attr_name,attr_value):
        """
        Redefines funciton __setattr__
        INPUTS:
        -------
         attr_name: Attribute name
        attr_value: Attribute value
        """
        if attr_name == 'shared_data' and not isinstance(attr_value,shared_data_holder):
            raise TypeError('shared_data must be instance of class shared_data_holder')

        if attr_name == 'MUST_double_type' and not isinstance(attr_value,str):
            raise TypeError('MUST_double_type must be a string')
        elif attr_name == 'MUST_double_type' and attr_value.lower() not in ['must_lu','must_ul','must_uu','must_ll']: 
            raise TypeError('Invalid MUST_double_type value! Allowed choices are MUST_LU, MUST_UL, MUST_LL, MUST_UU')

        if attr_name == 'build_new_optModel' and not isinstance(attr_value,bool):
            raise TypeError('build_new_optModel must be either True or False')

        if attr_name == 'objective_thr' and not isinstance(attr_value,float) and not isinstance(attr_value,int):
            raise TypeError('objective_thr must be either a float or an integer')

        if attr_name == 'validate_results' and not isinstance(attr_value,bool):
            raise TypeError('validate_results must be eiher True or False')

        if attr_name == 'results_filename' and not isinstance(attr_value,str):
            raise TypeError('results_filename must be a string')

        if attr_name == 'create_new_results_file' and not isinstance(attr_value,bool):
            raise TypeError('create_new_results_file must be eiher True or False')

        if attr_name == 'warnings' and not isinstance(attr_value,bool):
            raise TypeError('warnings must be eiher True or False')

        if attr_name == 'stoud_msgs' and not isinstance(attr_value,bool):
            raise TypeError('stdout_msgs must be eiher True or False')

        if attr_name.lower() not in  ['shared_data','must_double_type','build_new_optModel','objective_thr','validate_results','results_filename','create_new_results_file','warnings','stdout_msgs']:
            self.shared_data.__dict__[attr_name] = attr_value 

        self.__dict__[attr_name] = attr_value

    #------------------------------------------------------------------------
    #--- Define parameters needed for the optimizaiton problem ---
    #------------------------------------------------------------------------
    def define_optModel_params(self):
        """
        Assigns model parameters
        """
        self._muLB_max = 1e4
        self._muUB_max = 1e4

        # Reactions that must be excluded (ignore) from MUST doube consideration
        self._ignore = []
        for rxn in self.shared_data.model.reactions:
            if rxn.id in self.shared_data.MUST_X + self.shared_data.MUST_L + self.shared_data.MUST_U or \
               (rxn.flux_bounds[0] == 0 and rxn.flux_bounds[1] == 0) or \
               'transport' in rxn.name.lower() or \
               rxn.reversibility.lower() == 'exchange' or \
               (rxn.genes == [] and rxn.gene_reaction_rule == ''):
                self._ignore.append(rxn.id)

        # biomass
        self._ignore.append(self.shared_data.model.biomass_reaction.id)

        # ATPM
        if 'ATPM' in self.shared_data.model.reactions_by_id.keys(): 
            self._ignore.append('ATPM')

    def assignFluxBounds(self,optModel,j):
        """
        Define the flux bounds
        """
        # v_biomass >= v_biomass_min
        if j == self.shared_data.biomass_rxn_id:
            LB_UB = [(self.shared_data.min_biomass_percent/100)*self.shared_data.max_biomass_flux,self.shared_data.model.reactions_by_id[j].flux_bounds[1]]

        # v_prodict >= v_product_target
        elif j == self.shared_data.product_exchrxn_id: 
            LB_UB = [(self.shared_data.product_targetYield_percent/100)*self.shared_data.product_max_theor_yield, self.shared_data.model.reactions_by_id[j].flux_bounds[1]]

        else: 
            LB_UB = self.shared_data.model.reactions_by_id[j].flux_bounds

        return LB_UB 

    #------------------------------------------------------------------------
    #--- Define rules for the objective function and various constraints ----
    #------------------------------------------------------------------------
    #--- Constraints of the outer-level problem ---
    # Objective function
    def outer_objectiveFunc_rule(self,optModel):
        """
        Objective function of the outer-level problem 
        """
        # MUST_LU:  Max_OP(v1 - v2) < Min_WT(v1 - v2)
        # z = sum(j,[LBw(j)*yL(j) - UBw(j)*yU(j)] - [v_yL(j) - v_yU(j)])
        if self.MUST_double_type.lower() == 'must_lu':
            obj = sum([(self.shared_data.flux_bounds_ref[j][0]*optModel.yL[j] - self.shared_data.flux_bounds_ref[j][1]*optModel.yU[j]) - (optModel.v_yL[j] - optModel.v_yU[j]) for j in optModel.J])

        # MUST_UL: Min_OP(v1 - v2) > Max_WT(v1 - v2)
        # z = sum(j,[v_yU(j) - v_yL(j)] - [UBw(j)*yU(j) - LBw(j)*yL(j)])
        elif self.MUST_double_type.lower() == 'must_ul':
            obj = sum([(optModel.v_yU[j] - optModel.v_yL[j]) - (self.shared_data.flux_bounds_ref[j][1]*optModel.yU[j] - self.shared_data.flux_bounds_ref[j][0]*optModel.yL[j]) for j in optModel.J])

        # MUST_UU: Min_OP(v1 + v2) > Max_WT(v1 + v2)
        # z = sum(j,[v_y1U(j) + v_y2U(j)] - [UBw(j)*y1U(j) + UBw(j)*y2U(j)])
        elif self.MUST_double_type.lower() == 'must_uu':
            obj = sum([(optModel.v_y1U[j] + optModel.v_y2U[j]) - (self.shared_data.flux_bounds_ref[j][1]*optModel.y1U[j] - self.shared_data.flux_bounds_ref[j][1]*optModel.y2U[j]) for j in optModel.J])

        # MUST_LL: Max_OP(v1 + v2) < Min_WT(v1 + v2)
        # z = sum(j,[LBw(j)*y1L(j) + LBw(j)*y2L(j)] - [v_y1L(j) + v_y2L(j)]);
        elif self.MUST_double_type.lower() == 'must_ll':
            obj = sum([(self.shared_data.flux_bounds_ref[j][0]*optModel.y1L[j] + self.shared_data.flux_bounds_ref[j][0]*optModel.y2L[j]) - (optModel.v_y1L[j] + optModel.v_y2L[j]) for j in optModel.J])

        return obj

    def onlyOne_yL_isOne_const_rule(self, optModel):
        """
        sum(j,yL(j)) = 1
        """
        return sum([optModel.yL[j] for j in optModel.J]) == 1

    def onlyOne_yU_isOne_const_rule(self, optModel):
        """
        sum(j,yU(j)) = 1
        """
        return sum([optModel.yU[j] for j in optModel.J]) == 1

    def each_rxn_yLyU_const_rule(self, optModel, j):
        """
        yL[j] + yU[j] = 1 for each j 
        """
        return (optModel.yL[j] + optModel.yU[j]) <= 1

    def onlyOne_y1U_isOne_const_rule(self, optModel):
        """
        sum(j,y1U(j)) = 1
        """
        return sum([optModel.y1U[j] for j in optModel.J]) == 1

    def onlyOne_y2U_isOne_const_rule(self, optModel):
        """
        sum(j,y2U(j)) = 1
        """
        return sum([optModel.y2U[j] for j in optModel.J]) == 1

    def each_rxn_y1Uy2U_const_rule(self, optModel, j):
        """
        y1U[j] + y2U[j] = 1 for each j 
        """
        return (optModel.y1U[j] + optModel.y2U[j]) <= 1

    def onlyOne_y1L_isOne_const_rule(self, optModel):
        """
        sum(j,y1L(j)) = 1
        """
        return sum([optModel.y1L[j] for j in optModel.J]) == 1

    def onlyOne_y2L_isOne_const_rule(self, optModel):
        """
        sum(j,y2L(j)) = 1
        """
        return sum([optModel.y2L[j] for j in optModel.J]) == 1

    def each_rxn_y1Ly2L_const_rule(self, optModel, j):
        """
        y1L[j] + y2L[j] = 1 for each j 
        """
        return (optModel.y1L[j] + optModel.y2L[j]) <= 1

    # integer cuts
    def integer_cuts_rule(self,optModel):
        """
        Integer cuts: Sum of the binary variables that were one in a previous iteration must be less than or equal to one (i.e., at least
        one of them must be zero in the current iteration) 
        """
        if self.MUST_double_type.lower() in ['must_lu','must_ul']:
            const = sum([optModel.yL[j] for j in optModel.J if self._yLopt_curr[j] == 1]) + sum([optModel.yU[j] for j in optModel.J if self._yUopt_curr[j] == 1]) <= 1

        elif self.MUST_double_type.lower() in 'must_uu':
            const = sum([optModel.y1U[j] for j in optModel.J if self._y1Uopt_curr[j] == 1]) + sum([optModel.y2U[j] for j in optModel.J if self._y2Uopt_curr[j] == 1]) <= 1

        elif self.MUST_double_type.lower() in 'must_ll':
            const = sum([optModel.y1L[j] for j in optModel.J if self._y1Lopt_curr[j] == 1]) + sum([optModel.y2U[j] for j in optModel.J if self._y2Uopt_curr[j] == 1]) <= 1
        
        return const 

    #--- Constraints of the primal problem ---
    def primal_objectiveFunc_rule(self,optModel):
        """
        Objective function of the primal problem 
        """
        if self.MUST_double_type.lower() == 'must_lu':
            obj = sum([optModel.v[j]*optModel.yL[j] - optModel.v[j]*optModel.yU[j] for j in optModel.J])

        elif self.MUST_double_type.lower() == 'must_ul':
            obj = sum([optModel.v[j]*optModel.yU[j] - optModel.v[j]*optModel.yL[j] for j in optModel.J])

        elif self.MUST_double_type.lower() == 'must_uu':
            obj = sum([optModel.v[j]*optModel.y1U[j] + optModel.v[j]*optModel.y2U[j] for j in optModel.J])

        elif self.MUST_double_type.lower() == 'must_ll':
            obj = sum([optModel.v[j]*optModel.y1L[j] + optModel.v[j]*optModel.y2L[j] for j in optModel.J])

        return obj

    def massBalance_const_rule(self,optModel,i):
        """
        Mass balance 
        """
        return sum(j.stoichiometry[self.shared_data.model.compounds_by_id[i]]*optModel.v[j.id] for j in self.shared_data.model.compounds_by_id[i].reactions) == 0

    #--- Constraints of the dual problem ---
    def dual_objectiveFunc_rule(self,optModel):
        """
        Objective function of the dual problem
        """
        if self.MUST_double_type.lower() in ['must_lu','must_ll']:
            obj = sum([optModel.muUB[j]*self.shared_data.model.reactions_by_id[j].flux_bounds[1] for j in optModel.J]) - \
                  sum([optModel.muLB*self.shared_data.model.reactions_by_id[j].flux_bounds[0] for j in optModel.J if j not in [self.shared_data.biomass_rxn_id,self.shared_data.product_exchrxn_id]]) - \
                  optModel.muLB[self.shared_data.biomass_rxn_id]*(self.shared_data.min_biomass_percent/100)*self.shared_data.max_biomass_flux - \
                  optModel.muLB[self.shared_data.product_exchrxn_id]*(self.shared_data.product_targetYield_percent/100)*self.shared_data.product_max_theor_yield 

        elif self.MUST_double_type.lower() in ['must_ul','must_uu']:
            obj = sum([optModel.muLB*self.shared_data.model.reactions_by_id[j].flux_bounds[0] for j in optModel.J if j not in [self.shared_data.biomass_rxn_id,self.shared_data.product_exchrxn_id]]) + \
                  optModel.muLB[self.shared_data.biomass_rxn_id]*(self.shared_data.min_biomass_percent/100)*self.shared_data.max_biomass_flux + \
                  optModel.muLB[self.shared_data.product_exchrxn_id]*(self.shared_data.product_targetYield_percent/100)*self.shared_data.product_max_theor_yield - \
                  sum([optModel.muUB[j]*self.shared_data.model.reactions_by_id[j].flux_bounds[1] for j in optModel.J]) 

        return obj

    def dual_const_rule(self,optModel,j):
        """
        Constraints of the dual problem
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object with id j

        # MUST_LU
        if self.MUST_double_type.lower() == 'must_lu':
            const = sum(rxn.stoichiometry[i]*optModel.Lambda[i.id] for i in rxn.compounds) + optModel.muUB[j] - optModel.muLB[j] == optModel.yL[j] - optModel.yU[j] 

        # MUST_UL
        elif self.MUST_double_type.lower() == 'must_ul':
            const = sum(rxn.stoichiometry[i]*optModel.Lambda[i.id] for i in rxn.compounds) + optModel.muLB[j] - optModel.muUB[j] == optModel.yU[j] - optModel.yL[j] 

        # MUST_LL
        elif self.MUST_double_type.lower() == 'must_ll':
            const = sum(rxn.stoichiometry[i]*optModel.Lambda[i.id] for i in rxn.compounds) + optModel.muUB[j] - optModel.muLB[j] == optModel.y1L[j] + optModel.y2L[j] 

        # MUST_UU
        elif self.MUST_double_type.lower() == 'must_uu':
            const = sum(rxn.stoichiometry[i]*optModel.Lambda[i.id] for i in rxn.compounds) + optModel.muLB[j] - optModel.muUB[j] == optModel.y1U[j] + optModel.y2U[j] 

        return const

    # --- Strong duality constraint ---
    def strong_duality_const_rule(self,optModel):
        """
        Strong duality constraint: primal objective = dual objective 
        """
        if self.MUST_double_type.lower() == 'must_lu':
            const = sum([optModel.v_yL[j] - optModel.v_yU[j] for j in optModel.J]) == \
                    sum([optModel.muUB[j]*self.shared_data.model.reactions_by_id[j].flux_bounds[1] for j in optModel.J]) - \
                    sum([optModel.muLB[j]*self.shared_data.model.reactions_by_id[j].flux_bounds[0] for j in optModel.J if j not in [self.shared_data.biomass_rxn_id,self.shared_data.product_exchrxn_id]]) - \
                    optModel.muLB[self.shared_data.biomass_rxn_id]*(self.shared_data.min_biomass_percent/100)*self.shared_data.max_biomass_flux - \
                    optModel.muLB[self.shared_data.product_exchrxn_id]*(self.shared_data.product_targetYield_percent/100)*self.shared_data.product_max_theor_yield 

        elif self.MUST_double_type.lower() == 'must_ul':
            const = sum([optModel.v_yU[j] - optModel.v_yL[j] for j in optModel.J]) == \
                    sum([optModel.muLB[j]*self.shared_data.model.reactions_by_id[j].flux_bounds[0] for j in optModel.J if j not in [self.shared_data.biomass_rxn_id,self.shared_data.product_exchrxn_id]]) + \
                    optModel.muLB[self.shared_data.biomass_rxn_id]*(self.shared_data.min_biomass_percent/100)*self.shared_data.max_biomass_flux + \
                    optModel.muLB[self.shared_data.product_exchrxn_id]*(self.shared_data.product_targetYield_percent/100)*self.shared_data.product_max_theor_yield - \
                    sum([optModel.muUB[j]*self.shared_data.model.reactions_by_id[j].flux_bounds[1] for j in optModel.J]) 


        elif self.MUST_double_type.lower() == 'must_uu':
            const = sum([optModel.v_y1U[j] + optModel.v_y2U[j]*optModel.y2U[j] for j in optModel.J]) == \
                    sum([optModel.muLB[j]*self.shared_data.model.reactions_by_id[j].flux_bounds[0] for j in optModel.J if j not in [self.shared_data.biomass_rxn_id,self.shared_data.product_exchrxn_id]]) + \
                    optModel.muLB[self.shared_data.biomass_rxn_id]*(self.shared_data.min_biomass_percent/100)*self.shared_data.max_biomass_flux + \
                    optModel.muLB[self.shared_data.product_exchrxn_id]*(self.shared_data.product_targetYield_percent/100)*self.shared_data.product_max_theor_yield - \
                    sum([optModel.muUB[j]*self.shared_data.model.reactions_by_id[j].flux_bounds[1] for j in optModel.J]) 


        elif self.MUST_double_type.lower() == 'must_ll':
            const = sum([optModel.v_y1L[j] + optModel.v_y2L[j] for j in optModel.J]) == \
                    sum([optModel.muUB[j]*self.shared_data.model.reactions_by_id[j].flux_bounds[1] for j in optModel.J]) - \
                    sum([optModel.muLB[j]*self.shared_data.model.reactions_by_id[j].flux_bounds[0] for j in optModel.J if j not in [self.shared_data.biomass_rxn_id,self.shared_data.product_exchrxn_id]]) - \
                    optModel.muLB[self.shared_data.biomass_rxn_id]*(self.shared_data.min_biomass_percent/100)*self.shared_data.max_biomass_flux - \
                    optModel.muLB[self.shared_data.product_exchrxn_id]*(self.shared_data.product_targetYield_percent/100)*self.shared_data.product_max_theor_yield 

        return const

    #--- Constraints linearizing the product of reactions fluxes and binary variables ---
    #-- v[j]*yL[j] --
    def linearize_v_yL_const1_rule(self,optModel,j):
        """
        LB[j]*yL[j] <= v_yL[j] <= UB[j]*yL[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return rxn.flux_bounds[0]*optModel.yL[j] <= optModel.v_yL[j]

    def linearize_v_yL_const2_rule(self,optModel,j):
        """
        LB[j]*yL[j] <= v_yL[j] <= UB[j]*yL[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v_yL[j] <= rxn.flux_bounds[1]*optModel.yL[j]

    def linearize_v_yL_const3_rule(self,optModel,j):
        """
        x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        v[j] - (1 - yL[j])*UB[j] <= v_yL[j] <= v[j] - (1 - yL[j])*LB[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v[j] - (1 - optModel.yL[j])*rxn.flux_bounds[1] <= optModel.v_yL[j]

    def linearize_v_yL_const4_rule(self,optModel,j):
        """
        x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        v[j] - (1 - yL[j])*UB[j] <= v_yL[j] <= v[j] - (1 - yL[j])*LB[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v_yL[j] <= optModel.v[j] - (1 - optModel.yL[j])*rxn.flux_bounds[0]

    #-- v[j]*yU[j] --
    def linearize_v_yU_const1_rule(self,optModel,j):
        """
        LB[j]*yU[j] <= v_yU[j] <= UB[j]*yU[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return rxn.flux_bounds[0]*optModel.yU[j] <= optModel.v_yU[j]

    def linearize_v_yU_const2_rule(self,optModel,j):
        """
        LB[j]*yU[j] <= v_yU[j] <= UB[j]*yU[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v_yU[j] <= rxn.flux_bounds[1]*optModel.yU[j]

    def linearize_v_yU_const3_rule(self,optModel,j):
        """
        x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        v[j] - (1 - yU[j])*UB[j] <= v_yU[j] <= v[j] - (1 - yU[j])*LB[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v[j] - (1 - optModel.yU[j])*rxn.flux_bounds[1] <= optModel.v_yU[j]

    def linearize_v_yU_const4_rule(self,optModel,j):
        """
        x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        v[j] - (1 - yU[j])*UB[j] <= v_yU[j] <= v[j] - (1 - yU[j])*LB[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v_yU[j] <= optModel.v[j] - (1 - optModel.yU[j])*rxn.flux_bounds[0]

    #-- v[j]*y1U[j] --
    def linearize_v_y1U_const1_rule(self,optModel,j):
        """
        LB[j]*y1U[j] <= v_y1U[j] <= UB[j]*y1U[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return rxn.flux_bounds[0]*optModel.y1U[j] <= optModel.v_y1U[j]

    def linearize_v_y1U_const2_rule(self,optModel,j):
        """
        LB[j]*y1U[j] <= v_y1U[j] <= UB[j]*y1U[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v_y1U[j] <= rxn.flux_bounds[1]*optModel.y1U[j]

    def linearize_v_y1U_const3_rule(self,optModel,j):
        """
        x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        v[j] - (1 - y1U[j])*UB[j] <= v_y1U[j] <= v[j] - (1 - y1U[j])*LB[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v[j] - (1 - optModel.y1U[j])*rxn.flux_bounds[1] <= optModel.v_y1U[j]

    def linearize_v_y1U_const4_rule(self,optModel,j):
        """
        x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        v[j] - (1 - y1U[j])*UB[j] <= v_y1U[j] <= v[j] - (1 - y1U[j])*LB[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v_y1U[j] <= optModel.v[j] - (1 - optModel.y1U[j])*rxn.flux_bounds[0]

    #-- v[j]*y2U[j] --
    def linearize_v_y2U_const1_rule(self,optModel,j):
        """
        LB[j]*y2U[j] <= v_y2U[j] <= UB[j]*y2U[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return rxn.flux_bounds[0]*optModel.y2U[j] <= optModel.v_y2U[j]

    def linearize_v_y2U_const2_rule(self,optModel,j):
        """
        LB[j]*y2U[j] <= v_y2U[j] <= UB[j]*y2U[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v_y2U[j] <= rxn.flux_bounds[1]*optModel.y2U[j]

    def linearize_v_y2U_const3_rule(self,optModel,j):
        """
        x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        v[j] - (1 - y2U[j])*UB[j] <= v_y2U[j] <= v[j] - (1 - y2U[j])*LB[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v[j] - (1 - optModel.y2U[j])*rxn.flux_bounds[1] <= optModel.v_y2U[j]

    def linearize_v_y2U_const4_rule(self,optModel,j):
        """
        x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        v[j] - (1 - y2U[j])*UB[j] <= v_y2U[j] <= v[j] - (1 - y2U[j])*LB[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v_y2U[j] <= optModel.v[j] - (1 - optModel.y2U[j])*rxn.flux_bounds[0]

    #-- v[j]*y1L[j] --
    def linearize_v_y1L_const1_rule(self,optModel,j):
        """
        LB[j]*y1L[j] <= v_y1L[j] <= UB[j]*y1L[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return rxn.flux_bounds[0]*optModel.y1L[j] <= optModel.v_y1L[j]

    def linearize_v_y1L_const2_rule(self,optModel,j):
        """
        LB[j]*y1L[j] <= v_y1L[j] <= UB[j]*y1L[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v_y1L[j] <= rxn.flux_bounds[1]*optModel.y1L[j]

    def linearize_v_y1L_const3_rule(self,optModel,j):
        """
        x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        v[j] - (1 - y1L[j])*UB[j] <= v_y1L[j] <= v[j] - (1 - y1L[j])*LB[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v[j] - (1 - optModel.y1L[j])*rxn.flux_bounds[1] <= optModel.v_y1L[j]

    def linearize_v_y1L_const4_rule(self,optModel,j):
        """
        x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        v[j] - (1 - y1L[j])*UB[j] <= v_y1L[j] <= v[j] - (1 - y1L[j])*LB[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v_y1L[j] <= optModel.v[j] - (1 - optModel.y1L[j])*rxn.flux_bounds[0]


    #-- v[j]*y2L[j] --
    def linearize_v_y2L_const1_rule(self,optModel,j):
        """
        LB[j]*y2L[j] <= v_y2L[j] <= UB[j]*y2L[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return rxn.flux_bounds[0]*optModel.y2L[j] <= optModel.v_y2L[j]

    def linearize_v_y2L_const2_rule(self,optModel,j):
        """
        LB[j]*y2L[j] <= v_y2L[j] <= UB[j]*y2L[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v_y2L[j] <= rxn.flux_bounds[1]*optModel.y2L[j]

    def linearize_v_y2L_const3_rule(self,optModel,j):
        """
        x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        v[j] - (1 - y2L[j])*UB[j] <= v_y2L[j] <= v[j] - (1 - y2L[j])*LB[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v[j] - (1 - optModel.y2L[j])*rxn.flux_bounds[1] <= optModel.v_y2L[j]

    def linearize_v_y2L_const4_rule(self,optModel,j):
        """
        x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        v[j] - (1 - y2L[j])*UB[j] <= v_y2L[j] <= v[j] - (1 - y2L[j])*LB[j]

        The functions returns (lb, expr, ub) for a constraint in the form lb <= expor <= ub
        """
        rxn = self.shared_data.model.reactions_by_id[j]  # rxn object
        return optModel.v_y2L[j] <= optModel.v[j] - (1 - optModel.y2L[j])*rxn.flux_bounds[0]

    #--------------------------------------------------------
    #---------------- Create optimization models ------------        
    #--------------------------------------------------------
    def build_primal_optModel(self):
        """
        Creates a pyomo optimization model for the primal problem 
        """
        # Define parameters and scalars needed to define the optimizaiton problem
        self.define_optModel_params()

        # Create a pyomo model optimization model
        optModel = ConcreteModel()

        #--- Sets ---
        # Set of compounds 
        optModel.I = Set(initialize = [c.id for c in self.shared_data.model.compounds])

        # Set of rxns  
        optModel.J = Set(initialize = [r.id for r in self.shared_data.model.reactions])

        #--- Variables --- 
        # Reaction fluxes
        optModel.v = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)

        # Binary variables in for reactions that must be down-regulated (yL) or up-regulated (yU) 
        if self.MUST_double_type.lower() in ['must_lu','must_ul']:
            optModel.yL = Var(optModel.J, domain=Boolean)
            optModel.yU = Var(optModel.J, domain=Boolean)
        elif self.MUST_double_type.lower() == 'must_ll':
            optModel.y1L = Var(optModel.J, domain=Boolean)
            optModel.y2L = Var(optModel.J, domain=Boolean)
        elif self.MUST_double_type.lower() == 'must_uu':
            optModel.y1U = Var(optModel.J, domain=Boolean)
            optModel.y2U = Var(optModel.J, domain=Boolean)

        #--- Objective function ---
        if self.MUST_double_type.lower() in ['must_lu','must_ll']:
            optModel.objectiveFunc = Objective(rule=self.primal_objectiveFunc_rule, sense = maximize)
        if self.MUST_double_type.lower() in ['must_ul','must_uu']:
            optModel.objectiveFunc = Objective(rule=self.primal_objectiveFunc_rule, sense = minimize)

        #--- Constraints ----
        # Mass balance 
        optModel.massBalance_const = Constraint(optModel.I, rule=self.massBalance_const_rule)

        self.optModel = optModel

    def build_dual_optModel(self):
        """
        Creates a pyomo optimization model for the dual problem 
        """
        # Define parameters and scalars needed to define the optimizaiton problem
        self.define_optModel_params()

        # Create a pyomo model optimization model
        optModel = ConcreteModel()

        #--- Sets ---
        # Set of compounds 
        optModel.I = Set(initialize = [c.id for c in self.shared_data.model.compounds])

        # Set of rxns  
        optModel.J = Set(initialize = [r.id for r in self.shared_data.model.reactions])

        #--- Variables --- 
        # Dual variables associated with steady-state mass balance constraints
        # It's better to not provide upper and lower bound on lambda otherwise the dual objective 
        # will be slightly different from the primal's
        optModel.Lambda = Var(optModel.I, domain=Reals)

        # Dual variables associated with v_j >= LB_j and v_j <= UB_j
        optModel.muLB = Var(optModel.J, domain=Reals, bounds = (0,self._muLB_max))
        optModel.muUB = Var(optModel.J, domain=Reals, bounds = (0,self._muUB_max))

        # Product of binary variables and reaction fluxes 
        if self.MUST_double_type.lower() in ['must_lu','must_ul']:
            optModel.v_yL = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)
            optModel.v_yU = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)
        elif self.MUST_double_type.lower() == 'must_ll':
            optModel.v_y1L = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)
            optModel.v_y2L = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)
        elif self.MUST_double_type.lower() == 'must_uu':
            optModel.v_y1U = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)
            optModel.v_y2U = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)

        # Binary variables in for reactions that must be down-regulated (yL) or up-regulated (yU) 
        if self.MUST_double_type.lower() in ['must_lu','must_ul']:
            optModel.yL = Var(optModel.J, domain=Boolean)
            optModel.yU = Var(optModel.J, domain=Boolean)
        elif self.MUST_double_type.lower() == 'must_ll':
            optModel.y1L = Var(optModel.J, domain=Boolean)
            optModel.y2L = Var(optModel.J, domain=Boolean)
        elif self.MUST_double_type.lower() == 'must_uu':
            optModel.y1U = Var(optModel.J, domain=Boolean)
            optModel.y2U = Var(optModel.J, domain=Boolean)

        #--- Objective function ---
        if self.MUST_double_type.lower() in ['must_lu','must_ll']:
            optModel.objectiveFunc = Objective(rule=self.dual_objectiveFunc_rule, sense = minimize)
        if self.MUST_double_type.lower() in ['must_ul','must_uu']:
            optModel.objectiveFunc = Objective(rule=self.dual_objectiveFunc_rule, sense = maximize)

        #-- Constraints of the dual problem --
        # dual constraints 
        optModel.dual_const = Constraint(optModel.J, rule=self.dual_const_rule)

        # Constraints linearizing the product of v_j and binary variables 
        if self.MUST_double_type.lower() in ['must_lu','must_ul']:
            optModel.linearize_v_yL_const1 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yL_const1_rule)
            optModel.linearize_v_yL_const2 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yL_const2_rule)
            optModel.linearize_v_yL_const3 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yL_const3_rule)
            optModel.linearize_v_yL_const4 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yL_const4_rule)

            optModel.linearize_v_yU_const1 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yU_const1_rule)
            optModel.linearize_v_yI_const2 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yU_const2_rule)
            optModel.linearize_v_yU_const3 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yU_const3_rule)
            optModel.linearize_v_yU_const4 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yU_const4_rule)

        elif self.MUST_double_type.lower() in 'must_uu':
            optModel.linearize_v_y1U_const1 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1U_const1_rule)
            optModel.linearize_v_y1U_const2 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1U_const2_rule)
            optModel.linearize_v_y1U_const3 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1U_const3_rule)
            optModel.linearize_v_y1U_const4 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1U_const4_rule)

            optModel.linearize_v_y2U_const1 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2U_const1_rule)
            optModel.linearize_v_y2U_const2 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2U_const2_rule)
            optModel.linearize_v_y2U_const3 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2U_const3_rule)
            optModel.linearize_v_y2U_const4 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2U_const4_rule)

        elif self.MUST_double_type.lower() in 'must_ll':
            optModel.linearize_v_y1L_const1 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1L_const1_rule)
            optModel.linearize_v_y1L_const2 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1L_const2_rule)
            optModel.linearize_v_y1L_const3 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1L_const3_rule)
            optModel.linearize_v_y1L_const4 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1L_const4_rule)

            optModel.linearize_v_y2L_const1 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2L_const1_rule)
            optModel.linearize_v_y2L_const2 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2L_const2_rule)
            optModel.linearize_v_y2L_const3 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2L_const3_rule)
            optModel.linearize_v_y2L_const4 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2L_const4_rule)

        self.optModel = optModel

    def build_bilevel_optModel(self):
        """
        Creates a pyomo optimization model for the bilevel problem 
        """
        # Define parameters and scalars needed to define the optimizaiton problem
        self.define_optModel_params()

        # Create a pyomo model optimization model
        optModel = ConcreteModel()

        #------------------ Sets -----------------------
        # Set of compounds 
        optModel.I = Set(initialize = [c.id for c in self.shared_data.model.compounds])

        # Set of rxns  
        optModel.J = Set(initialize = [r.id for r in self.shared_data.model.reactions])

        #----------------- Variables -------------------
        #-- Variables of the primal problem --
        # Reaction fluxes
        optModel.v = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)

        # Binary variables in for reactions that must be down-regulated (yL) or up-regulated (yU) 
        if self.MUST_double_type.lower() in ['must_lu','must_ul']:
            optModel.yL = Var(optModel.J, domain=Boolean)
            optModel.yU = Var(optModel.J, domain=Boolean)
        elif self.MUST_double_type.lower() == 'must_ll':
            optModel.y1L = Var(optModel.J, domain=Boolean)
            optModel.y2L = Var(optModel.J, domain=Boolean)
        elif self.MUST_double_type.lower() == 'must_uu':
            optModel.y1U = Var(optModel.J, domain=Boolean)
            optModel.y2U = Var(optModel.J, domain=Boolean)

        #-- Variables of the primal problem --
        # Dual variables associated with steady-state mass balance constraints
        # It's better to not provide upper and lower bound on lambda otherwise the dual objective 
        # will be slightly different from the primal's
        optModel.Lambda = Var(optModel.I, domain=Reals)

        # Dual variables associated with v_j >= LB_j and v_j <= UB_j
        optModel.muLB = Var(optModel.J, domain=Reals, bounds = (0,self._muLB_max))
        optModel.muUB = Var(optModel.J, domain=Reals, bounds = (0,self._muUB_max))

        # Product of binary variables and reaction fluxes 
        if self.MUST_double_type.lower() in ['must_lu','must_ul']:
            optModel.v_yL = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)
            optModel.v_yU = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)
        elif self.MUST_double_type.lower() == 'must_ll':
            optModel.v_y1L = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)
            optModel.v_y2L = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)
        elif self.MUST_double_type.lower() == 'must_uu':
            optModel.v_y1U = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)
            optModel.v_y2U = Var(optModel.J, domain=Reals, bounds = self.assignFluxBounds)

        #------ Objective function of the outer problem ------
        optModel.objectiveFunc = Objective(rule = self.outer_objectiveFunc_rule, sense = maximize)

        #---------------- Constraints ----------------------
        #-- Constraints of the outer problem --
        # Only one yL or yU can be one at a time and each rxn can participate in only L or U set 
        if self.MUST_double_type.lower() in ['must_lu','must_ll']:
            optModel.onlyOne_yL_isOne_const = Constraint(rule=self.onlyOne_yL_isOne_const_rule)
            optModel.onlyOne_yU_isOne_const = Constraint(rule=self.onlyOne_yU_isOne_const_rule)
            optModel.each_rxn_yLyU_const = Constraint(optModel.J, rule=self.each_rxn_yLyU_const_rule)
        elif self.MUST_double_type.lower() == 'must_uu':
            optModel.onlyOne_y1U_isOne_const = Constraint(rule=self.onlyOne_y1U_isOne_const_rule)
            optModel.onlyOne_y2U_isOne_const = Constraint(rule=self.onlyOne_y2U_isOne_const_rule)
            optModel.each_rxn_y1Uy2U_const = Constraint(optModel.J, rule=self.each_rxn_y1Uy2U_const_rule)
        elif self.MUST_double_type.lower() == 'must_ll':
            optModel.onlyOne_y1L_isOne_const = Constraint(rule=self.onlyOne_y1L_isOne_const_rule)
            optModel.onlyOne_y2L_isOne_const = Constraint(rule=self.onlyOne_y2L_isOne_const_rule)
            optModel.each_rxn_y1Ly2L_const = Constraint(optModel.J, rule=self.each_rxn_y1Ly2L_const_rule)

        # Integer cuts
        optModel.integer_cuts = ConstraintList(noruleinit=True)
         
        #-- Constraints of the primal problem --
        # Mass balance 
        optModel.massBalance_const = Constraint(optModel.I, rule=self.massBalance_const_rule)

        # Constraints linearizing the product of v_j and binary variables 
        if self.MUST_double_type.lower() in ['must_lu','must_ul']:
            optModel.linearize_v_vL_const1 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yL_const1_rule)
            optModel.linearize_v_vL_const2 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yL_const2_rule)
            optModel.linearize_v_vL_const3 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yL_const3_rule)
            optModel.linearize_v_vL_const4 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yL_const4_rule)

            optModel.linearize_v_yU_const1 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yU_const1_rule)
            optModel.linearize_v_yU_const2 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yU_const2_rule)
            optModel.linearize_v_yU_const3 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yL_const3_rule)
            optModel.linearize_v_yU_const4 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_yL_const4_rule)

        elif self.MUST_double_type.lower() in 'must_uu':
            optModel.linearize_v_y1U_const1 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1U_const1_rule)
            optModel.linearize_v_y1U_const2 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1U_const2_rule)
            optModel.linearize_v_y1U_const3 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1U_const3_rule)
            optModel.linearize_v_y1U_const4 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1U_const4_rule)

            optModel.linearize_v_y2U_const1 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2U_const1_rule)
            optModel.linearize_v_y2U_const2 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2U_const2_rule)
            optModel.linearize_v_y2U_const3 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2U_const3_rule)
            optModel.linearize_v_y2U_const4 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2U_const4_rule)

        elif self.MUST_double_type.lower() in 'must_ll':
            optModel.linearize_v_y1LB_const1 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1L_const1_rule)
            optModel.linearize_v_y1LB_const2 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1L_const2_rule)
            optModel.linearize_v_y1LB_const3 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1L_const3_rule)
            optModel.linearize_v_y1LB_const4 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y1L_const4_rule)

            optModel.linearize_v_y2L_const1 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2L_const1_rule)
            optModel.linearize_v_y2L_const2 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2L_const2_rule)
            optModel.linearize_v_y2L_const3 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2L_const3_rule)
            optModel.linearize_v_y2L_const4 = Constraint([j for j in optModel.J if j not in self._ignore], rule=self.linearize_v_y2L_const4_rule)

        #-- Constraints of the dual problem --
        # dual constraints 
        optModel.dual_const = Constraint(optModel.J, rule=self.dual_const_rule)

        #-- Strong duality -- 
        optModel.strong_duality_const = Constraint(rule=self.strong_duality_const_rule)

        self.optModel = optModel

    def fix_known_variables(self):
        """
        Fixies all known binary variables to zero/one
        """
        if self.MUST_double_type.lower() in ['must_lu','must_ul']:
            for rxn in self._ignore:
                self.optModel.yL[rxn] = 0
                self.optModel.yL[rxn].fixed = True
                self.optModel.v_yL[rxn] = 0
                self.optModel.v_yL[rxn].fixed = True

                self.optModel.yU[rxn] = 0
                self.optModel.yU[rxn].fixed = True
                self.optModel.v_yU[rxn] = 0
                self.optModel.v_yU[rxn].fixed = True

        elif self.MUST_double_type.lower() in 'must_uu':
            for rxn in self._ignore:
                self.optModel.y1U[rxn] = 0
                self.optModel.y1U[rxn].fixed = True
                self.optModel.v_y1U[rxn] = 0
                self.optModel.v_y1U[rxn].fixed = True

                self.optModel.y2U[rxn] = 0
                self.optModel.y2U[rxn].fixed = True
                self.optModel.v_y2U[rxn] = 0
                self.optModel.v_y2U[rxn].fixed = True

        elif self.MUST_double_type.lower() in 'must_ll':
            for rxn in self._ignore:
                self.optModel.y1L[rxn] = 0
                self.optModel.y1L[rxn].fixed = True
                self.optModel.v_y1L[rxn] = 0
                self.optModel.v_y1L[rxn].fixed = True

                self.optModel.y2L[rxn] = 0
                self.optModel.y2L[rxn].fixed = True
                self.optModel.v_y2L[rxn] = 0
                self.optModel.v_y2L[rxn].fixed = True

    def run_single(self):
        """
        Performs a single run of the code
        """
        # Processing and wall time for pyomo
        start_preproc_pyomo_pt = time.clock()
        start_preproc_pyomo_wt = time.time()

        # Instantiate the optModel
        self.optModel.preprocess()

        elapsed_preproc_pyomo_pt = str(timedelta(seconds = time.clock() - start_preproc_pyomo_pt))
        elapsed_preproc_pyomo_wt = str(timedelta(seconds = time.time() - start_preproc_pyomo_wt))

        #---- Solve the model ----
        #- Solve the optModel (tee=True shows the solver output) -
        try:
            # Processing and wall time for the solver
            start_solver_pt = time.clock()
            start_solver_wt = time.time()
            OptSoln = self._solverType.solve(self.optModel,tee=False)
            solverFlag = 'normal'

        # In the case of an error switch the solver
        except  Exception, e:
            if self.warnings:
                print '**WARNING (MUST_doubles)! {} failed with the following error: \n{} \nAn alternative solver is tried'.format(self.shared_data.optimization_solver,e)

            if self.shared_data.optimization_solver.lower() == 'gurobi':
                new_solver = 'cplex'
            elif self.shared_data.optimization_solver.lower() == 'cplex':
                new_solver = 'gurobi'

            # Try solving with the alternative solver
            solverType = pyomoSolverCreator(new_solver)
            try:
                start_solver_pt = time.clock()
                start_solver_wt = time.time()
                OptSoln = solverType.solve(self.optModel,tee=False)
                solverFlag = 'normal'
            except   Exception, e:
                solverFlag = 'solverError'
                if self.warnings:
                    print '**WARNING (break_cycle.py)! {} failed with the following error: \n{} \nAn alternative solver is tried'.format(new_solver,e)

        elapsed_solver_pt = str(timedelta(seconds = time.clock() - start_solver_pt))
        elapsed_solver_wt = str(timedelta(seconds = time.time() - start_solver_wt))

        #----- Print the results in the output ------
        if solverFlag == 'normal' and str(OptSoln.solver.termination_condition).lower() == 'optimal':

            exit_flag = 'globallyOptimal'

            # Load the results
            self.optModel.load(OptSoln)

            # Optimal value of the objective function
            opt_objValue = self.optModel.objectiveFunc()

            # Print the results on the screen 
            if self.stdout_msgs:
                print "\nSolver.status = ",OptSoln.solver.termination_condition
                print "Optimality status = ",exit_flag
                print "Objective value = ",opt_objValue

            # List of reactions for which yL or yU is one 
            # NOTE: Instead of checking if binary variables are exactly equal to one, we check whether the difference 
            # between a binary variable and one is less than a threshold. This is because sometimes the solver stops with 
            # a binary variable that is not eactly one or zero according to the specified integrality tolerence used
            if self.MUST_double_type.lower() in ['must_lu','must_ul']:
                one_yLopt_rxns = [j for j in self.optModel.J if abs(self.optModel.yL[j].value - 1) <= mip_integrality_tol] 
                one_yUopt_rxns = [j for j in self.optModel.J if abs(self.optModel.yU[j].value - 1) <= mip_integrality_tol] 

                # self._yLopt_curr and self._yUopt_curr hold the optimal value of the binary variables at the
                # current interation
                self._yLopt_curr = {}
                self._yUopt_curr = {}
                for j in self.optModel.J:
                    self._yLopt_curr[j] = 0
                    self._yUopt_curr[j] = 0
                for j in one_yLopt_rxns:
                    self._yLopt_curr[j] = 1
                for j in one_yUopt_rxns:
                    self._yUopt_curr[j] = 1

            elif self.MUST_double_type.lower() in 'must_uu':
                one_y1Uopt_rxns = [j for j in self.optModel.J if abs(self.optModel.y1U[j].value - 1) <= mip_integrality_tol] 
                one_y2Uopt_rxns = [j for j in self.optModel.J if abs(self.optModel.y2U[j].value - 1) <= mip_integrality_tol] 

                # self._y1Uopt_curr and self._y2Uopt_curr hold the optimal value of the binary variables at the
                # current interation
                self._y1Uopt_curr = {}
                self._y2Uopt_curr = {}
                for j in self.optModel.J:
                    self._y1Uopt_curr[j] = 0
                    self._y2Uopt_curr[j] = 0
                for j in one_y1Uopt_rxns:
                    self._y1Uopt_curr[j] = 1
                for j in one_y2Uopt_rxns:
                    self._y2Uopt_curr[j] = 1

            elif self.MUST_double_type.lower() in 'must_ll':
                one_y1Lopt_rxns = [j for j in self.optModel.J if abs(self.optModel.y1L[j].value - 1) <= mip_integrality_tol] 
                one_y2Lopt_rxns = [j for j in self.optModel.J if abs(self.optModel.y2L[j].value - 1) <= mip_integrality_tol] 

                # self._y1Lopt_curr and self._y2Lopt_curr hold the optimal value of the binary variables at the
                # current interation
                self._y1Lopt_curr = {}
                self._y2Lopt_curr = {}
                for j in self.optModel.J:
                    self._y1Lopt_curr[j] = 0
                    self._y2Lopt_curr[j] = 0
                for j in one_y1Lopt_rxns:
                    self._y1Lopt_curr[j] = 1
                for j in one_y2Lopt_rxns:
                    self._y2Lopt_curr[j] = 1

        # If there was a solver error or if an optimal solution was not returned 
        else:
            if solverFlag == 'solverError':
                exit_flag = solverFlag
            else:
                exit_flag = str(OptSoln.solver.termination_condition)

            opt_objValue = None
            if self.MUST_double_type.lower() in ['must_lu','must_ul']:
                one_yLopt_rxns = []
                one_yUopt_rxns = []
            elif self.MUST_double_type.lower() in 'must_uu':
                one_y1Uopt_rxns = []
                one_y2Uopt_rxns = []
            elif self.MUST_double_type.lower() in 'must_ll':
                one_y1Lopt_rxns = []
                one_y2Lopt_rxns = []

            if self.stdout_msgs:
                print "\n\n** No optimal solutions found (solution.solver.status = ",OptSoln.Solution.status,", solver.status =",OptSoln.solver.status,", solver.termination_condition = ",OptSoln.solver.termination_condition,")\n"

        #---- Solution ----
        if self.MUST_double_type.lower() in ['must_lu','must_ul']:
            self._curr_soln = {'exit_flag':exit_flag,'objective_value':opt_objValue,'one_yLopt_rxns':one_yLopt_rxns,'one_yUopt_rxns':one_yUopt_rxns}

        elif self.MUST_double_type.lower() in 'must_uu':
            self._curr_soln = {'exit_flag':exit_flag,'objective_value':opt_objValue,'one_y1Uopt_rxns':one_y1Uopt_rxns,'one_y2Uopt_rxns':one_y2Uopt_rxns}

        elif self.MUST_double_type.lower() in 'must_ll':
            self._curr_soln = {'exit_flag':exit_flag,'objective_value':opt_objValue,'one_y1Lopt_rxns':one_y1Lopt_rxns,'one_y2Lopt_rxns':one_y2Lopt_rxns}

        if self.stdout_msgs:
           print 'Time elapsed (processing/wall) time (hh:mm:ss): Preprocess pyomo model = {}/{}  ,  solver = {}/{}\n'.format(elapsed_preproc_pyomo_pt,elapsed_preproc_pyomo_wt,elapsed_solver_pt,elapsed_solver_wt)

    def validate_soln(self):
        """
        This function validates the obtained results
        """
        # MUST_LU:  Max_OP(v1 - v2) < Min_WT(v1 - v2)
        if self.MUST_double_type.lower() == 'must_lu':
            if len(self._curr_soln['one_yLopt_rxns']) != 1:
                raise userError('Length of one_yLopt_rxns is not one! len(one_yLopt_rxns) = {}'.format(len(self._curr_soln['one_yLopt_rxns'])))
            else:
                L_rxn = self._curr_soln['one_yLopt_rxns'][0]                   

                if (L_rxn in self.shared_data.MUST_X) or (L_rxn in self.shared_data.MUST_L) or (L_rxn in self.shared_data.MUST_U):
                    raise userError('L_rxn {} appears in MUST_L or MUST_U or MUST_X'.format(L_rxn)) 

            if len(self._curr_soln['one_yUopt_rxns']) != 1: 
                raise userError('Length of one_yUopt_rxns is not one! len(one_yUopt_rxns) = {}'.format(len(self._curr_soln['one_yUopt_rxns'])))
            else:
                U_rxn = self._curr_soln['one_yUopt_rxns'][0]   

                if (U_rxn in self.shared_data.MUST_X) or (U_rxn in self.shared_data.MUST_L) or (U_rxn in self.shared_data.MUST_U):
                    raise userError('U_rxn {} appears in MUST_L or MUST_U or MUST_X'.format(U_rxn)) 

            if (self.shared_data.flux_bounds_ref[L_rxn][0] - self.shared_data.flux_bounds_ref[U_rxn][1]) - (self.optModel.v_yL[L_rxn].value - self.optModel.v_yU[U_rxn].value) < self.objective_thr:
                raise userError('Min_WT(v1 - v2) - Max_OP(v1 - v2) = ({}) - ({}) = {} is not less than objective_thr = {} for L_rxn = {}, U_rxn = {}'.format(self.shared_data.flux_bounds_ref[L_rxn][0] - self.shared_data.flux_bounds_ref[U_rxn][1], self.optModel.v_yL[L_rxn].value - self.optModel.v_yU[U_rxn].value, (self.shared_data.flux_bounds_ref[L_rxn][0] - self.shared_data.flux_bounds_ref[U_rxn][1]) - (self.optModel.v_yL[L_rxn].value - self.optModel.v_yU[U_rxn].value), self.objective_thr, L_rxn, U_rxn)) 

        # MUST_UL: Min_OP(v1 - v2) > Max_WT(v1 - v2)
        elif self.MUST_double_type.lower() == 'must_ul':
            if len(self._curr_soln['one_yLopt_rxns']) != 1:
                raise userError('Length of one_yLopt_rxns is not one! len(one_yLopt_rxns) = {}'.format(len(self._curr_soln['one_yLopt_rxns'])))
            else: 
                L_rxn = self._curr_soln['one_yLopt_rxns'][0]                   

            if len(self._curr_soln['one_yUopt_rxns']) != 1: 
                raise userError('Length of one_yUopt_rxns is not one! len(one_yUopt_rxns) = {}'.format(len(self._curr_soln['one_yUopt_rxns'])))
            else: 
                U_rxn = self._curr_soln['one_yUopt_rxns'][0]   

            if (self.optModel.v_yU[U_rxn].value - self.optModel.v_yL[L_rxn].value) - (self.shared_data.flux_bounds_ref[U_rxn][1] - self.shared_data.flux_bounds_ref[L_rxn][0]) < self.objective_thr:
                raise userError('Min_OP(v1 - v2) - Max_WT(v1 - v2) = ({}) - ({}) = {} is not less than objective_thr = {} for U_rxn = {} , L_rxn = {}'.format(self.optModel.v_yU[U_rxn].value - self.optModel.v_yL[L_rxn].value, self.shared_data.flux_bounds_ref[U_rxn][1] - self.shared_data.flux_bounds_ref[L_rxn][0], (self.optModel.v_yU[U_rxn].value - self.optModel.v_yL[L_rxn].value) - (self.shared_data.flux_bounds_ref[U_rxn][1] - self.shared_data.flux_bounds_ref[L_rxn][0]), self.objective_thr, U_rxn, L_rxn))

        # MUST_UU: Min_OP(v1 + v2) > Max_WT(v1 + v2)
        elif self.MUST_double_type.lower() == 'must_uu':
            if len(self._curr_soln['one_y1Uopt_rxns']) != 1:
                raise userError('Length of one_y1Uopt_rxns is not one! len(one_y1Uopt_rxns) = {}'.format(len(self._curr_soln['one_y1Uopt_rxns'])))
            else:
                U1_rxn = self._curr_soln['one_y1Uopt_rxns'][0]                   

                if (U1_rxn in self.shared_data.MUST_X) or (U1_rxn in self.shared_data.MUST_L) or (U1_rxn in self.shared_data.MUST_U):
                    raise userError('U1_rxn {} appears in MUST_L or MUST_U or MUST_X'.format(U1_rxn)) 

            if len(self._curr_soln['one_y2Uopt_rxns']) != 1:
                raise userError('Length of one_y2Uopt_rxns is not one! len(one_y2Uopt_rxns) = {}'.format(len(self._curr_soln['one_y1Uopt_rxns'])))
            else:
                U2_rxn = self._curr_soln['one_y2Uopt_rxns'][0]   

                if (U2_rxn in self.shared_data.MUST_X) or (U2_rxn in self.shared_data.MUST_L) or (U2_rxn in self.shared_data.MUST_U):
                    raise userError('U2_rxn {} appears in MUST_L or MUST_U or MUST_X'.format(U2_rxn)) 

            if (self.optModel.v_y1U[U1_rxn].value + self.optModel.v_y2U[U2_rxn].value) -  (self.shared_data.flux_bounds_ref[U1_rxn][1] + self.shared_data.flux_bounds_ref[U2_rxn][1]) < self.objective_thr:
                raise userError('Min_OP(v1 + v2) - Max_WT(v1 + v2) = ({}) - ({}) = {} is not less than objective_thr = {} for U1_rxn = {} , U2_rxn = {}'.format(self.optModel.v_y1U[U1_rxn].value + self.optModel.v_y2U[U2_rxn].value, self.shared_data.flux_bounds_ref[U1_rxn][1] + self.shared_data.flux_bounds_ref[U2_rxn][1], (self.optModel.v_y1U[U1_rxn].value + self.optModel.v_y2U[U2_rxn].value) -  (self.shared_data.flux_bounds_ref[U1_rxn][1] + self.shared_data.flux_bounds_ref[U2_rxn][1]), self.objective_thr, U1_rxn, U2_rxn))    

        # MUST_LL: Max_OP(v1 + v2) < Min_WT(v1 + v2)
        elif self.MUST_double_type.lower() == 'must_ll':
            if len(self._curr_soln['one_y1Lopt_rxns']) != 1:
                raise userError('Length of one_y1Lopt_rxns is not one! len(one_y1Lopt_rxns) = {}'.format(len(self._curr_soln['one_y1Lopt_rxns'])))
            else:  
                L1_rxn = self._curr_soln['one_y1Lopt_rxns'][0]                   

                if (L1_rxn in self.shared_data.MUST_X) or (L1_rxn in self.shared_data.MUST_L) or (L1_rxn in self.shared_data.MUST_U):
                    raise userError('L1_rxn {} appears in MUST_L or MUST_U or MUST_X'.format(L1_rxn)) 

            if len(self._curr_soln['one_y2Lopt_rxns']) != 1:
                raise userError('Length of one_y2Lopt_rxns is not one! len(one_y2Lopt_rxns) = {}'.format(len(self._curr_soln['one_y2Lopt_rxns'])))
            else: 
                L2_rxn = self._curr_soln['one_y2Lopt_rxns'][0]   

                if (L2_rxn in self.shared_data.MUST_X) or (L2_rxn in self.shared_data.MUST_L) or (L2_rxn in self.shared_data.MUST_U):
                    raise userError('L2_rxn {} appears in MUST_L or MUST_U or MUST_X'.format(L2_rxn)) 

            if (self.shared_data.flux_bounds_ref[L1_rxn][0] + self.shared_data.flux_bounds_ref[L1_rxn][0]) - (self.optModel.v_y1L[L1_rxn].value + self.optModel.v_y2U[L2_rxn].value) < self.objective_thr:
                raise userError('Min_WT(v1 + v2) - Max_OP(v1 + v2) = ({}) - ({}) = {} is not less than objective_thr = {} for L1_rxn = {} , L2_rxn = {}'.format(self.shared_data.flux_bounds_ref[L1_rxn][0] + self.shared_data.flux_bounds_ref[L2_rxn][0], self.optModel.v_y1L[L1_rxn].value + self.optModel.v_y2L[L2_rxn].value), (self.shared_data.flux_bounds_ref[L1_rxn][0] + self.shared_data.flux_bounds_ref[L2_rxn][0]) - (self.optModel.v_y1L[L1_rxn].value + self.optModel.v_y2L[L2_rxn]).value, self.objective_thr, L1_rxn, L2_rxn)     

    def run(self, optModel_name = 'bilevel', max_solution_num = 1e5):
        """ 
        This method runs FBA. 

        INPUTS:
        -------
               optModel_name: Name of the optimizaiton model to solve
            max_solution_num: Total number of solutions to return. The default is a very large numbr meaning that it will return
                              all possible solutions
        OUTPUT:
        -------
        solution: A list of dictionaries with the following keys:
                        exit_flag: A string, which can be 'globallyOptimal', 'solverError'
                                   or what is stored in OptSoln.solver.termination_condition
                  objective_value: Optimal objective funtion value
                 one_yLopt_rxns: List of reactions for which the optimal value of yL is one
                 one_yUopt_rxns: List of reactions for which the optimal value of yU is one
        """
        # Total processing and wall time required to create the pyomo model, solve it and store the results 
        start_total_pt = time.clock()
        start_total_wt = time.time()

        self.solution = []

        # Number of solutions found so far
        found_solutions_num = 0

        #---- Creating the pyomo optModel ----
        if self.build_new_optModel:
            start_pyomo_pt = time.clock()
            start_pyomo_wt = time.time()
            # Create the pyomo model optModel only if self.build_new_optModel == 1        
            if optModel_name.lower() == 'bilevel':
                self.build_bilevel_optModel()
            elif optModel_name.lower() == 'primal':
                self.build_primal_optModel()
            elif optModel_name.lower() == 'dual':
                self.build_dual_optModel()
            else:
                raise ValueError("Invalid optModel_name value. Allowed choices are 'bilevel', 'primal' and 'dual'")
            # Time to create a pyomo model
            elapsed_create_pyomo_pt = str(timedelta(seconds = time.clock() - start_pyomo_pt))
            elapsed_create_pyomo_wt = str(timedelta(seconds = time.time() - start_pyomo_wt))

        # Fix known variables
        self.fix_known_variables()

        # Create a solver and set the options
        self._solverType = pyomoSolverCreator(self.shared_data.optimization_solver)

        # results file
        if self.results_filename != '':
            if self.create_new_results_file:
                file_opener = 'w'
            else:
                file_opener = 'a'
            with open(self.results_filename,file_opener) as f:
                f.write('\n' + self.MUST_double_type + '_details = [\n')

        # A list of dictionaries holding the optimal solution in different iterations
        self.solutions = []

        done = False
        while not done:
            # Solve the optimizaiton model 
            self.run_single()

            # Check whether the current run was successful
            if self._curr_soln['exit_flag'] == 'globallyOptimal':

                if self._curr_soln['objective_value'] < self.objective_thr:
                    done = True
                    self.termination_condition = 'Objective function ({}) greater than objective_thr ({})'.format(self._curr_soln['objective_value'],self.objective_thr)
                else:
                    # Validate the solution
                    if self.validate_results:
                        self.validate_soln()

                    self.solutions.append(self._curr_soln)

                    # Add integer cut
                    self.optModel.integer_cuts.add(self.integer_cuts_rule(optModel = self.optModel))
                    found_solutions_num += 1

                    if self.stdout_msgs:
                       print '{} solutions found'.format(found_solutions_num)

                    # Write results into the file
                    if self.results_filename != '':
                        with open(self.results_filename,'a') as f:
                            # MUST_LU:  Max_OP(v1 - v2) < Min_WT(v1 - v2)
                            if self.MUST_double_type.lower() in 'must_lu':
                                L_rxn = self._curr_soln['one_yLopt_rxns'][0]                   
                                U_rxn = self._curr_soln['one_yUopt_rxns'][0]   
                                f.write("{{'L':{}, 'U':{}, 'Min_WT(v1 - v2)':{}, 'Max_OP(v1 - v2)':{}}},\n".format(L_rxn,U_rxn, self.shared_data.flux_bounds_ref[L_rxn][0] - self.shared_data.flux_bounds_ref[U_rxn][1], self.optModel.v_yL[L_rxn].value - self.optModel.v_yU[U_rxn].value))     
            
                            # MUST_UL: Min_OP(v1 - v2) > Max_WT(v1 - v2)
                            elif self.MUST_double_type.lower() in 'must_ul':
                                L_rxn = self._curr_soln['one_yLopt_rxns'][0]                   
                                U_rxn = self._curr_soln['one_yUopt_rxns'][0]   
                                f.write("{{'U':{}, 'L':{}, 'Min_OP(v1 - v2)':{}, 'Max_WT(v1 - v2)':{}}},\n".format(U_rxn,L_rxn, self.optModel.v_yU[U_rxn].value - self.optModel.v_yL[L_rxn].value, self.shared_data.flux_bounds_ref[U_rxn][1] - self.shared_data.flux_bounds_ref[L_rxn][0]))      
 
                            # MUST_UU: Min_OP(v1 + v2) > Max_WT(v1 + v2)
                            elif self.MUST_double_type.lower() in 'must_uu':
                                U1_rxn = self._curr_soln['one_y1Uopt_rxns'][0] 
                                U2_rxn = self._curr_soln['one_y2Uopt_rxns'][0]   
                                f.write("{{'U1':{}, 'U2':{}, 'Min_OP(v1 + v2)':{}, 'Max_WT(v1 + v2)':{}}},\n".format(U1_rxn,U2_rxn, self.optModel.v_y1U[U1_rxn].value + self.optModel.v_y2U[U2_rxn].value, self.shared_data.flux_bounds_ref[U1_rxn][1] + self.shared_data.flux_bounds_ref[U2_rxn][1]))    
            
                            # MUST_LL: Max_OP(v1 + v2) < Min_WT(v1 + v2)
                            elif self.MUST_double_type.lower() in 'must_ll':
                                L1_rxn = self._curr_soln['one_y1Lopt_rxns'][0]  
                                L2_rxn = self._curr_soln['one_y2Lopt_rxns'][0]   
                                f.write("{{'L1':{}, 'L2':{}, 'Min_WT(v1 - v2)':{}, 'Max_OP(v1 - v2)':{}}},\n".format(L1_rxn,L2_rxn, self.shared_data.flux_bounds_ref[L_rxn][0] + self.shared_data.flux_bounds_ref[U_rxn][0], self.optModel.v_y1L[L1_rxn].value + self.optModel.v_y2U[L2_rxn].value))     

                    if found_solutions_num >= max_solution_num:
                        done = True
                        self.termination_condition = 'max_solution_num of {} was reached'.format(max_solution_num)

            else:
                done = True 
                self.termination_condition = 'Optimization problem was not solved to optimality: {}:'.format(self._curr_soln['exit_flag'])

        # Time required to perform FBA
        elapsed_total_pt = str(timedelta(seconds = time.clock() - start_total_pt))
        elapsed_total_wt = str(timedelta(seconds = time.time() - start_total_wt))

        if self.stdout_msgs:
           print 'MUST_doubles elapsed (processing/wall) time (hh:mm:ss): create pyomo model = {}/{}  ,  total = {}/{}\n'.format(elapsed_create_pyomo_pt,elapsed_create_pyomo_wt,elapsed_total_pt,elapsed_total_wt)

        if self.results_filename != '':
            with open(self.results_filename,'a') as f:
                f.write(']\n')

        return (self.solutions, self.termination_condition)


class shared_data_holder(object):
    """
    A class storing the data that should be shared among the main OptForce class and the
    classes finding MUST doubles and FORCE sets of reactions. This class just facilitates
    data sharing among the three aformentioned classes.
    """
    def __init__(self, model, product_exchrxn_id, exp_flux_bounds, product_targetYield_percent = 80, min_biomass_percent = 10, growthMedium_flux_bounds = {'flux_bounds_filename':None, 'flux_bounds_dict': {}}, save_flux_bounds_toThisFile = '', read_flux_bounds_fromThisFile = '', save_MUST_singles_toThisFile = '', read_MUST_singles_fromThisFile = '', save_MUST_doubles_toThisFile = '', read_MUST_doubles_fromThisFile = '', save_FORCE_sets_toThisFile = '', optimization_solver = 'gurobi', simulation_condition = '', stdout_msgs = True, warnings = True):

        # Metabolic model
        self.model = model

        # Biomass reaction id
        self.biomass_rxn_id = self.model.biomass_reaction.id

        # Id of the exchange reaction for the product of interest
        self.product_exchrxn_id = product_exchrxn_id

        # Target yeild
        self.product_targetYield_percent = product_targetYield_percent

        # Minimum biomass formation
        self.min_biomass_percent = min_biomass_percent

        # Experimental flux data
        self.exp_flux_bounds = exp_flux_bounds

        # Flux bounds for exchange reactions corresponding to compounds present in the growth medium
        self.growthMedium_flux_bounds = growthMedium_flux_bounds

        # Solver name
        self.optimization_solver = optimization_solver

        # Simulation conditions
        self.simulation_condition = simulation_condition

        # File names holding the flux bounds, MUST single and MUST doulbe sets
        self.read_flux_bounds_fromThisFile = read_flux_bounds_fromThisFile
        self.save_flux_bounds_toThisFile = save_flux_bounds_toThisFile
        self.read_MUST_singles_fromThisFile = read_MUST_singles_fromThisFile
        self.save_MUST_singles_toThisFile = save_MUST_singles_toThisFile
        self.read_MUST_doubles_fromThisFile = read_MUST_doubles_fromThisFile
        self.save_MUST_doubles_toThisFile = save_MUST_doubles_toThisFile

        # Warnings and messages in the standard output
        self.stdout_msgs = stdout_msgs
        self.warnings = warnings

    def __setattr__(self,attr_name,attr_value):
        """
        Redefines funciton __setattr__
        INPUTS:
        -------
         attr_name: Attribute name
        attr_value: Attribute value
        """
        # model 
        if attr_name == 'model' and not isinstance(attr_value,model):
            raise TypeError('model must be instance of class model')

        # product_exchrxn_id 
        if attr_name == 'product_exchrxn_id' and not isinstance(attr_value,str):
            raise TypeError('product_exchrxn_id must be a string')

        # product_targetYield_percent
        if attr_name == 'product_targetYield_percent' and (not isinstance(attr_value,int) and not isinstance(attr_value,float)):
            raise TypeError('product_targetYield_percent must be an integer or a float')
        if attr_name == 'product_targetYield_percent' and (attr_value < 0 or attr_value > 100): 
            raise ValueError('product_targetYield_percent must be between 0 and 100')

        # min_biomass_percent 
        if attr_name == 'min_biomass_percent' and (not isinstance(attr_value,int) and not isinstance(attr_value,float)):
            raise TypeError('min_biomass_percent must be an integer or a float')
        if attr_name == 'min_biomass_percent' and (attr_value < 0 or attr_value > 100): 
            raise ValueError('min_biomass_percent must be between 0 and 100')

        # exp_flux_bounds
        if attr_name == 'exp_flux_bounds' and not isinstance(attr_value,dict):
            raise TypeError('exp_flux_bounds must be a dictionary')

        # growthMedium_flux_bounds 
        if attr_name == 'growthMedium_flux_bounds' and not isinstance(attr_value,dict): 
            raise TypeError('growthMedium_flux_bounds must be a dictionary')
        if attr_name == 'growthMedium_flux_bounds' and len([k for k in attr_value.keys() if k.lower() not in ['flux_bounds_filename','flux_bounds_dict']]) > 0: 
            raise ValueError('Invalid key for growthMedium_flux_bounds. Allowed keys are flux_bounds_filename and flux_bounds_dict')

        # Solver name
        if attr_name == 'optimization_solver' and attr_value.lower() not in ['cplex','gurobi']:
            raise userError('Invalid solver name (eligible choices are cplex and gurobi)\n')

        # Simulation conditions name
        if attr_name == 'simulation_condition' and (attr_value is not None and not isinstance(attr_value,str)): 
            raise userError('Invalid simulation_condition for fba model. simulation_condition must be a string')

        # save_flux_bounds_toThisFile, save_MUST_singles_toThisFile and save_MUST_doubles_toThisFile, save_FORCE_sets_toThisFile
        # read_flux_bounds_fromThisFile, read_MUST_singles_fromThisFile and read_MUST_doubles_fromThisFile
        if attr_name == 'save_flux_bounds_toThisFile' and not isinstance(attr_value,str): 
            raise TypeError('save_flux_bounds_toThisFile must be a string')
        if attr_name == 'read_flux_bounds_fromThisFile' and not isinstance(attr_value,str): 
            raise TypeError('read_flux_bounds_fromThisFile must be a string')
        if attr_name == 'save_MUST_singles_toThisFile' and not isinstance(attr_value,str): 
            raise TypeError('save_MUST_singles_toThisFile must be a string')
        if attr_name == 'read_MUST_singles_fromThisFile' and not isinstance(attr_value,str): 
            raise TypeError('read_MUST_singles_fromThisFile must be a string')
        if attr_name == 'save_MUST_dooubles_toThisFile' and not isinstance(attr_value,str): 
            raise TypeError('save_MUST_doubles_toThisFile must be a string')
        if attr_name == 'read_MUST_doubles_fromThisFile' and not isinstance(attr_value,str): 
            raise TypeError('read_MUST_doubles_fromThisFile must be a string')
        if attr_name == 'save_FORCE_sets_toThisFile' and not isinstance(attr_value,str): 
            raise TypeError('save_FORCE_sets_toThisFile must be a string')

        # Warnings and messages in the standard output
        if attr_name == 'stdout_msgs' and not isinstance(attr_value,bool):
            raise TypeError("'stdout_msgs' must be either True or False")
        if attr_name == 'warnings' and not isinstance(attr_value,bool):
            raise TypeError("'warnings' must be either True or False")

        self.__dict__[attr_name] = attr_value


#-----------------------------------------
class FORCE(object):
    """
    This class defines the optimization problem to identify the FORCE set of 
    of reactions, 

    Ali R. Zomorrodi - Segre Lab @ BU
    Last updated: March 28, 2016
    """
    def __init__(self,shared_data, build_new_optModel = True, validate_results = False, results_filename = '', warnings = True, stdout_msgs = True): 
        """
        All inputs are a subset of those for OptForce

        INPUTS:
        ------
               shared_data: An instance of class shared_data_holder
        build_new_optModel: If True ia new optimization model is created
          validate_results: If True each obtained solution is validated before finding the next
                            one
          results_filename: A string containing the name of the file where the results should
                            be written in
        """
        # Shared_data 
        self.shared_data = shared_data

        # Type of MUST doubles to identify
        self.MUST_double_type = MUST_double_type

        # build_new_optModel
        self.build_new_optModel = build_new_optModel

        # validate results
        self.validate_results = validate_results

        # results file name
        self.results_filename = results_filename

        # warnings
        self.warnings = warnings

        # stdout_msgs
        self.stdout_msgs = stdout_msgs

    def __setattr__(self,attr_name,attr_value):
        """
        Redefines funciton __setattr__
        INPUTS:
        -------
         attr_name: Attribute name
        attr_value: Attribute value
        """
        if attr_name == 'shared_data' and not isinstance(attr_value,shared_data_holder):
            raise TypeError('shared_data must be instance of class shared_data_holder')

        if attr_name == 'MUST_double_type' and not isinstance(attr_value,str):
            raise TypeError('MUST_double_type must be a string')
        elif attr_name == 'MUST_double_type' and attr_value.lower() not in ['must_lu','must_ul','must_uu','must_ll']: 
            raise TypeError('Invalid MUST_double_type value! Allowed choices are MUST_LU, MUST_UL, MUST_LL, MUST_UU')

        if attr_name == 'build_new_optModel' and not isinstance(attr_value,bool):
            raise TypeError('build_new_optModel must be either True or False')

        if attr_name == 'validate_results' and not isinstance(attr_value,bool):
            raise TypeError('validate_results must be eiher True or False')

        if attr_name == 'results_filename' and not isinstance(attr_value,str):
            raise TypeError('results_filename must be a string')

        if attr_name == 'warnings' and not isinstance(attr_value,bool):
            raise TypeError('warnings must be eiher True or False')

        if attr_name == 'stoud_msgs' and not isinstance(attr_value,bool):
            raise TypeError('stdout_msgs must be eiher True or False')

        if attr_name.lower() not in  ['shared_data','build_new_optModel','validate_results','results_filename','warnings','stdout_msgs']:
            self.shared_data.__dict__[attr_name] = attr_value 



#-------------------------
if __name__ == '__main__':
    pass 
 
