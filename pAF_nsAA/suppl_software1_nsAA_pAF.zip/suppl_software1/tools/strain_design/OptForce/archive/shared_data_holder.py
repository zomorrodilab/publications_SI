from __future__ import division
import sys,os, time
sys.path.append('../../../')
from copy import deepcopy
from tools.userError import userError
from tools.globalVariables import *
from tools.core.compound import compound
from tools.core.reaction import reaction
from tools.core.organism import organism
from tools.core.model import model
# Increse the recursion limit, otherwise deepcopy will complain
sys.setrecursionlimit(10000)

class shared_data_holder(object):
    """
    A class storing the data that should be shared among the main OptForce class and the
    classes finding MUST doubles and FORCE sets of reactions. This class just facilitates
    data sharing among the three aformentioned classes.
    """
    def __init__(self, **input_args):

        for arg in input_args.keys():
            exec 'self.' + arg + ' = ' + str(input_args[arg])


    def __setattr__(self,attr_name,attr_value):
        """
        Redefines funciton __setattr__
        INPUTS:
        -------
         attr_name: Attribute name
        attr_value: Attribute value
        """
        # model 
        if attr_name == 'model' and not isinstance(attr_value,model):
            raise TypeError('model must be instance of class model')

        # product_exchrxn_id 
        if attr_name == 'product_exchrxn_id' and not isinstance(attr_value,str):
            raise TypeError('product_exchrxn_id must be a string')

        # product_targetYield_percent
        if attr_name == 'product_targetYield_percent' and (not isinstance(attr_value,int) and not isinstance(attr_value,float)):
            raise TypeError('product_targetYield_percent must be an integer or a float')
        if attr_name == 'product_targetYield_percent' and (attr_value < 0 or attr_value > 100): 
            raise ValueError('product_targetYield_percent must be between 0 and 100')

        # min_biomass_percent 
        if attr_name == 'min_biomass_percent' and (not isinstance(attr_value,int) and not isinstance(attr_value,float)):
            raise TypeError('min_biomass_percent must be an integer or a float')
        if attr_name == 'min_biomass_percent' and (attr_value < 0 or attr_value > 100): 
            raise ValueError('min_biomass_percent must be between 0 and 100')

        # growthMedium_flux_bounds 
        if attr_name == 'growthMedium_flux_bounds' and not isinstance(attr_value,dict): 
            raise TypeError('growthMedium_flux_bounds must be a dictionary')
        if attr_name == 'growthMedium_flux_bounds' and len([k for k in attr_value.keys() if k.lower() not in ['flux_bounds_filename','flux_bounds_dict']]) > 0: 
            raise ValueError('Invalid key for growthMedium_flux_bounds. Allowed keys are flux_bounds_filename and flux_bounds_dict')

        # Filenames
        if attr_name in ['read_blocked_rxns_fromThisFile','read_inSilico_essential_rxns_fromThisFile','read_inVivo_essential_rxns_fromThisFile'] and not isinstance(attr_value,str): 
            raise TypeError('{} must be a string'.format(attr_name))

        # Simulation conditions name
        if attr_name == 'simulation_condition' and (attr_value is not None and not isinstance(attr_value,str)): 
            raise userError('Invalid simulation_condition for fba model. simulation_condition must be a string')


        self.__dict__[attr_name] = attr_value


