from __future__ import division
import sys,os, time
sys.path.append('../../../')
from copy import deepcopy
from datetime import timedelta  # To convert elapsed time to hh:mm:ss format
from MUST_doubles import MUST_doubles
from tools.userError import userError
from tools.globalVariables import *
from tools.pyomoSolverCreator import pyomoSolverCreator
from tools.io.read_sbml_model import read_sbml_model
from tools.core.compound import compound
from tools.core.reaction import reaction
from tools.core.organism import organism
from tools.core.model import model
from tools.io.create_model import create_model
from tools.fba.fba import fba
from tools.fba.set_specific_bounds import set_specific_bounds
from imp import load_source
from pyomo.environ import *
from pyomo.opt import *

# The following lines change the temporary directory for pyomo
from pyutilib.services import TempfileManager
TempfileManager.tempdir = pyomo_tmp_dir

# Increse the recursion limit, otherwise deepcopy will complain
sys.setrecursionlimit(10000)

# The following lines change the temporary directory for pyomo
from pyutilib.services import TempfileManager
TempfileManager.tempdir = '/tmp/'


class FORCE(object):
    """
    This class defines the optimization problem to identify the FORCE set of 
    of reactions, 

    Ali R. Zomorrodi - Segre Lab @ BU
    Last updated: August 04, 2017
    """
    def __init__(self,model, product_exchrxn_id, flux_bounds_ref, flux_bounds_overprod, product_MW, carbonSrc_MW = 180.156, moles_of_carbonSrc_takenup = 100, growthMedium_flux_bounds = {'flux_bounds_filename':None, 'flux_bounds_dict': {}}, min_biomass_percent = 10, product_targetYield_percent = 80, MUST_X = [], MUST_L = [], MUST_U = [], MUST_LU_L = [], MUST_LU_U = [], MUST_LL_L1 = [], MUST_LL_L2 = [], MUST_UU_U1 = [], MUST_UU_U2 = [], min_interven_num = 1, max_interven_num = 10, thr_to_increase_interven_num = 0.1, max_alternate_solns_num = 10, notMUST_max_interven_num = 0, notXrxns_interven_num = 0, notLrxns_interven_num = 0, notUrxns_interven_num = 0, fixed_X_rxns = [], ignored_X_rxns = [], fixed_L_rxns = [], ignored_L_rxns = [], fixed_U_rxns = {}, ignored_U_rxns = [], doNot_modify_transport_rxns = True, doNot_modify_noGene_rxns = True, inSilico_essential_rxns = [], inVivo_essential_rxns= [], blocked_rxns = [], build_new_optModel = True, dual_formulation_type = 'standard', validate_results = True, results_filename = '', optimization_solver = default_optim_solver, max_threads_num = 1, warnings = True, stdout_msgs = True, stdout_msgs_details = False): 
        """
        All inputs are a subset of those for OptForce

        INPUTS:
        ------
        product_MW and carbonSrc_MW:
        Molecular weight of product and the carbon source (is used to compute g of product/g of carbon source yield)

        moles_of_carbonSrc_takenup:
        Mole of carbon source taken up (required to compute g of product/g of carbon source yield)

        min_interven_num: 
        Minimum total number of interventions

        max_interven_num: 
        Maximum total number of interventions

        thr_to_increase_interven_num:
        If the best production flux of the product for a given number of interventions is less than 
        or equal to the best produciton flux achieved with a lesser number of interventions +  
        thr_to_increase_interven_num, the number of interventions increase

        max_alternate_solns_num:
        Max number of alternative solutions to return for each given number of interventions.
        Note that if a solution with the current number of interventions is worse than the best solution achieved 
        with a lower number of interventions no further alternative solutions are returned

        notMUST_max_interven_num: 
        Maximum allowed number of interventions out of the MUST sets

        notXrxns_interven_num: 
        Allowed number of knockouts outside of X_rxns

        notUrxns_interven_num: 
        Allowed number of down_regulations outside of U_rxns

        notLrxns_interven_num: 
        Allowed number of down_regulations outside of L_rxns

        build_new_optModel: 
        If True ia new optimization model is created

        product_targetYield_percent: 
        Product target yield percent. Iterations stop if the objective function reaches this target yield

        dual_formulation_type: 
        A string showing which type of dual formulation to use. 
        'standard': We deal with the product of binary variables and dual varibales, whcih ar elinearized
        'simplified': We analyze each term in the dual objective function considering the duality theory and
        try to simplify the product of binary and dual variables. No linearization of the 
        binary and dual variables is needed here.

        fixed_X_rxns, fixed_L_rxns, fixed_U_rxns:
        A list of reactions ids that must be knocked out, down-regulated or 
        up-regulated by fixing their corresponidng yX, yL or yU to one

        ignored_X_rxns, ignored_L_rxns, ignored_U_rxns: 
        A list of reactions ids that must NOT be knocked out, down-regulate
        or up-regulated by fixing their corresponindg yX, yL or yU to zero

        inSilico_essential_rxns: 
        List of in silico essential reaciton ids

        inVivo_essential_rxns: 
        List of in vivo essential reaction ids

        blocked_rxns: 
        List of alwqys blocked reactions in the model

        growthMedium_flux_bounds: 
        Information about growth media 

        flux_bounds_filename: 
        Name of and path of the file containing the flux bounds
        file for exchange reactions corresponding to compounds in 
                                                         in the growth media
        flux_bounds_dict: 
        A dictionary containing the flux bounds for other reactions (such as carbon
        source uptake, oxygen uptake, etc), that have to be set for reactions not 
        in flux_data_filenam or media_filename

        doNot_modify_transport_rxns and doNot_modify_noGene_rxns:
        Parameters showing if transport or reactions with no gene associations can be
        modified (False) or not (True)

        validate_results: 
        If True each obtained solution is validated before finding the next
        one

        results_filename: 
        A string containing the name of the file where the results should
        be written in

        max_threads_num:
        Maximum number of threads (cores) to be used by the optimization solver for parallel computing
        (see pyomoSolverCreator.py for details) 

        Ali R. Zomorrodi - Segre lab @ BU
        Last updated: 03/14/2018
        """
        # model 
        self.model = model
        self.biomass_reaction = model.biomass_reaction
        self.biomass_rxn_id = model.biomass_reaction.id
        
        # Growth medium
        self.growthMedium_flux_bounds = growthMedium_flux_bounds

        # flux bounds
        self.flux_bounds_ref = flux_bounds_ref
        self.flux_bounds_overprod = flux_bounds_overprod

        # Product and biomass yields
        self.product_exchrxn_id = product_exchrxn_id
        self.product_targetYield_percent = product_targetYield_percent
        self.min_biomass_percent = min_biomass_percent

        # Molecular weight of product and carbon source and mole of carbon source taken up
        self.product_MW = product_MW
        self.carbonSrc_MW = carbonSrc_MW
        self.moles_of_carbonSrc_takenup = moles_of_carbonSrc_takenup

        # MUST sets
        self.MUST_X = MUST_X
        self.MUST_L = MUST_L
        self.MUST_U = MUST_U
        self.MUST_LU_L = MUST_LU_L
        self.MUST_LU_U = MUST_LU_U
        self.MUST_LL_L1 = MUST_LL_L1
        self.MUST_LL_L2 = MUST_LL_L2
        self.MUST_UU_U1 = MUST_UU_U1
        self.MUST_UU_U2 = MUST_UU_U2
        
        # Minimum and maximum Total number of interventions
        self.min_interven_num = min_interven_num
        self.max_interven_num = max_interven_num
        if self.min_interven_num > self.max_interven_num:
            raise ValueError('max_interven_num is less than min_interven_num!')

        # thr_to_increase_interven_num
        self.thr_to_increase_interven_num = thr_to_increase_interven_num

        # Maximum number of alternative solutions for each given number of interventions
        self.max_alternate_solns_num = max_alternate_solns_num

        # Allowed number of intervnetions out of the MUST sets
        self.notMUST_max_interven_num = notMUST_max_interven_num

        # Allowed number of interventions outside of X_rxns, L_rxns and U_rxns
        self.notXrxns_interven_num = notXrxns_interven_num
        self.notLrxns_interven_num = notLrxns_interven_num
        self.notUrxns_interven_num = notUrxns_interven_num

        # build_new_optModel
        self.build_new_optModel = build_new_optModel

        # List of in silico essential, in vivo essential and always blocked reactions
        self.inSilico_essential_rxns = inSilico_essential_rxns
        self.inVivo_essential_rxns = inVivo_essential_rxns
        self.blocked_rxns = blocked_rxns        

        # Type of the dual formulation
        self.dual_formulation_type = dual_formulation_type

        # Product target yield percent
        self.product_targetYield_percent = product_targetYield_percent

        # validate results
        self.validate_results = validate_results

        # results file name
        self.results_filename = results_filename

        # optimization solver
        self.optimization_solver = optimization_solver

        # max_threads_num
        self.max_threads_num = max_threads_num

        # warnings
        self.warnings = warnings

        # stdout_msgs
        self.stdout_msgs = stdout_msgs
        self.stdout_msgs_details = stdout_msgs_details

        # - Perform some preprocessing --
        # Reactions that must be up- or down-regulated according to MUST sets
        self.U_rxns = list(set(self.MUST_U + self.MUST_LU_U + self.MUST_UU_U1 + self.MUST_UU_U2))
        self.L_rxns = list(set(self.MUST_L + self.MUST_LU_L + self.MUST_LL_L1 + self.MUST_LL_L2))
        self.X_rxns = self.MUST_X 

        # Reactions that must be knocked out, down-regulated or up-regulated by fixing their 
        # corresponding binary variables yX, yL and yU to one
        self.fixed_X_rxns = fixed_X_rxns
        self.fixed_L_rxns = fixed_L_rxns
        self.fixed_U_rxns = fixed_U_rxns
        self.ignored_X_rxns = ignored_X_rxns
        self.ignored_L_rxns = ignored_L_rxns
        self.ignored_U_rxns = ignored_U_rxns

        # Set of ignored rxns provided by the user as input. The list of these reactions are
        # reported in the output. Note that a large set of other reactions are added to 
        # ignored_X_rxns, ignored_L_rxns and ignored_U_rxns later on in the code
        # (see funciton define_optModel_params), but we don't want to report all of them in the output 
        # Reporting the provided list of reactions in the input is useful as sometimes solutions from
        # previous runs of the code that are not desirable are excluded in the later runs of hte code
        # Storing this informaiton will come in handy when looking at the results as the we know what
        # previous solutions we have excluded to come up with these new solutions
        # Note don't do self._ignored_X_rxns_user = self.ignored_X_rxns as any later changes to 
        # self.ignored_X_rxns will be carried over to self._ignored_X_rxns_user (due to the nature of lists
        # in python)
        self._ignored_X_rxns_user = [r for r in self.ignored_X_rxns]
        self._ignored_L_rxns_user = [r for r in self.ignored_L_rxns]
        self._ignored_U_rxns_user = [r for r in self.ignored_U_rxns]

        self.doNot_modify_transport_rxns = doNot_modify_transport_rxns
        self.doNot_modify_noGene_rxns = doNot_modify_noGene_rxns

    def __setattr__(self,attr_name,attr_value):
        """
        Redefines funciton __setattr__
        INPUTS:
        -------
         attr_name: Attribute name
        attr_value: Attribute value
        """
        # model 
        if attr_name == 'model' and not isinstance(attr_value,model):
            raise TypeError('model must be instance of class model')

        # growthMedium_flux_bounds 
        if attr_name == 'growthMedium_flux_bounds' and not isinstance(attr_value,dict):
            raise TypeError('growthMedium_flux_bounds must be a dictionary')
        if attr_name == 'growthMedium_flux_bounds' and len([k for k in attr_value.keys() if k.lower() not in ['flux_bounds_filename','flux_bounds_dict']]) > 0:
            raise ValueError('Invalid key for growthMedium_flux_bounds. Allowed keys are flux_bounds_filename and flux_bounds_dict')

        # product_exchrxn_id 
        if attr_name == 'product_exchrxn_id' and not isinstance(attr_value,str):
            raise TypeError('product_exchrxn_id must be a string')

        # min_biomass_percent and product_targetYield_percent 
        if attr_name in ['min_biomass_percent','product_targetYield_percent'] and (not isinstance(attr_value,int) and not isinstance(attr_value,float)):
            raise TypeError('{} must be an integer or a float'.format(attr_name))
        if attr_name in ['min_biomass_percent','product_targetYield_percent'] and (attr_value < 0 or attr_value > 100):
            raise ValueError('{} must be between 0 and 100'.format(attr_name))

        # MUST_singles, MUST_doubles, essential and blocked rxns 
        if attr_name in ['MUST_X','MUST_L','MUST_U','MUST_LU_L', 'MUST_LU_U', 'MUST_LL_L1', 'MUST_LL_L2', 'MUST_UU_U1', 'MUST_UU_U2', 'blocked_rxns', 'inSilico_essential_rxns','inVivo_essential_rxns'] and not isinstance(attr_value,list):
            raise TypeError('{} must be a list of strings'.format(attr_name))
        elif attr_name in ['MUST_X','MUST_L','MUST_U','MUST_LU_L', 'MUST_LU_U', 'MUST_LL_L1', 'MUST_LL_L2', 'MUST_UU_U1', 'MUST_UU_U2', 'blocked_rxns', 'inSilico_essential_rxns','inVivo_essential_rxns'] and len([k for k in attr_value if not isinstance(k,str)]) > 0:
            raise TypeError('{} must be a list of string. Non-string objects were observed in the list'.format(attr_name))

        if attr_name in ['min_interven_num', 'max_interven_num', 'max_alternate_solns_num', 'notMUST_max_interven_num', 'notXrxns_interven_num', 'notLrxns_interven_num', 'notUrxns_interven_num'] and not isinstance(attr_value,int):
            raise TypeError('{} must be an integer', attr_name)
        elif attr_name in ['min_interven_num', 'max_interven_num', 'notMUST_max_interven_num', 'max_alternate_solns_num', 'notXrxns_interven_num', 'notLrxns_interven_num', 'notUrxns_interven_num'] and attr_value < 0:
            raise ValueError('{} must be a non-negative integer', attr_value) 

        if attr_name == 'thr_to_increase_interven_num' and not isinstance(attr_value,float):
            raise TypeError('{} must be an float', attr_name)
        elif attr_name == 'thr_to_increase_interven_num' and attr_value < 0:
            raise ValueError('{} must be a non-negative floatr', attr_name) 

        if attr_name in ['product_MW', 'carbonSrc_MW', 'moles_of_carbonSrc_takenup'] and not isinstance(attr_value,float) and not isinstance(attr_value,int):
            raise TypeError('{} must be an integer or a float', attr_name)
        elif attr_name == 'thr_to_increase_interven_num' and attr_value < 0:
            raise ValueError('{} must be a non-negative floatr', attr_name) 

        if attr_name in ['fixed_X_rxns','fixed_L_rxns','fixed_U_rxns','ignore_X_rxns','ignored_L_rxns','ignored_U_rxns'] and not isinstance(attr_value,list):
            raise TypeError('{} must be a list of strings'.format(attr_name))
        elif attr_name in ['fixed_X_rxns','fixed_L_rxns','fixed_U_rxns'] and len([k for k in attr_value if not isinstance(k,str)]) > 0: 
            raise TypeError('Elements of {} must be a string'.format(attr_name))

        if attr_name in ['inSilico_essential_rxns','inVivo_essential_rxns','blocked_rxns'] and not isinstance(attr_value,list):
            raise TypeError('{} must be a list of strings'.fomrat(attr_name))
        elif attr_name in ['inSilico_essential_rxns','inVivo_essential_rxns','blocked_rxns'] and len([k for k in attr_value if not isinstance(k,str)]) > 0: 
            raise TypeError('Element of {} must be a string'.format(attr_name))

        if attr_name == 'build_new_optModel' and not isinstance(attr_value,bool):
            raise TypeError('build_new_optModel must be either True or False')

        if attr_name == 'dual_formulation_type' and not isinstance(attr_value,str):
            raise TypeError('dual_formulation_type must be a string')
        elif attr_name == 'dual_formulation_type' and attr_value.lower() not in ['standard','simplified']: 
            raise TypeError('Invalid dual_formulation_type value! Allowed choices are standard and simplified')

        if attr_name == 'product_targetYield_percent' and not isinstance(attr_value,float) and not isinstance(attr_value,int):
            raise TypeError('product_targetYield_percent must be an integer or float')
        elif attr_name == 'product_targetYield_percent' and (attr_value < 0 or attr_value > 100):
            raise TypeError('product_targetYield_percent must be an integer or float between 0 and 100')

        if attr_name == 'validate_results' and not isinstance(attr_value,bool):
            raise TypeError('validate_results must be eiher True or False')

        if attr_name == 'results_filename' and not isinstance(attr_value,str):
            raise TypeError('results_filename must be a string')

        if attr_name in ['doNot_modify_transport_rxns', 'doNot_modify_noGene_rxns', 'warnings','stoud_msgs','stdout_msgs_details'] and not isinstance(attr_value,bool):
            raise TypeError('{} must be eiher True or False'.format(attr_name))

        # Solver name
        if attr_name == 'optimization_solver' and not isinstance(attr_value, str):
            raise TypeError('optimization_solver must be a string')
        elif attr_name == 'optimization_solver' and attr_value.lower() not in ['cplex','gurobi','gurobi_ampl','cplexamp']:
            raise userError('Invalid solver name (eligible choices are cplex and gurobi)\n')

        # Solver name
        if attr_name == 'optimization_solver' and not isinstance(attr_value, str):
            raise TypeError('optimization_solver must be a string')
        elif attr_name == 'optimization_solver' and attr_value.lower() not in ['cplex','gurobi','gurobi_ampl','cplexamp']:
            raise userError('Invalid solver name (eligible choices are cplex and gurobi, cplexamp and gurobi_ampl)\n')

        # max_thread_num 
        if attr_name == 'max_thread_num' and not isinstance(attr_value, int):
            raise TypeError('max_thread_num must be an integer')
        elif attr_name == 'max_thread_num' and (attr_value < 1 or attr_value > 32):
            raise userError('max_thread_num must be an integer between 1 and 32\n')

        self.__dict__[attr_name] = attr_value 

    def find_maxBiomass_flux(self):
        """
        Finds the maximum thoeretical biomass flux
        """
        for rxn in self.model.reactions:
            rxn.objective_coefficient = 0
        self.model.biomass_reaction.objective_coefficient = 1

        set_specific_bounds(model = self.model, file_name = self.growthMedium_flux_bounds['flux_bounds_filename'], flux_bounds = self.growthMedium_flux_bounds['flux_bounds_dict'], reset_flux_bounds = True)

        self.model.fba(build_new_optModel = True, store_opt_fluxes = False, stdout_msgs = False, warnings = True)
        if self.model.fba_model.solution['exit_flag'] == 'globallyOptimal':
            self.max_biomass_flux = self.model.fba_model.solution['objective_value']
            if self.stdout_msgs:
                print 'OptForce: Theoretical maximum biomass formation flux = {}'.format(self.max_biomass_flux)
        else:
            raise userError('The FBA problem for finding the maximum theoretical biomass flux was not solved to optimality!')

    def find_prod_max_theor_yield(self):
        """
        Finds the maximum thoeretical yield for the product of interest (this is the max flux of the exchange reactions for the product)
        """
        for rxn in self.model.reactions:
            rxn.objective_coefficient = 0
        self.model.reactions_by_id[self.product_exchrxn_id].objective_coefficient = 1

        set_specific_bounds(model = self.model, file_name = self.growthMedium_flux_bounds['flux_bounds_filename'], flux_bounds = self.growthMedium_flux_bounds['flux_bounds_dict'], reset_flux_bounds = True)

        self.model.fba(build_new_optModel = True, store_opt_fluxes = False, stdout_msgs = False, warnings = True)
        if self.model.fba_model.solution['exit_flag'] == 'globallyOptimal':
            self.product_max_theor_yield = self.model.fba_model.solution['objective_value']
            self.product_max_theor_yield_g_per_g = self.product_MW*self.product_max_theor_yield/(self.moles_of_carbonSrc_takenup*self.carbonSrc_MW) 
            if self.stdout_msgs:
                print 'OptForce: Theoretical maximum product yield = {} mol/mol of carbon src takenup = {} g/g of carbon src'.format(self.product_max_theor_yield, self.product_max_theor_yield_g_per_g) 
        else:
            raise userError('The FBA problem for finding the theoretical maximum product yield was not solved to optimality!')


    #------------------------------------------------------------------------
    #--- Define parameters needed for the optimizaiton problem ---
    #------------------------------------------------------------------------
    def set_model_flux_bounds(self):
        """
        Set the flux bounds for the growth medium and min biomass flux in the model
        This functions needs to be called before creating an optModel
        """
        # Find the maximum biomass flux and  maximum theoretical yield of the product
        if not hasattr(self,'max_biomass_flux'):
            self.find_maxBiomass_flux()
        if not hasattr(self,'product_max_theor_yield'):
            self.find_prod_max_theor_yield()

        # Set the flux bounds for the model
        set_specific_bounds(model = self.model, file_name = self.growthMedium_flux_bounds['flux_bounds_filename'], flux_bounds = self.growthMedium_flux_bounds['flux_bounds_dict'], reset_flux_bounds = True)
        # Impost constraints on min biomass formation flux
        set_specific_bounds(model = self.model, flux_bounds = {self.biomass_rxn_id:[(self.min_biomass_percent/100)*self.max_biomass_flux,None]}, reset_flux_bounds = False)

    def define_optModel_params(self):
        """
        Assigns model parameters
        """
        # big M
        self._bigM_rxnflux = 1000
  
        # Max value of the dual variables
        self._bigM_dualvar = 1e4

        # Reactions that must be excluded (ignore) from any type of manupulaiton (X, L or U) 
        ignore_all = []
        for rxn in self.model.reactions:
            if rxn in self.blocked_rxns or \
               rxn.flux_bounds == [0,0] or \
               (self.doNot_modify_transport_rxns and 'transport' in rxn.name.lower()) or \
               (self.doNot_modify_transport_rxns and rxn.subsystem != '' and 'transport' in rxn.subsystem.lower()) or \
               rxn.is_exchange or \
               (self.doNot_modify_noGene_rxns and rxn.genes == [] and rxn.gene_reaction_rule == ''):
                ignore_all.append(rxn.id)

        # biomass
        ignore_all.append(self.model.biomass_reaction.id)

        # ATPM
        if 'ATPM' in self.model.reactions_by_id.keys():
            ignore_all.append('ATPM')

        #--- Reactions that must be ignored for knock outs --- 
        self.ignored_X_rxns += ignore_all

        # in silico and in vivo essential rxns
        self.ignored_X_rxns += list(set(self.inSilico_essential_rxns + self.inVivo_essential_rxns))

        # Reactions not in X_rxns 
        if self.notXrxns_interven_num == 0:
            self.ignored_X_rxns += [r.id for r in self.model.reactions if r.id not in self.X_rxns]

        #---- L_rxns ----
        self.ignored_L_rxns += ignore_all 

        # Reactions not in L_rxns 
        if self.notLrxns_interven_num == 0:
            self.ignored_L_rxns +=  [r.id for r in self.model.reactions if r.id not in self.L_rxns]

        #---- U_rxns ----
        self.ignored_U_rxns += ignore_all 

        # Reactions not in U_rxns 
        if self.notUrxns_interven_num == 0:
            self.ignored_U_rxns += [r.id for r in self.model.reactions if r.id not in self.U_rxns]
        
    #------------------------------------------------------------------------
    #--- Define rules for the objective function and various constraints ----
    #------------------------------------------------------------------------
    def strong_duality_const_rule(self,optModel):
        """
        Objective function of the dual problem
        NOTE: In the dual formulation we replcae LBj and UBj in the up/down-regulation constraints wtih
              -M and M (where M is a big number), respectively, and let the constaints on reaction knowckouts
              to take care of the reaction bounds 

        NOTE: In case you want to remove terms related to ignored_X_rxns, ignored_L_rxns and ignored_L_rxns, makes ure that
              you exclude only the terms that are the product of the binary variables and dual varabiels not dual variables
              alone.
        """
        if self.dual_formulation_type.lower() == 'standard':
            # v(product exch rxn) =  
            # sum(j, muLB(j)*[LB(j)*(1 - yX(j)] + 
            #        muUB(j)*[UB(j)*(1 - yX(j)] +
            #        [LBon(j) - (-M)]*thethaLB_yU(j) + (-M)*thethaLB(j) +
            #        [UBon(j) - bigM]*thethaUB_yL(j) + bigM*thethaUB
            const = \
                  optModel.v[self.product_exchrxn_id] ==  \
                  sum([self.model.reactions_by_id[j].flux_bounds[0]*(optModel.muLB[j] - optModel.muLB_yX[j]) for j in optModel.J]) - \
                  sum([self.model.reactions_by_id[j].flux_bounds[1]*(optModel.muUB[j] - optModel.muUB_yX[j]) for j in optModel.J]) + \
                  sum([(self.flux_bounds_overprod[j][0] + self._bigM_rxnflux)*optModel.thethaLB_yU[j] - self._bigM_rxnflux*optModel.thethaLB[j] for j in optModel.J]) - \
                  sum([(self.flux_bounds_overprod[j][1] - self._bigM_rxnflux)*optModel.thethaUB_yL[j] + self._bigM_rxnflux*optModel.thethaUB[j] for j in optModel.J])
                        
        else:  # Simplified formulation
            # NOTE: self.ignored_L_rxns and self.ignored_U_rxns should not be excluded
            # from the objective function. The reasons is that thethaLB and
            # thethalUB appear in dual_const for ALL reactions not just reactions 
            # that are a candidate for knockout. So, LB(j)*thethaLB(j) and UB(j)*thethaUB(j) 
            # should appear for all reactions in the objective funciton. If a reaction 
            # is not a candidate for up- or down-regulation, the constraints 
            # thethaLB_yU_const and thethaUB_yL_const ensure that thethaLB and thethaUB 
            # are zero for any reaction that is not a candidate for up/down-regulation            
            const = \
                  optModel.v[self.product_exchrxn_id] == \
                  sum([self.model.reactions_by_id[j].flux_bounds[0]*(optModel.muLB[j] - optModel.muLB_yX[j]) for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] != -self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[0] != 0]) - \
                  sum([self.model.reactions_by_id[j].flux_bounds[1]*(optModel.muUB[j] - optModel.muUB_yX[j]) for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] != self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[1] != 0]) + \
                  sum([self.flux_bounds_overprod[j][0]*optModel.thethaLB[j] for j in optModel.J]) - \
                  sum([self.flux_bounds_overprod[j][1]*optModel.thethaUB[j] for j in optModel.J])

        return const


    #--- Constraints of the dual problem ---
    def dual_objectiveFunc_rule(self,optModel):
        """
        Objective function of the dual problem
        NOTE: In the dual formulation we replcae LBj and UBj in the up/down-regulation constraints wtih
              -M and M (where M is a big number), respectively, and let the constaints on reaction knowckouts
              to take care of the reaction bounds 
        NOTE: In case you want to remove terms related to ignored_X_rxns, ignored_L_rxns and ignored_L_rxns, makes ure that
              you exclude only the terms that are the product of the binary variables and dual varabiels not dual variables
              alone.
        """
        if self.dual_formulation_type.lower() == 'standard':
            # sum(j, muLB(j)*[LB(j)*(1 - yX(j)] + 
            #        muUB(j)*[UB(j)*(1 - yX(j)] +
            #        [LBon(j) - (-M)]*thethaLB_yU(j) + (-M)*thethaLB(j) +
            #        [UBon(j) - bigM]*thethaUB_yL(j) + bigM*thethaUB
            obj = \
                  sum([self.model.reactions_by_id[j].flux_bounds[0]*(optModel.muLB[j] - optModel.muLB_yX[j]) for j in optModel.J]) - \
                  sum([self.model.reactions_by_id[j].flux_bounds[1]*(optModel.muUB[j] - optModel.muUB_yX[j]) for j in optModel.J]) + \
                  sum([(self.flux_bounds_overprod[j][0] + self._bigM_rxnflux)*optModel.thethaLB_yU[j] - self._bigM_rxnflux*optModel.thethaLB[j] for j in optModel.J]) - \
                  sum([(self.flux_bounds_overprod[j][1] - self._bigM_rxnflux)*optModel.thethaUB_yL[j] + self._bigM_rxnflux*optModel.thethaUB[j] for j in optModel.J])


        else:    # Simplified 
            # NOTE: self.ignored_L_rxns and self.ignored_U_rxns should not be excluded
            # from the objective function. The reasons is that thethaLB and
            # thethalUB appear in dual_const for ALL reactions not just reactions 
            # that are a candidate for knockout. So, LB(j)*thethaLB(j) and UB(j)*thethaUB(j) 
            # should appear for all reactions in the objective funciton. If a reaction 
            # is not a candidate for up- or down-regulation, the constraints 
            # thethaLB_yU_const and thethaUB_yL_const ensure that thethaLB and thethaUB 
            # are zero for any reaction that is not a candidate for up/down-regulation            
            obj = \
                  sum([self.model.reactions_by_id[j].flux_bounds[0]*(optModel.muLB[j] - optModel.muLB_yX[j]) for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] != -self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[0] != 0]) - \
                  sum([self.model.reactions_by_id[j].flux_bounds[1]*(optModel.muUB[j] - optModel.muUB_yX[j]) for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] != self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[1] != 0]) + \
                  sum([self.flux_bounds_overprod[j][0]*optModel.thethaLB[j] for j in optModel.J]) - \
                  sum([self.flux_bounds_overprod[j][1]*optModel.thethaUB[j] for j in optModel.J])

        return obj

    def dual_const_rule(self,optModel,j):
        """
        Constraints of the dual problem
        """
        rxn = self.model.reactions_by_id[j]  # rxn object with id j
        if j == self.product_exchrxn_id:
            const = sum(rxn.stoichiometry[i]*optModel.Lambda[i.id] for i in rxn.compounds) + optModel.muLB[j] - optModel.muUB[j] + optModel.thethaLB[j] - optModel.thethaUB[j] == 1 
        else:
            const = sum(rxn.stoichiometry[i]*optModel.Lambda[i.id] for i in rxn.compounds) + optModel.muLB[j] - optModel.muUB[j] + optModel.thethaLB[j] - optModel.thethaUB[j] == 0
        return const

    #--------------------------------------------------------
    #---------------- Create optimization models ------------        
    #--------------------------------------------------------
    def build_primal_optModel(self):
        """
        Creates a pyomo optimization model for the primal problem 
        """
        # Set optModel parameters
        self.define_optModel_params()

        # Create a pyomo model optimization model
        optModel = ConcreteModel()

        #--- Sets ---
        # Set of compounds 
        optModel.I = Set(initialize = [c.id for c in self.model.compounds])

        # Set of rxns  
        optModel.J = Set(initialize = [r.id for r in self.model.reactions])

        #--- Variables --- 
        # Reaction fluxes (NOTE: Make sure flux bounds are correctly assigned)
        optModel.v = Var(optModel.J, domain=Reals, bounds = lambda optModel, j: self.model.reactions_by_id[j].flux_bounds)

        # Binary variables in for reactions considered for up-regulation, down-regulation or knockout 
        optModel.yL = Var(optModel.J, domain=Boolean)
        optModel.yU = Var(optModel.J, domain=Boolean)
        optModel.yX = Var(optModel.J, domain=Boolean)

        #--- Objective function ---
        optModel.objectiveFunc = Objective(rule = lambda optModel: optModel.v[self.product_exchrxn_id], sense = minimize)

        #--- Constraints ----
        # Mass balance 
        optModel.massBalance_const = Constraint(optModel.I, rule = lambda optModel, i: sum(j.stoichiometry[self.model.compounds_by_id[i]]*optModel.v[j.id] for j in self.model.compounds_by_id[i].reactions) == 0)

        # Constrain for U_rxns
        # v(j) =g= LBon(j)*yU(j) + (1-yU(j))*LB(j) or v(j) =g= (LBon(j) - LB(j))*yU(j) + LB(j).
        # Instead of LB(j) use -bigM to make the constraint inactive when yU(j) = 0:
        # v(j) =g= (LBon(j) - (-M))*yU(j) + (-M) 
        optModel.U_rxns_const = Constraint([j for j in optModel.J if j not in self.ignored_U_rxns], rule = lambda optModel, j: optModel.v[j] >= (self.flux_bounds_overprod[j][0] + self._bigM_rxnflux)*optModel.yU[j] - self._bigM_rxnflux)

        # Constraint for U_rxns
        # v(j) =l= UBon(j)*yL(j) + (1-yL(j))*UB(j) or v(j) =l= (UBon(j) - UB(j))*yL(j) + UB(j)
        # Instead of UB(j) use bigM to make the constraint inactive when yL(j) = 0:
        # v(j) =l= (UBon(j) - bigM)*yU(j) + bigM
        optModel.L_rxns_const = Constraint([j for j in optModel.J if j not in self.ignored_L_rxns], rule = lambda optModel, j: optModel.v[j] <= (self.flux_bounds_overprod[j][1] - self._bigM_rxnflux)*optModel.yL[j] + self._bigM_rxnflux)

        # Cconstraints for X_rxns. This constraint is written over all reactions (not just thos ein X_rxns) to incorporate
        # their LB and UB into the calculations
        # LB(j)*(1 - yX(j)) <= v(j)  and v(j) <= UB(j)*(1 - yX(j)) 
        optModel.X_rxns_const1 = Constraint(optModel.J, rule = lambda optModel, j: optModel.v[j] >= self.model.reactions_by_id[j].flux_bounds[0]*(1 - optModel.yX[j]))
        optModel.X_rxns_const2 = Constraint(optModel.J, rule = lambda optModel, j: optModel.v[j] <= self.model.reactions_by_id[j].flux_bounds[1]*(1 - optModel.yX[j]))

        self.optModel = optModel

        self._optModel_name = 'primal'

    def build_dual_optModel(self):
        """
        Creates a pyomo optimization model for the dual problem 
        """
        # Set optModel parameters
        self.define_optModel_params()

        # Create a pyomo model optimization model
        optModel = ConcreteModel()

        #--- Sets ---
        # Set of compounds 
        optModel.I = Set(initialize = [c.id for c in self.model.compounds])

        # Set of rxns  
        optModel.J = Set(initialize = [r.id for r in self.model.reactions])

        #--- Variables --- 
        # Dual variables associated with steady-state mass balance constraints
        # It's better to not provide upper and lower bound on lambda otherwise the dual objective 
        # will be slightly different from the primal's
        optModel.Lambda = Var(optModel.I, domain=Reals)

        # Dual variables associated with v_j >= LB_j*(1-yX(j) and v_j <= UB_j*(1-yX(j))
        optModel.muLB = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        optModel.muUB = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        optModel.muLB_yX = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        optModel.muUB_yX = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))

        # Dual variables associated with U_rxns_const: v(j) >= (LBon(j) - (-M))*yU(j) + (-M) (thethaLB) and  
        # L_rxns_const: v(j) <= (UBon(j) - bigM)*yU(j) + bigM (thethaUB)
        optModel.thethaLB = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        optModel.thethaUB = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        if self.dual_formulation_type.lower() == 'standard':
            optModel.thethaLB_yU = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
            optModel.thethaUB_yL = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))

        # Binary variables
        optModel.yL = Var(optModel.J, domain=Boolean)
        optModel.yU = Var(optModel.J, domain=Boolean)
        optModel.yX = Var(optModel.J, domain=Boolean)

        #--- Objective function ---
        optModel.objectiveFunc = Objective(rule=self.dual_objectiveFunc_rule, sense = maximize)

        #-- Constraints of the dual problem --
        # dual constraints 
        optModel.dual_const = Constraint(optModel.J, rule=self.dual_const_rule)

        #- Constraints linearizing the product of v_j and binary variables -
        # x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
        # muLB[j] - (1 - yX[j])*muLB_max[j] <= muLB_yX[j] <= muLB[j] - (1 - yX[j])*muLB_min[j] and muLB_min = 0
        if self.dual_formulation_type.lower() == 'standard':
            optModel.linearize_muLB_yX_const1 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.muLB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muLB_yX_const2 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.muLB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muLB_yX[j])
            optModel.linearize_muLB_yX_const3 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.muLB_yX[j] <= optModel.muLB[j] - (1 - optModel.yX[j])*0)

            # muUB_min[j]*yX[j] <= muUB_yX[j] <= muUB_max*yX[j]  and muUB_min = 0
            optModel.linearize_muUB_yX_const1 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.muUB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muUB_yX_const2 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.muUB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muUB_yX[j])
            optModel.linearize_muUB_yX_const3 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.muUB_yX[j] <= optModel.muUB[j] - (1 - optModel.yX[j])*0)


            # thethaLB_min[j]*yU[j] <= thethaLB_yU[j] <= thethaLB_max*yU[j]  and thethaLB_min = 0
            optModel.linearize_thethaLB_yU_const1 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.thethaLB_yU[j] <= self._bigM_dualvar*optModel.yU[j])
            optModel.linearize_thethaLB_yU_const2 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.thethaLB[j] - (1 - optModel.yU[j])*self._bigM_dualvar <= optModel.thethaLB_yU[j])
            optModel.linearize_thethaLB_yU_const3 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.thethaLB_yU[j] <= optModel.thethaLB[j] - (1 - optModel.yU[j])*0)

            # thethaUB_min[j]*yL[j] <= thethaUB_yL[j] <= thethaUB_max*yL[j]  and thethaUB_min = 0
            optModel.linearize_thethaUB_yL_const1 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.thethaUB_yL[j] <= self._bigM_dualvar*optModel.yL[j])
            optModel.linearize_thethaUB_yL_const2 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.thethaUB[j] - (1 - optModel.yL[j])*self._bigM_dualvar <= optModel.thethaUB_yL[j])
            optModel.linearize_thethaUB_yL_const3 = Constraint([j for j in optModel.J], rule = lambda optMode, j: optModel.thethaUB_yL[j] <= optModel.thethaUB[j] - (1 - optModel.yL[j])*0)

        else:  # Simplified
            # Only for reacitons that appear in the objective function (i.e., those with LB != -M and LB != 0)
            # muLB[j] - (1 - yX[j])*muLB_max[j] <= muLB_yX[j] <= muLB[j] - (1 - yX[j])*muLB_min[j] and muLB_min = 0
            optModel.linearize_muLB_yX_const1 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] != -self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[0] != 0], rule = lambda optModel, j: optModel.muLB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muLB_yX_const2 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] != -self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[0] != 0], rule = lambda optModel, j: optModel.muLB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muLB_yX[j])
            optModel.linearize_muLB_yX_const3 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] != -self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[0] != 0], rule = lambda optModel, j: optModel.muLB_yX[j] <= optModel.muLB[j] - (1 - optModel.yX[j])*0)

            # Only for reacitons that appear in the objective function (i.e., those with UB != M and UB != 0)
            # muUB_yx[j]:
            # 0 <= muUB_yx[j] <= muUB_max[j]*yX[j]   where muUB_min = 0
            # muUB_min[j]*yX[j] <= muUB_yX[j] <= muUB_max*yX[j]  and muUB_min = 0
            optModel.linearize_muUB_yX_const1 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] != self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[1] != 0], rule = lambda optModel, j: optModel.muUB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muUB_yX_const2 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] != self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[1] != 0], rule = lambda optModel, j: optModel.muUB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muUB_yX[j])
            optModel.linearize_muUB_yX_const3 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] != self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[1] != 0], rule = lambda optModel, j: optModel.muUB_yX[j] <= optModel.muUB[j] - (1 - optModel.yX[j])*0)

            # Only for reactions for which LB = -M
            optModel.muLB_yX_const = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] == -self._bigM_rxnflux], rule = lambda optModel,j:optModel.muLB[j] <= self._bigM_dualvar*optModel.yX[j])


            # Only for reactions for which UB = M
            optModel.muUB_yX_const = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] == self._bigM_rxnflux], rule = lambda optModel,j: optModel.muUB[j] <= self._bigM_dualvar*optModel.yX[j])

            # For all reactions 
            # NOTE: self.ignored_L_rxns and self.ignored_U_rxns should not be excluded
            # from the following two constraints. The reasons is that thethaLB and
            # thethalUB appear in dual_const for ALL reactions not just reactions 
            # that are a candidate for knockout. The following two constraints 
            # ensure that thethaLB and thethaUB are zero for any reaction that is
            # not a candidate for up/down-regulation
            optModel.thethaLB_yU_const = Constraint(optModel.J, rule = lambda optModel, j: optModel.thethaLB[j] <= self._bigM_dualvar*optModel.yU[j])
            optModel.thethaUB_yL_const = Constraint(optModel.J, rule = lambda optModel,j: optModel.thethaUB[j] <= self._bigM_dualvar*optModel.yL[j])

        self.optModel = optModel

        self._optModel_name = 'dual'

    def build_bilevel_optModel(self):
        """
        Creates a pyomo optimization model for the bilevel problem 
        """
        # Set optModel parameters (including self._bigM_rxnflux, self._bigM_dualvar, ignored_X_rxns, 
        # ignored_L_rxns and ignored_U_rxns
        self.define_optModel_params()

        # Create a pyomo model optimization model
        optModel = ConcreteModel()

        #------------------ Sets -----------------------
        # Set of compounds 
        optModel.I = Set(initialize = [c.id for c in self.model.compounds])

        # Set of rxns  
        optModel.J = Set(initialize = [r.id for r in self.model.reactions])

        #----------------- Variables -------------------
        #-- Variables of the primal problem --
        # Reaction fluxes
        optModel.v = Var(optModel.J, domain=Reals, bounds = lambda optModel, j: self.model.reactions_by_id[j].flux_bounds)

        # Binary variables in for reactions considered for up-regulation, down-regulation or knockout 
        optModel.yL = Var(optModel.J, domain=Boolean)
        optModel.yU = Var(optModel.J, domain=Boolean)
        optModel.yX = Var(optModel.J, domain=Boolean)

        #-- Variables of the dual problem --
        # Dual variables associated with steady-state mass balance constraints
        # It's better to not provide upper and lower bound on lambda otherwise the dual objective 
        # will be slightly different from the primal's
        optModel.Lambda = Var(optModel.I, domain=Reals)

        # Dual variables associated with v_j >= LB_j*(1-yX(j) and v_j <= UB_j*(1-yX(j))
        optModel.muLB = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        optModel.muUB = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        optModel.muLB_yX = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        optModel.muUB_yX = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))

        # Dual variables associated with U_rxns_const: v(j) >= (LBon(j) - (-M))*yU(j) + (-M) (thethaLB) and  
        # L_rxns_const: v(j) <= (UBon(j) - bigM)*yU(j) + bigM (thethaUB)
        optModel.thethaLB = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        optModel.thethaUB = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        if self.dual_formulation_type.lower() == 'standard':
            optModel.thethaLB_yU = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
            optModel.thethaUB_yL = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))

        #------ Objective function of the outer problem ------
        #optModel.objectiveFunc = Objective(rule = lambda optModel: optModel.v[self.product_exchrxn_id], sense = maximize)

        # Also minimize the total number of bianry variables. This is because sometimes e.g., when the total
        # allowed number of interventions is two, it finds one interventions that affects the yield combined
        # with another intervention that has no effect on the yield.
        optModel.objectiveFunc = Objective(rule = lambda optModel: optModel.v[self.product_exchrxn_id] - (1e-6)*sum([optModel.yL[j] + optModel.yU[j] + optModel.yX[j] for j in optModel.J]), sense = maximize)

        #---------------- Constraints ----------------------
        #-- Constraints of the outer problem --
        # Each rxn can participate in only one intervention: yL(j) + yU(j) + yX(j) =l= 1
        optModel.one_interven_forEachRxn_const = Constraint(optModel.J, rule = lambda optModel, j: optModel.yX[j] + optModel.yL[j] + optModel.yU[j] <= 1)

        # Restrict the total number of interventions: sum(j,yL(j) + yU(j) + yX(j)) =l= interven_num_curr;
        optModel.total_interven_const = Constraint(rule = lambda optModel: sum([optModel.yL[j] + optModel.yU[j] + optModel.yX[j] for j in optModel.J]) <= self._interven_num_curr)

        # Maximum allowed number of interventions outside of the MUST sets
        optModel.notMUST_interven_const = Constraint(rule = lambda optModel: sum([optModel.yX[j] for j in optModel.J if j not in self.X_rxns]) + sum([optModel.yL[j] for j in optModel.J if j not in self.L_rxns]) + sum([optModel.yU[j] for j in optModel.J if j not in self.U_rxns]) <= min(self._interven_num_curr, self.notMUST_max_interven_num))

        # Maximum allowed number of knockouts, up-regulations and down-regulations outside of X_rxns, U_rxns and L_rxns
        optModel.notXrxns_interven_const = Constraint(rule = lambda optModel: sum([optModel.yX[j] for j in optModel.J if j not in self.X_rxns]) <= min(self._interven_num_curr, self.notXrxns_interven_num)) 
        optModel.notLrxns_interven_const = Constraint(rule = lambda optModel: sum([optModel.yL[j] for j in optModel.J if j not in self.L_rxns]) <= min(self._interven_num_curr, self.notLrxns_interven_num)) 
        optModel.notUrxns_interven_const = Constraint(rule = lambda optModel: sum([optModel.yU[j] for j in optModel.J if j not in self.U_rxns]) <= min(self._interven_num_curr, self.notUrxns_interven_num)) 

        # Integer cuts
        optModel.integer_cuts = ConstraintList(noruleinit=True)

        #-- Constraints of the primal problem --
        # Mass balance 
        optModel.massBalance_const = Constraint(optModel.I, rule = lambda optModel, i: sum(j.stoichiometry[self.model.compounds_by_id[i]]*optModel.v[j.id] for j in self.model.compounds_by_id[i].reactions) == 0)

        # Cconstraints for X_rxns. This constraint is written over all reactions (not just thos ein X_rxns) to incorporate
        # their LB and UB into the calculations
        # LB(j)*(1 - yX(j)) <= v(j)  and v(j) <= UB(j)*(1 - yX(j)) 
        optModel.X_rxns_const1 = Constraint(optModel.J, rule = lambda optModel, j: optModel.v[j] >= self.model.reactions_by_id[j].flux_bounds[0]*(1 - optModel.yX[j]))
        optModel.X_rxns_const2 = Constraint(optModel.J, rule = lambda optModel, j: optModel.v[j] <= self.model.reactions_by_id[j].flux_bounds[1]*(1 - optModel.yX[j]))

        # Constrain for U_rxns
        # v(j) =g= LBon(j)*yU(j) + (1-yU(j))*LB(j) or v(j) =g= (LBon(j) - LB(j))*yU(j) + LB(j).
        # Instead of LB(j) use -bigM to make the constraint inactive when yU(j) = 0:
        # v(j) =g= (LBon(j) - (-M))*yU(j) + (-M) 
        optModel.U_rxns_const = Constraint([j for j in optModel.J if j not in self.ignored_U_rxns], rule = lambda optModel, j: optModel.v[j] >= (self.flux_bounds_overprod[j][0] + self._bigM_rxnflux)*optModel.yU[j] - self._bigM_rxnflux)

        # Constraint for U_rxns
        # v(j) =l= UBon(j)*yL(j) + (1-yL(j))*UB(j) or v(j) =l= (UBon(j) - UB(j))*yL(j) + UB(j)
        # Instead of UB(j) use bigM to make the constraint inactive when yL(j) = 0:
        # v(j) =l= (UBon(j) - bigM)*yU(j) + bigM
        optModel.L_rxns_const = Constraint([j for j in optModel.J if j not in self.ignored_L_rxns], rule = lambda optModel, j: optModel.v[j] <= (self.flux_bounds_overprod[j][1] - self._bigM_rxnflux)*optModel.yL[j] + self._bigM_rxnflux)

        #-- Constraints of the dual problem --
        # dual constraints 
        optModel.dual_const = Constraint(optModel.J, rule=self.dual_const_rule)

        #- Constraints linearizing the product of v_j and binary variables -
        if self.dual_formulation_type.lower() == 'standard':
            # Constraints linearizing the product of continuous and binary variables
            # This constraint is not written for reactions in self.ignored_X_rxns, self.ignored_L_rxns and self.ignored_U_rxns because 
            # they have already been fixed to zero
            # If y is a binary variable and x is a continuous variable, then y*x is linearzed as folllows
            # y*LowerBounod_of_x <= s <= y*UpperBound_of_x
            # x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
            # 
            # NOTE: The following constraints can be written for all reactions not including ignored_X_rxns, ignored_L_rxns and 
            #       ignored_U_rxns (becasue yX, yL and yU are set to zero for these reactions). However, for some reasons,
            #       when we write these constraints for these reactions. the optimization problem is not solved to optimality 
            #       and stops with a solution status of "other". This is despite the fact that when a knonwn solution is provided
            #       by fixing the binary variables, it doesn't make the optimizaiton problem infeasible. As such, I decided to
            #       write these constraints for all reactions as I didn't observe such awkward behavior in that case. 
            #
            # muLB_yX:
            # 0 <= muLB_yx[j] <= muLB_max[j]*yX[j]   where muLB_min = 0
            # muLB[j] - (1 - yX[j])*muLB_max[j] <= muLB_yX[j] <= muLB[j] - (1 - yX[j])*muLB_min[j] and muLB_min = 0
            optModel.linearize_muLB_yX_const1 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.muLB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muLB_yX_const2 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.muLB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muLB_yX[j])
            optModel.linearize_muLB_yX_const3 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.muLB_yX[j] <= optModel.muLB[j] - (1 - optModel.yX[j])*0)

            # muUB_yx[j]:
            # 0 <= muUB_yx[j] <= muUB_max[j]*yX[j]   where muUB_min = 0
            # muUB_min[j]*yX[j] <= muUB_yX[j] <= muUB_max*yX[j]  and muUB_min = 0
            optModel.linearize_muUB_yX_const1 = Constraint([j for j in optModel.J if j], rule = lambda optModel, j: optModel.muUB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muUB_yX_const2 = Constraint([j for j in optModel.J if j], rule = lambda optModel, j: optModel.muUB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muUB_yX[j])
            optModel.linearize_muUB_yX_const3 = Constraint([j for j in optModel.J if j], rule = lambda optModel, j: optModel.muUB_yX[j] <= optModel.muUB[j] - (1 - optModel.yX[j])*0)

            # thethaLB_yU[j]:
            # 0 <= thethaLB_yU[j] <= thethaLB_max[j]*yU[j]   where thethaLB_min = 0
            # thethaLB_min[j]*yU[j] <= thethaLB_yU[j] <= thethaLB_max*yU[j]  and thethaLB_min = 0
            optModel.linearize_thethaLB_yU_const1 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.thethaLB_yU[j] <= self._bigM_dualvar*optModel.yU[j])
            optModel.linearize_thethaLB_yU_const2 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.thethaLB[j] - (1 - optModel.yU[j])*self._bigM_dualvar <= optModel.thethaLB_yU[j])
            optModel.linearize_thethaLB_yU_const3 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.thethaLB_yU[j] <= optModel.thethaLB[j] - (1 - optModel.yU[j])*0)

            # thethaUB_yL[j]:
            # 0 <= thethaUB_yL[j] <= thethaUB_max[j]*yL[j]   where thethaUB_min = 0
            # thethaUB_min[j]*yL[j] <= thethaUB_yL[j] <= thethaUB_max*yL[j]  and thethaUB_min = 0
            optModel.linearize_thethaUB_yL_const1 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.thethaUB_yL[j] <= self._bigM_dualvar*optModel.yL[j])
            optModel.linearize_thethaUB_yL_const2 = Constraint([j for j in optModel.J], rule = lambda optModel, j: optModel.thethaUB[j] - (1 - optModel.yL[j])*self._bigM_dualvar <= optModel.thethaUB_yL[j])
            optModel.linearize_thethaUB_yL_const3 = Constraint([j for j in optModel.J], rule = lambda optMode, j: optModel.thethaUB_yL[j] <= optModel.thethaUB[j] - (1 - optModel.yL[j])*0)


        else:   # Simplified formulation
            # Only for reacitons that appear in the objective function (i.e., those with LB != -M and LB != 0)
            # muLB[j] - (1 - yX[j])*muLB_max[j] <= muLB_yX[j] <= muLB[j] - (1 - yX[j])*muLB_min[j] and muLB_min = 0
            optModel.linearize_muLB_yX_const1 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] != -self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[0] != 0], rule = lambda optModel, j: optModel.muLB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muLB_yX_const2 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] != -self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[0] != 0], rule = lambda optModel, j: optModel.muLB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muLB_yX[j])
            optModel.linearize_muLB_yX_const3 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] != -self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[0] != 0], rule = lambda optModel, j: optModel.muLB_yX[j] <= optModel.muLB[j] - (1 - optModel.yX[j])*0)

            # Only for reacitons that appear in the objective function (i.e., those with UB != M and UB != 0)
            # muUB_yx[j]:
            # 0 <= muUB_yx[j] <= muUB_max[j]*yX[j]   where muUB_min = 0
            # muUB_min[j]*yX[j] <= muUB_yX[j] <= muUB_max*yX[j]  and muUB_min = 0
            optModel.linearize_muUB_yX_const1 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] != self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[1] != 0], rule = lambda optModel, j: optModel.muUB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muUB_yX_const2 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] != self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[1] != 0], rule = lambda optModel, j: optModel.muUB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muUB_yX[j])
            optModel.linearize_muUB_yX_const3 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] != self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[1] != 0], rule = lambda optModel, j: optModel.muUB_yX[j] <= optModel.muUB[j] - (1 - optModel.yX[j])*0)

            # Only for reactions for which LB = -M
            optModel.muLB_yX_const = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] == -self._bigM_rxnflux], rule = lambda optModel,j:optModel.muLB[j] <= self._bigM_dualvar*optModel.yX[j])

            # Only for reactions for which UB = M
            optModel.muUB_yX_const = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] == self._bigM_rxnflux], rule = lambda optModel,j: optModel.muUB[j] <= self._bigM_dualvar*optModel.yX[j])

            # For all reactions 
            # NOTE: self.ignored_L_rxns and self.ignored_U_rxns should not be excluded
            # from the following two constraints. The reasons is that thethaLB and
            # thethalUB appear in dual_const for ALL reactions not just reactions 
            # that are a candidate for knockout. The following two constraints 
            # ensure that thethaLB and thethaUB are zero for any reaction that is
            # not a candidate for up/down-regulation
            optModel.thethaLB_yU_const = Constraint(optModel.J, rule = lambda optModel, j: optModel.thethaLB[j] <= self._bigM_dualvar*optModel.yU[j])
            optModel.thethaUB_yL_const = Constraint(optModel.J, rule = lambda optModel,j: optModel.thethaUB[j] <= self._bigM_dualvar*optModel.yL[j])


        #-- Strong duality -- 
        optModel.strong_duality_const = Constraint(rule=self.strong_duality_const_rule)

        self.optModel = optModel

        self._optModel_name = 'bilevel'

    def build_bilevel_optModel_v1(self):
        """
        Creates a pyomo optimization model for the bilevel problem 
        """
        # Define parameters and scalars needed to define the optimizaiton problem
        self.define_optModel_params()

        # Create a pyomo model optimization model
        optModel = ConcreteModel()

        #------------------ Sets -----------------------
        # Set of compounds 
        optModel.I = Set(initialize = [c.id for c in self.model.compounds])

        # Set of rxns  
        optModel.J = Set(initialize = [r.id for r in self.model.reactions])

        #----------------- Variables -------------------
        #-- Variables of the primal problem --
        # Reaction fluxes
        optModel.v = Var(optModel.J, domain=Reals, bounds = lambda optModel, j: self.model.reactions_by_id[j].flux_bounds)

        # Binary variables in for reactions considered for up-regulation, down-regulation or knockout 
        optModel.yL = Var(optModel.J, domain=Boolean)
        optModel.yU = Var(optModel.J, domain=Boolean)
        optModel.yX = Var(optModel.J, domain=Boolean)

        #-- Variables of the dual problem --
        # Dual variables associated with steady-state mass balance constraints
        # It's better to not provide upper and lower bound on lambda otherwise the dual objective 
        # will be slightly different from the primal's
        optModel.Lambda = Var(optModel.I, domain=Reals)

        # Dual variables associated with v_j >= LB_j*(1-yX(j) and v_j <= UB_j*(1-yX(j))
        optModel.muLB = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        optModel.muUB = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        optModel.muLB_yX = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        optModel.muUB_yX = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))

        # Dual variables associated with U_rxns_const: v(j) >= (LBon(j) - (-M))*yU(j) + (-M) (thethaLB) and  
        # L_rxns_const: v(j) <= (UBon(j) - bigM)*yU(j) + bigM (thethaUB)
        optModel.thethaLB = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        optModel.thethaUB = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
        if self.dual_formulation_type.lower() == 'standard':
            optModel.thethaLB_yU = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))
            optModel.thethaUB_yL = Var(optModel.J, domain=Reals, bounds = (0,self._bigM_dualvar))

        #------ Objective function of the outer problem ------
        optModel.objectiveFunc = Objective(rule = lambda optModel: optModel.v[self.product_exchrxn_id], sense = maximize)

        #---------------- Constraints ----------------------
        #-- Constraints of the outer problem --
        # Each rxn can participate in only one intervention: yL(j) + yU(j) + yX(j) =l= 1
        optModel.one_interven_forEachRxn_const = Constraint(optModel.J, rule = lambda optModel, j: optModel.yX[j] + optModel.yL[j] + optModel.yU[j] <= 1)

        # Restrict the total number of interventions: sum(j,yL(j) + yU(j) + yX(j)) =l= interven_num_curr;
        optModel.total_interven_const = Constraint(rule = lambda optModel: sum([optModel.yL[j] + optModel.yU[j] + optModel.yX[j] for j in optModel.J]) <= self._interven_num_curr)

        # Maximum allowed number of interventions outside of the MUST sets
        optModel.notMUST_interven_const = Constraint(rule = lambda optModel: sum([optModel.yX[j] for j in optModel.J if j not in self.X_rxns]) + sum([optModel.yL[j] for j in optModel.J if j not in self.L_rxns]) + sum([optModel.yU[j] for j in optModel.J if j not in self.U_rxns]) <= min(self._interven_num_curr, self.notMUST_max_interven_num))

        # Maximum allowed number of knockouts, up-regulations and down-regulations outside of X_rxns, U_rxns and L_rxns
        #optModel.notXrxns_interven_const = Constraint(rule = lambda optModel: sum([optModel.yX[j] for j in optModel.J if j not in self.X_rxns]) <= self.notXrxns_interven_num) 
        #optModel.notLrxns_interven_const = Constraint(rule = lambda optModel: sum([optModel.yL[j] for j in optModel.J if j not in self.L_rxns]) <= self.notLrxns_interven_num) 
        #optModel.notUrxns_interven_const = Constraint(rule = lambda optModel: sum([optModel.yU[j] for j in optModel.J if j not in self.U_rxns]) <= self.notUrxns_interven_num) 

        # Integer cuts
        optModel.integer_cuts = ConstraintList(noruleinit=True)

        #-- Constraints of the primal problem --
        # Mass balance 
        optModel.massBalance_const = Constraint(optModel.I, rule = lambda optModel, i: sum(j.stoichiometry[self.model.compounds_by_id[i]]*optModel.v[j.id] for j in self.model.compounds_by_id[i].reactions) == 0)

        # Constrain for U_rxns
        # v(j) >= LBon(j)*yU(j) + (1-yU(j))*LB(j) or v(j) =g= (LBon(j) - LB(j))*yU(j) + LB(j).
        # Instead of LB(j) use -bigM to make the constraint inactive when yU(j) = 0:
        # v(j) >= (LBon(j) - (-M))*yU(j) + (-M) 
        optModel.U_rxns_const = Constraint([j for j in optModel.J if j not in self.ignored_U_rxns], rule = lambda optModel, j: optModel.v[j] >= (self.flux_bounds_overprod[j][0] + self._bigM_rxnflux)*optModel.yU[j] - self._bigM_rxnflux)

        # Constraint for L_rxns
        # v(j) <= UBon(j)*yL(j) + (1-yL(j))*UB(j) or v(j) =l= (UBon(j) - UB(j))*yL(j) + UB(j)
        # Instead of UB(j) use bigM to make the constraint inactive when yL(j) = 0:
        # v(j) <= (UBon(j) - bigM)*yL(j) + bigM
        optModel.L_rxns_const = Constraint([j for j in optModel.J if j not in self.ignored_L_rxns], rule = lambda optModel, j: optModel.v[j] <= (self.flux_bounds_overprod[j][1] - self._bigM_rxnflux)*optModel.yL[j] + self._bigM_rxnflux)

        # Constraints for X_rxns. This constraint is written over all reactions (not just thos ein X_rxns) to incorporate
        # their LB and UB into the calculations
        # LB(j)*(1 - yX(j)) <= v(j)  and v(j) <= UB(j)*(1 - yX(j)) 
        optModel.X_rxns_const1 = Constraint(optModel.J, rule = lambda optModel, j: optModel.v[j] >= self.model.reactions_by_id[j].flux_bounds[0]*(1 - optModel.yX[j]) )
        optModel.X_rxns_const2 = Constraint(optModel.J, rule = lambda optModel, j: optModel.v[j] <= self.model.reactions_by_id[j].flux_bounds[1]*(1 - optModel.yX[j]))

        #-- Constraints of the dual problem --
        # dual constraints 
        optModel.dual_const = Constraint(optModel.J, rule=self.dual_const_rule)

        if self.dual_formulation_type.lower() == 'standard':
            # Constraints linearizing the product of continuous and binary variables
            # This constraint is not written for reactions in self.ignored_X_rxns, self.ignored_L_rxns and self.ignored_U_rxns because 
            # they have already been fixed to zero
            # If y is a binary variable and x is a continuous variable, then y*x is linearzed as folllows
            # y*LowerBounod_of_x <= s <= y*UpperBound_of_x
            # x - (1-y)*UpperBound_of_x <= s <= x- (1-y)*LowerBound_of_x 
            # 
            # muLB_yX:
            # 0 <= muLB_yx[j] <= muLB_max[j]*yX[j]   where muLB_min = 0
            # muLB[j] - (1 - yX[j])*muLB_max[j] <= muLB_yX[j] <= muLB[j] - (1 - yX[j])*muLB_min[j] and muLB_min = 0
            """
            optModel.linearize_muLB_yX_const1 = Constraint([j for j in optModel.J if j not in self.ignored_X_rxns], rule = lambda optModel, j: optModel.muLB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muLB_yX_const2 = Constraint([j for j in optModel.J if j not in self.ignored_X_rxns], rule = lambda optModel, j: optModel.muLB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muLB_yX[j])
            optModel.linearize_muLB_yX_const3 = Constraint([j for j in optModel.J if j not in self.ignored_X_rxns], rule = lambda optModel, j: optModel.muLB_yX[j] <= optModel.muLB[j] - (1 - optModel.yX[j])*0)

            # muUB_yx[j]:
            # 0 <= muUB_yx[j] <= muUB_max[j]*yX[j]   where muUB_min = 0
            # muUB_min[j]*yX[j] <= muUB_yX[j] <= muUB_max*yX[j]  and muUB_min = 0
            optModel.linearize_muUB_yX_const1 = Constraint([j for j in optModel.J if j not in self.ignored_X_rxns], rule = lambda optModel, j: optModel.muUB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muUB_yX_const2 = Constraint([j for j in optModel.J if j not in self.ignored_X_rxns], rule = lambda optModel, j: optModel.muUB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muUB_yX[j])
            optModel.linearize_muUB_yX_const3 = Constraint([j for j in optModel.J if j not in self.ignored_X_rxns], rule = lambda optModel, j: optModel.muUB_yX[j] <= optModel.muUB[j] - (1 - optModel.yX[j])*0)
            
           
            # thethaLB_yU[j]:
            # 0 <= thethaLB_yU[j] <= thethaLB_max[j]*yU[j]   where thethaLB_min = 0
            # thethaLB_min[j]*yU[j] <= thethaLB_yU[j] <= thethaLB_max*yU[j]  and thethaLB_min = 0
            optModel.linearize_thethaLB_yU_const1 = Constraint([j for j in optModel.J if j not in self.ignored_U_rxns], rule = lambda optModel, j: optModel.thethaLB_yU[j] <= self._bigM_dualvar*optModel.yU[j])
            optModel.linearize_thethaLB_yU_const2 = Constraint([j for j in optModel.J if j not in self.ignored_U_rxns], rule = lambda optModel, j: optModel.thethaLB[j] - (1 - optModel.yU[j])*self._bigM_dualvar <= optModel.thethaLB_yU[j])
            optModel.linearize_thethaLB_yU_const3 = Constraint([j for j in optModel.J if j not in self.ignored_U_rxns], rule = lambda optModel, j: optModel.thethaLB_yU[j] <= optModel.thethaLB[j] - (1 - optModel.yU[j])*0)

            # thethaUB_yL[j]:
            # 0 <= thethaUB_yL[j] <= thethaUB_max[j]*yL[j]   where thethaUB_min = 0
            # thethaUB_min[j]*yL[j] <= thethaUB_yL[j] <= thethaUB_max*yL[j]  and thethaUB_min = 0
            optModel.linearize_thethaUB_yL_const1 = Constraint([j for j in optModel.J if j not in self.ignored_L_rxns], rule = lambda optModel, j: optModel.thethaUB_yL[j] <= self._bigM_dualvar*optModel.yL[j])
            optModel.linearize_thethaUB_yL_const2 = Constraint([j for j in optModel.J if j not in self.ignored_L_rxns], rule = lambda optModel, j: optModel.thethaUB[j] - (1 - optModel.yL[j])*self._bigM_dualvar <= optModel.thethaUB_yL[j])
            optModel.linearize_thethaUB_yL_const3 = Constraint([j for j in optModel.J if j not in self.ignored_L_rxns], rule = lambda optMode, j: optModel.thethaUB_yL[j] <= optModel.thethaUB[j] - (1 - optModel.yL[j])*0)
            """
            optModel.linearize_muLB_yX_const1 = Constraint([j for j in optModel.J if j not in self.ignored_X_rxns], rule = lambda optModel, j: optModel.muLB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muLB_yX_const2 = Constraint([j for j in optModel.J if j not in self.ignored_X_rxns], rule = lambda optModel, j: optModel.muLB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muLB_yX[j])
            optModel.linearize_muLB_yX_const3 = Constraint([j for j in optModel.J if j not in self.ignored_X_rxns], rule = lambda optModel, j: optModel.muLB_yX[j] <= optModel.muLB[j] - (1 - optModel.yX[j])*0)

            # muUB_min[j]*yX[j] <= muUB_yX[j] <= muUB_max*yX[j]  and muUB_min = 0
            optModel.linearize_muUB_yX_const1 = Constraint([j for j in optModel.J if j not in self.ignored_X_rxns], rule = lambda optModel, j: optModel.muUB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muUB_yX_const2 = Constraint([j for j in optModel.J if j not in self.ignored_X_rxns], rule = lambda optModel, j: optModel.muUB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muUB_yX[j])
            optModel.linearize_muUB_yX_const3 = Constraint([j for j in optModel.J if j not in self.ignored_X_rxns], rule = lambda optModel, j: optModel.muUB_yX[j] <= optModel.muUB[j] - (1 - optModel.yX[j])*0)

            # thethaLB_min[j]*yU[j] <= thethaLB_yU[j] <= thethaLB_max*yU[j]  and thethaLB_min = 0
            optModel.linearize_thethaLB_yU_const1 = Constraint([j for j in optModel.J if j not in self.ignored_U_rxns], rule = lambda optModel, j: optModel.thethaLB_yU[j] <= self._bigM_dualvar*optModel.yU[j])
            optModel.linearize_thethaLB_yU_const2 = Constraint([j for j in optModel.J if j not in self.ignored_U_rxns], rule = lambda optModel, j: optModel.thethaLB[j] - (1 - optModel.yU[j])*self._bigM_dualvar <= optModel.thethaLB_yU[j])
            optModel.linearize_thethaLB_yU_const3 = Constraint([j for j in optModel.J if j not in self.ignored_U_rxns], rule = lambda optModel, j: optModel.thethaLB_yU[j] <= optModel.thethaLB[j] - (1 - optModel.yU[j])*0)

            # thethaUB_min[j]*yL[j] <= thethaUB_yL[j] <= thethaUB_max*yL[j]  and thethaUB_min = 0
            optModel.linearize_thethaUB_yL_const1 = Constraint([j for j in optModel.J if j not in self.ignored_L_rxns], rule = lambda optModel, j: optModel.thethaUB_yL[j] <= self._bigM_dualvar*optModel.yL[j])
            optModel.linearize_thethaUB_yL_const2 = Constraint([j for j in optModel.J if j not in self.ignored_L_rxns], rule = lambda optModel, j: optModel.thethaUB[j] - (1 - optModel.yL[j])*self._bigM_dualvar <= optModel.thethaUB_yL[j])
            optModel.linearize_thethaUB_yL_const3 = Constraint([j for j in optModel.J if j not in self.ignored_L_rxns], rule = lambda optMode, j: optModel.thethaUB_yL[j] <= optModel.thethaUB[j] - (1 - optModel.yL[j])*0)


        if self.dual_formulation_type.lower() == 'simplified':
            # Only for reacitons that appear in the objective function (i.e., those with LB != -M and LB != 0)
            # 0 <= muLB_yx[j] <= muLB_max[j]*yX[j]   where muLB_min = 0
            # muLB[j] - (1 - yX[j])*muLB_max[j] <= muLB_yX[j] <= muLB[j] - (1 - yX[j])*muLB_min[j] and muLB_min = 0
            optModel.linearize_muLB_yX_const1 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] != -self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[0] != 0], rule = lambda optModel, j: optModel.muLB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muLB_yX_const2 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] != -self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[0] != 0], rule = lambda optModel, j: optModel.muLB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muLB_yX[j])
            optModel.linearize_muLB_yX_const3 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] != -self._bigM_rxnflux and self.model.reactions_by_id[j].flux_bounds[0] != 0], rule = lambda optModel, j: optModel.muLB_yX[j] <= optModel.muLB[j] - (1 - optModel.yX[j])*0)

            # Only for reacitons that appear in the objective function (i.e., those with UB != M)
            # muUB_yx[j]:
            # 0 <= muUB_yx[j] <= muUB_max[j]*yX[j]   where muUB_min = 0
            # muUB_min[j]*yX[j] <= muUB_yX[j] <= muUB_max*yX[j]  and muUB_min = 0
            optModel.linearize_muUB_yX_const1 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] != self._bigM_rxnflux], rule = lambda optModel, j: optModel.muUB_yX[j] <= self._bigM_dualvar*optModel.yX[j])
            optModel.linearize_muUB_yX_const2 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] != self._bigM_rxnflux], rule = lambda optModel, j: optModel.muUB[j] - (1 - optModel.yX[j])*self._bigM_dualvar <= optModel.muUB_yX[j])
            optModel.linearize_muUB_yX_const3 = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] != self._bigM_rxnflux], rule = lambda optModel, j: optModel.muUB_yX[j] <= optModel.muUB[j] - (1 - optModel.yX[j])*0)

            # Only for reactions for which LB = -M
            optModel.muLB_yX_const = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[0] == -self._bigM_rxnflux], rule = lambda optModel,j:optModel.muLB[j] <= self._bigM_dualvar*optModel.yX[j])


            # Only for reactions for which UB = M
            optModel.muUB_yX_const = Constraint([j for j in optModel.J if self.model.reactions_by_id[j].flux_bounds[1] == self._bigM_rxnflux], rule = lambda optModel,j: optModel.muUB[j] <= self._bigM_dualvar*optModel.yX[j])

            # For all reactions that are a candidate for up/down-regulation
            optModel.thethaLB_yU_const = Constraint([j for j in optModel.J if j not in self.ignored_U_rxns], rule = lambda optModel, j: optModel.thethaLB[j] <= self._bigM_dualvar*optModel.yU[j])
            optModel.thethaUB_yL_const = Constraint([j for j in optModel.J if j not in self.ignored_L_rxns], rule = lambda optModel,j: optModel.thethaUB[j] <= self._bigM_dualvar*optModel.yL[j])

        #-- Strong duality -- 
        optModel.strong_duality_const = Constraint(rule=self.strong_duality_const_rule)

        self.optModel = optModel

    def fix_known_variables(self):
        """
        Fixies all known binary variables to zero/one
        """
        # Do not manipulate reactions in self.ignorex_X_rxns
        for rxn in self.ignored_X_rxns:
            self.optModel.yX[rxn] = 0
            self.optModel.yX[rxn].fixed = True

            if self._optModel_name in ['dual','bilevel']:
                self.optModel.muLB_yX[rxn] = 0
                self.optModel.muLB_yX[rxn].fixed = True
                self.optModel.muUB_yX[rxn] = 0
                self.optModel.muUB_yX[rxn].fixed = True

        for rxn in self.ignored_L_rxns:
            self.optModel.yL[rxn] = 0
            self.optModel.yL[rxn].fixed = True
            if self._optModel_name in ['dual','bilevel'] and self.dual_formulation_type.lower() == 'standard':
                self.optModel.thethaUB_yL[rxn] = 0 
                self.optModel.thethaUB_yL[rxn].fixed = True

        for rxn in self.ignored_U_rxns:
            self.optModel.yU[rxn] = 0
            self.optModel.yU[rxn].fixed = True
            if self._optModel_name in ['dual','bilevel'] and self.dual_formulation_type.lower() == 'standard':
                self.optModel.thethaLB_yU[rxn] = 0 
                self.optModel.thethaLB_yU[rxn].fixed = True 

        # Fix binary variables for a priori imposed knockouts, down-regulations and up-regulations
        for rxn in self.fixed_X_rxns:
            self.optModel.yX[rxn] = 1 
            self.optModel.yX[rxn].fixed = True

        for rxn in self.fixed_L_rxns:
            self.optModel.yL[rxn] = 1 
            self.optModel.yL[rxn].fixed = True

        for rxn in self.fixed_U_rxns:
            self.optModel.yU[rxn] = 1 
            self.optModel.yU[rxn].fixed = True

    def single_run(self):
        """
        Performs a single run of the code
        """
        # Processing and wall time for pyomo
        start_preproc_pyomo_pt = time.clock()
        start_preproc_pyomo_wt = time.time()

        # Reset model flux bounds
        self.set_model_flux_bounds()

        # Instantiate the optModel (no londer needed in versions 4.X or higher of pyomo)
        #self.optModel.preprocess()

        elapsed_preproc_pyomo_pt = str(timedelta(seconds = time.clock() - start_preproc_pyomo_pt))
        elapsed_preproc_pyomo_wt = str(timedelta(seconds = time.time() - start_preproc_pyomo_wt))

        #---- Solve the model ----
        #- Solve the optModel (tee=True shows the solver output) -
        try:
            # Processing and wall time for the solver
            start_solver_pt = time.clock()
            start_solver_wt = time.time()

            optSoln = self._optSolver.solve(self.optModel,tee=False)
            solver_status = str(optSoln.solver.status)
            termination_condition = str(optSoln.solver.termination_condition)

            soln_load_flag = 'normal'

        except  Exception, e:
            soln_load_flag = 'failed'
            if self.warnings:
                print '**WARNING (FORCE)! Loading soluiton using {} failed with the following error: \n{} \n'.format(self.optimization_solver,e)

        elapsed_solver_pt = str(timedelta(seconds = time.clock() - start_solver_pt))
        elapsed_solver_wt = str(timedelta(seconds = time.time() - start_solver_wt))

        if soln_load_flag == 'normal' and solver_status == 'ok' and termination_condition in ['optimal', 'globallyOptimal']:

            exit_flag = 'globallyOptimal'

            # Load the results (no londer needed in versions 4.X or higher of pyomo)
            #self.optModel.load(optSoln)

            # Optimal value of the objective function
            opt_objValue = self.optModel.objectiveFunc()

            # Optimal flux of exchange rxn for product of interest
            opt_productFlux = self.optModel.v[self.product_exchrxn_id].value

            # Reactions that must be knocked out, up-regulated or down-regulated
            #yX_one_rxns = [j for j in self.optModel.J if abs(self.optModel.yX[j].value - 1) <= mip_integrality_tol]
            #yL_one_rxns = [j for j in self.optModel.J if abs(self.optModel.yL[j].value - 1) <= mip_integrality_tol]
            #yU_one_rxns = [j for j in self.optModel.J if abs(self.optModel.yU[j].value - 1) <= mip_integrality_tol]
            yX_one_rxns = [j for j in self.optModel.J if self.optModel.yX[j].value == 1]
            yL_one_rxns = [j for j in self.optModel.J if self.optModel.yL[j].value == 1]
            yU_one_rxns = [j for j in self.optModel.J if self.optModel.yU[j].value == 1]

        # If there was a solver error or if an optimal solution was not returned 
        else:
            opt_objValue = None
            opt_productFlux = None
            if soln_load_flag == 'failed': 
                exit_flag = 'Failed to load the optimal solution due to an unexpected error' 
            else:
                exit_flag = 'solver status = {}, termiination condition = {}'.format(solver_status, termination_condition)

            # Reactions that must be knocked out, up-regulated or down-regulated
            yX_one_rxns = []
            yL_one_rxns = []
            yU_one_rxns = []

        # Store the solution
        self._curr_soln = {'exit_flag':exit_flag, 'opt_productFlux':opt_productFlux, 'objective_value':opt_objValue,'interven_num': len(yX_one_rxns) + len(yL_one_rxns) + len(yU_one_rxns),'X_rxns':yX_one_rxns,'L_rxns':yL_one_rxns,'U_rxns':yU_one_rxns}

        # Print the results on the screen 
        if self.stdout_msgs_details:
            print '\nObjective value = {}, Optimality status = {}, Solution status = {}, Solver run status = {}'.format(opt_objValue, optSoln.solver.termination_condition, optSoln.Solution.status, solver_flag)
            print 'Took (hh:mm:ss) {}/{} of processing/walltime to create a pyomo model, {}/{} to  preprcoess the model and {}/{} to solve the model\n'.format(self._elapsed_create_optModel_pt, self._elapsed_create_optModel_wt, elapsed_preproc_pyomo_pt,elapsed_preproc_pyomo_wt, elapsed_solver_pt,elapsed_solver_wt)

    def find_min_product_yield(self, validate = True):
        """
        If validate is True it Validates an obtained solution. 
        if validate is False, it finds the min product yield for a set of fixed binary
        variables provided by self.fixed_X_rxns, self.fixed_L_rxns and self.fixed_U_rxns
        """
        for rxn in self.model.reactions:
            rxn.objective_coefficient = 0
        self.model.reactions_by_id[self.product_exchrxn_id].objective_coefficient = 1                

        if validate:
            self.set_model_flux_bounds()
            for j in self._curr_soln['X_rxns']:
                self.model.reactions_by_id[j].flux_bounds = [0,0]
            for j in self._curr_soln['L_rxns']:
                self.model.reactions_by_id[j].flux_bounds[1] = self.flux_bounds_overprod[j][1]
            for j in self._curr_soln['U_rxns']:
                self.model.reactions_by_id[j].flux_bounds[0] = self.flux_bounds_overprod[j][0]

            if hasattr(self.model,'fba_model'):
                self.model.fba(build_new_optModel = False, maximize = False, stdout_msgs = False)
            else:
                self.model.fba(build_new_optModel = True, maximize = False, stdout_msgs = False)

        else:
            self.set_model_flux_bounds()
            for j in self.fixed_X_rxns:
                self.model.reactions_by_id[j].flux_bounds = [0,0]
            for j in self.fixed_L_rxns:
                self.model.reactions_by_id[j].flux_bounds[1] = self.flux_bounds_overprod[j][1]
            for j in self.fixed_U_rxns:
                self.model.reactions_by_id[j].flux_bounds[0] = self.flux_bounds_overprod[j][0]
            self.model.fba(build_new_optModel = True, maximize = False, stdout_msgs = False)

        if self.model.fba_model.solution['exit_flag'] == 'globallyOptimal': 
            if validate and (self._curr_soln['opt_productFlux'] - self.model.fba_model.solution['objective_value'] > 1e-6):
                raise userError('Validation failed for X_rxns = {} , L_rxns = {} , U_rxns = {} because the production flux of the product ({}) is less than the objective function value of the optimizaiton problem for identifhing FORCE sets ({})'.format(self._curr_soln['X_rxns'], self._curr_soln['L_rxns'], self._curr_soln['U_rxns'], self.model.fba_model.solution['objective_value'], self._curr_soln['opt_productFlux']))
            elif not validate:
                self._best_product_yield_soFar_init = self.model.fba_model.solution['objective_value']
            else:
                if self.stdout_msgs_details:
                    print 'The following soluiton was successfully validates: X_rxns = {}\nL_rxns = {}\nU_rxns = {}'.format(self._curr_soln['X_rxns'],self._curr_soln['L_rxns'],self._curr_soln['U_rxns'])

        elif self.model.fba_model.solution['exit_flag'] != 'globallyOptimal':
            raise userError('Validaiton failed for X_rxns = {} , L_rxns = {} , U_rxns = {} because the fba problem to find the minimum production flux of the product was not solved to optimality and ended with an exit_flag of {}'.format(self._curr_soln['X_rxns'], self._curr_soln['L_rxns'], self._curr_soln['U_rxns'], self.model.fba_model.solution['exit_flag']))

        else:  # If validated, then reset the flux bounds for the model
            self.set_model_flux_bounds()
            for rxn in self.model.reactions:
                rxn.objective_coefficient = 0
            self.model.biomass_reaction.objective_coefficient = 1

    def run(self):
        """ 
        This method runs FBA. 

        OUTPUT:
        -------
        solution: A list of dictionaries with the following keys:
        """
        # Total processing and wall time required to create the pyomo model, solve it and store the results 
        start_total_pt = time.clock()
        start_total_wt = time.time()

        # Set flux bounds for the model
        self.set_model_flux_bounds()

        # Number of solutions found so far
        found_solutions_num = 0

        # Number of solutions found for a given number of interventions
        found_solns_num_for_interven_num_curr = 0

        # Current max number of interventions
        if len(self.fixed_X_rxns) + len(self.fixed_L_rxns) + len(self.fixed_U_rxns) == 0:
            self._interven_num_curr = self.min_interven_num
        else:
            if len(self.fixed_X_rxns) + len(self.fixed_L_rxns) + len(self.fixed_U_rxns) > self.max_interven_num:
                raise userError('The number of fixed L, U and X reactions ({}) is higher than max allowed number of interventions ()'.format(len(self.fixed_X_rxns) + len(self.fixed_L_rxns) + len(self.fixed_U_rxns) , self.max_interven_num))
            else:
                self._interven_num_curr = min(self.max_interven_num, max(self.min_interven_num, len(self.fixed_X_rxns) + len(self.fixed_L_rxns) + len(self.fixed_U_rxns) + 1))

        # Find the min product yield, if the number of fixed interventions has already provided using fixed_X_rxns, 
        # fixed_L_rxns or fixed_U_rxns,
        if len(self.fixed_X_rxns) + len(self.fixed_L_rxns) + len(self.fixed_U_rxns) > 0:
            self.find_min_product_yield(validate = False)
        else:
            self._best_product_yield_soFar_init = 0.0

        if self.stdout_msgs:
            print '\nMin product yield with fixed input interventions (if any) = {:.4f} ({:.2f}% of theoretical maximum = {:.4f}) , biomass flux = {:.4f} ({:.2}%) of max biomass = {:.4f})'.format(self._best_product_yield_soFar_init, 100*self._best_product_yield_soFar_init/self.product_max_theor_yield, self.product_max_theor_yield, self.model.fba_model.optModel.v[self.biomass_rxn_id].value, 100*self.model.fba_model.optModel.v[self.biomass_rxn_id].value/self.max_biomass_flux, self.max_biomass_flux)

        # Best product yield achieved so far
        self._best_product_yield_soFar = self._best_product_yield_soFar_init

        # Best product yield achieved for the current number of iterations
        self._best_product_yield_prevIntervenNum = self._best_product_yield_soFar_init

        if self.results_filename != '':
            with open(self.results_filename,'w') as f:
                f.write('FORCE_sets = [\n')

        # Creating the pyomo optModel 
        if self.build_new_optModel:
            start_pyomo_pt = time.clock()
            start_pyomo_wt = time.time()

            self.build_bilevel_optModel()

            self._elapsed_create_optModel_pt = str(timedelta(seconds = time.clock() - start_pyomo_pt))
            self._elapsed_create_optModel_wt = str(timedelta(seconds = time.time() - start_pyomo_wt))
        else:
            self._elapsed_create_optModel_pt = 0 
            self._elapsed_create_optModel_wt = 0 

        # Fix known variables
        self.fix_known_variables()

        # Write model into a mps file
        #self.optModel.write(home_dir + 'work/tools/strain_design/OptForce/FORCE_optModel.mps')

        # Create a solver and set the options
        self._optSolver = pyomoSolverCreator(self.optimization_solver, max_threads_num = self.max_threads_num)

        # A list of dictionaries holding the optimal solution in different iterations
        self.solutions = []
        done = False

        if self.stdout_msgs:
            print '\n----- Set of ignored interventions ------\n'
            print '\nKnockouts = ',self._ignored_X_rxns_user
            print '\nDown-regulations = ', self._ignored_L_rxns_user
            print '\nUp-regulations = ', self._ignored_U_rxns_user

            print '\n----- Set of fixed interventions ------\n'
            print '\nKnockouts = ',self.fixed_X_rxns
            print '\nDown-regulations = ', self.fixed_L_rxns
            print '\nUp-regulations = ', self.fixed_U_rxns
            
            print '\n'

            print '\n-------- # of interventions = {} ----------\n'.format(self._interven_num_curr)

        # For a given number of interventions we keep finding alternative solutions all giving the same objective 
        # function value. If the problem becomes infeasible or the objective funciton is less than the best current
        # then we increase the number of iterventions 
        while not done: 

            print '\n# of interventions = {}'.format(self._interven_num_curr)

            # Solve the optimizaiton model 
            self.single_run()

            # Check whether the current run was successful
            if self._curr_soln['exit_flag'] == 'globallyOptimal':

                # Validate the solution
                if self.validate_results:
                    self.find_min_product_yield(validate = True)

                # If the product yield for the current number of iterations is zero, move on  
                # by increasing the number of interventions
                if abs(self._curr_soln['opt_productFlux']) < 1e-6:
                    if self.stdout_msgs:
                        print '\n** Iterations with {} interventions stopped with the following solution, which results in a production flux of almost zero for the target product'.format(self._interven_num_curr)
                        self.print_results_summary()

                    if self._interven_num_curr < self.max_interven_num:
                        self._interven_num_curr += 1
                        self._best_product_yield_prevIntervenNum = self._best_product_yield_soFar

                        # Reconstruct the optModel again to use the updated value of self._interven_num_curr
                        # NOTE: Instead of redefining the model, we can just redefine
                        # the constraints that include self._interven_num_curr, however, it seems that 
                        # pyomo doesn't do this effectively (or I don't know how to to do this correctly!) 
                        # as the optimizaiton problem stops with a solver status of 'other', while if a known
                        # solution is fixed, the optimization problem is solved to optimaility (not infeasible or something)
                        del self.optModel
                        self.set_model_flux_bounds()
                        self.build_bilevel_optModel()
                        self.fix_known_variables()

                        found_solns_num_for_interven_num_curr = 0

                        if self.stdout_msgs:
                            print '\n-------- # of interventions = {} ----------\n'.format(self._interven_num_curr)
                            print 'Best product yield achieved with the previous number of interventions = {}'.format(self._best_product_yield_prevIntervenNum)  

                    else:
                        done = True 
         
                # Stop or increase the number of interventions, if 
                # (i) the product yield with the current number of interventions is 
                # less than or equal to the best product yield achieved with the 
                # previous number of interventions, or
                # (ii) The identified number of interventions is less thanthe current 
                # max allowed number of interventions
                elif self._curr_soln['opt_productFlux'] <= self._best_product_yield_prevIntervenNum + self.thr_to_increase_interven_num or len(self._curr_soln['X_rxns']) + len(self._curr_soln['L_rxns']) + len(self._curr_soln['U_rxns']) < self._interven_num_curr:
                    # print a summary of results in the output
                    if self.stdout_msgs:
                        if len(self._curr_soln['X_rxns']) + len(self._curr_soln['L_rxns']) + len(self._curr_soln['U_rxns']) < self._interven_num_curr:
                            print '\n** Iterations with {} interventions stopped with the following solution, since the number of interventions in this solution ({}) is less than the current max allowed number of interventions ({})'.format(self._interven_num_curr, len(self._curr_soln['X_rxns']) + len(self._curr_soln['L_rxns']) + len(self._curr_soln['U_rxns']), self._interven_num_curr)
                        elif self._curr_soln['opt_productFlux'] < self._best_product_yield_prevIntervenNum + self.thr_to_increase_interven_num: 
                            print '\n** Iterations with {} interventions stopped with the following solution because the obtained production flux of the product + the threshold for increasing the number of interventions ({}) is less than or equal to the best yield achieved with a lower number of interventions ({})'.format(self._interven_num_curr, self.thr_to_increase_interven_num, self._best_product_yield_prevIntervenNum)
                        else:
                            print '\n** Iterations with {} interventions stopped for an unknown reason (see FORCE.py for inspectoins)!'.format(self._interven_num_curr)

                        self.print_results_summary()

                    # Stop All iterations if the target yield has already been achieved or max_interven_num has been reached
                    if self._best_product_yield_soFar >= (self.product_targetYield_percent/100)*self.product_max_theor_yield or self._interven_num_curr == self.max_interven_num:
                        done = True
                        if self.stdout_msgs:
                            if self._best_product_yield_soFar >= (self.product_targetYield_percent/100)*self.product_max_theor_yield: 
                                print 'All iterations stopped because the best product yield achieved so far ({}) satisfies the target product yield ({})'.format(self._best_product_yield_soFar, (self.product_targetYield_percent/100)*self.product_max_theor_yield)
                            elif self._interven_num_curr == self.max_interven_num:
                                print 'All iterations stopped because the maximum number of interventions ({}) has reached'.format(self.max_interven_num)

                    # If the target yield has not been achieved, increase the number of interventions if 
                    else:
                        self._interven_num_curr += 1
                        found_solns_num_for_interven_num_curr = 0
                        if self._interven_num_curr <= self.max_interven_num:
                            self._best_product_yield_prevIntervenNum = self._best_product_yield_soFar

                            # Reconstruct the optModel again to use the updated value of self._interven_num_curr
                            del self.optModel
                            self.set_model_flux_bounds()
                            self.build_bilevel_optModel()
                            self.fix_known_variables()
                            if self.stdout_msgs and self._interven_num_curr <= self.max_interven_num:
                                print '\n-------- # of interventions = {} ----------\n'.format(self._interven_num_curr)
                                print 'Best product yield achieved with the previous number of interventions = {}'.format(self._best_product_yield_prevIntervenNum)  


                # Otherwise store the results
                else:
                    found_solutions_num += 1
                    found_solns_num_for_interven_num_curr += 1
                   
                    if self._curr_soln['opt_productFlux'] > self._best_product_yield_soFar:
                        self._best_product_yield_soFar = self._curr_soln['opt_productFlux']
                        if self.stdout_msgs:
                            print '\nBest product yield achieved so far was updated to: {:.2f} mol/({} mol of carbon src) = {:.2f} g/g of carbon source ({:.2f}% of molar theoretical max)\n'.format(self._best_product_yield_soFar, self.moles_of_carbonSrc_takenup, self._best_product_yield_soFar*self.product_MW/(self.moles_of_carbonSrc_takenup*self.carbonSrc_MW), 100*self._best_product_yield_soFar/self.product_max_theor_yield)

                    self.solutions.append(self._curr_soln)

                    # Add an integer cut excluding the current solution. 
                    # we check if their distance from one is less than mip_integrality_tol
                    # Total number of yX, yL and yU variables is 3*len(self.optModel.J)
                    self.optModel.integer_cuts.add(
                         sum([self.optModel.yX[j] for j in self._curr_soln['X_rxns']]) + \
                         sum([self.optModel.yL[j] for j in self._curr_soln['L_rxns']]) + \
                         sum([self.optModel.yU[j] for j in self._curr_soln['U_rxns']]) + \
                         sum([1 - self.optModel.yX[j] for j in self.optModel.J if j not in self._curr_soln['X_rxns']]) + \
                         sum([1 - self.optModel.yL[j] for j in self.optModel.J if j not in self._curr_soln['L_rxns']]) + \
                         sum([1 - self.optModel.yU[j] for j in self.optModel.J if j not in self._curr_soln['U_rxns']]) <= \
                         len(self.optModel.yX) + len(self.optModel.yL) + len(self.optModel.yU) - 1)
                         
                    # print a summary of results in the output
                    if self.stdout_msgs:
                        print '\n{})'.format(found_solutions_num)
                        self.print_results_summary()
                        #print '\nAdded integer cut (not including the ones that were zero): {}'.format(sum([self.optModel.yX[j] for j in self._curr_soln['X_rxns']]) + sum([self.optModel.yL[j] for j in self._curr_soln['L_rxns']]) + sum([self.optModel.yU[j] for j in self._curr_soln['U_rxns']]) <= len(self.optModel.yX) + len(self.optModel.yL) + len(self.optModel.yU) - 1)

                    # Write results into the file
                    if self.results_filename != '':
                       with open(self.results_filename,'a') as f:
                           f.write('\n\n{')
                           f.write("'Max biomass flux':{:.4f},\n".format(self.max_biomass_flux))
                           f.write("'Max theoretical product flux (mol of product/max allowed mol of carbon source)':{:.4f},\n".format(self.product_max_theor_yield))
                           f.write("'Max theoretical product yield (g of product/g of carbon source)':{:.4f},\n".format(self.product_max_theor_yield_g_per_g))
                           f.write("'Maxmin product flux achieved with interventions (mol/gDW.h)':{:.4f},\n".format(self.optModel.v[self.product_exchrxn_id].value)) 
                           f.write("'Maxmin mass product yield achieved with interventions (g of product/g of carbon source taken up)':{:.4f},\n".format(self.optModel.v[self.product_exchrxn_id].value*self.product_MW/(self.moles_of_carbonSrc_takenup*self.carbonSrc_MW))) 
                           f.write("'Maxmin product flux is what percentage of max theoretical flux':{:.2f},\n".format(100*self.optModel.v[self.product_exchrxn_id].value/self.product_max_theor_yield))
                           f.write("'Biomass flux with interventions':{:.4f},\n".format(self.optModel.v[self.biomass_rxn_id].value)) 
                           f.write("'Biomass flux with interventions is what percentage of theoreical max':{:.2f},\n".format(100*self.optModel.v[self.biomass_rxn_id].value/self.max_biomass_flux)) 
                           f.write("'ignored_X_rxns': {},\n".format(self._ignored_X_rxns_user)) 
                           f.write("'ignored_L_rxns': {},\n".format(self._ignored_L_rxns_user)) 
                           f.write("'ignored_U_rxns': {},\n".format(self._ignored_U_rxns_user)) 
                           f.write("'fixed_X_rxns': {},\n".format(self.fixed_X_rxns)) 
                           f.write("'fixed_L_rxns': {},\n".format(self.fixed_L_rxns)) 
                           f.write("'fixed_U_rxns:: {},\n\n".format(self.fixed_U_rxns)) 
                           f.write("'X_rxns': [\n") 
                           for r_id in self._curr_soln['X_rxns']:
                               rxn = self.model.reactions_by_id[r_id] # reaction object
                               f.write("{{'id':'{}','name':'{}', 'gpr':'{}', 'subsystem':'{}', 'ref_bounds':{}, 'overprod_bounds':{}}},\n".format(r_id,rxn.name,rxn.gene_reaction_rule, rxn.subsystem, self.flux_bounds_ref[r_id], self.flux_bounds_overprod[r_id]))
                           f.write('],\n') 

                           f.write("'L_rxns': [\n") 
                           for r_id in self._curr_soln['L_rxns']:
                               rxn = self.model.reactions_by_id[r_id] # reaction object
                               f.write("{{'id':'{}','name':'{}', 'gpr':'{}', 'ref_bounds':{}, 'overprod_bounds':{}}},\n".format(r_id,rxn.name, rxn.gene_reaction_rule, self.flux_bounds_ref[r_id], self.flux_bounds_overprod[r_id]))
                           f.write('],\n') 

                           f.write("'U_rxns':[\n") 
                           for r_id in self._curr_soln['U_rxns']:
                               rxn = self.model.reactions_by_id[r_id] # reaction object
                               f.write("{{'id':'{}','name':'{}', 'gpr':'{}', 'ref_bounds':{}, 'overprod_bounds':{}}},\n".format(r_id,rxn.name,rxn.gene_reaction_rule, self.flux_bounds_ref[r_id], self.flux_bounds_overprod[r_id]))
                           f.write(']\n') 
                           f.write('},\n')

                    if found_solns_num_for_interven_num_curr == self.max_alternate_solns_num:
                        self._interven_num_curr += 1
                        found_solns_num_for_interven_num_curr = 0
                        if self._interven_num_curr <= self.max_interven_num:
                            self._best_product_yield_prevIntervenNum = self._best_product_yield_soFar

                            # Reconstruct the optModel again to use the updated value of self._interven_num_curr
                            del self.optModel
                            self.set_model_flux_bounds()
                            self.build_bilevel_optModel()
                            self.fix_known_variables()

                        if self.stdout_msgs and self._interven_num_curr <= self.max_interven_num:
                            print '\nNumber of iterventions increased because the max number of solutions for a given number of interventions (i.e., {}) was reached'.format(self.max_alternate_solns_num)
                            print 'Best product yield achieved with the previous number of interventions = {}'.format(self._best_product_yield_prevIntervenNum)  
                            print '\n-------- # of interventions = {} ----------\n'.format(self._interven_num_curr)


            # If the optimization problem was not solved to optimality 
            else:
                if self.stdout_msgs:
                    print '\n** Iterations with {} interventions stopped because the optimization problem was not solved to optimality (status = {})'.format(self._interven_num_curr, self._curr_soln['exit_flag'])

                # Stop if the target yield has already been achieved
                if self._best_product_yield_soFar >= (self.product_targetYield_percent/100)*self.product_max_theor_yield:
                    done = True
                    if self.stdout_msgs:
                        print 'All iterations stopped because the best product yield achieved so far ({}) satisfies the target product yield ({})'.format(best_product_yield_soFar, (self.product_targetYield_percent/100)*self.product_max_theor_yield)
                else: 
                    self._interven_num_curr += 1
                    found_solns_num_for_interven_num_curr = 0
                    if self._interven_num_curr <= self.max_interven_num:
                        self._best_product_yield_prevIntervenNum = self._best_product_yield_soFar

                        # Reconstruct the optModel again to use the updated value of self._interven_num_curr
                        del self.optModel
                        self.set_model_flux_bounds()
                        self.build_bilevel_optModel()
                        self.fix_known_variables()

                        if self.stdout_msgs and self._interven_num_curr <= self.max_interven_num:
                            print '\n-------- # of interventions = {} ----------\n'.format(self._interven_num_curr)
                            print 'Best product yield achieved with the previous number of interventions = {}'.format(self._best_product_yield_prevIntervenNum)  

            # Stop if the maximum number of interventions has exceeded
            if self._interven_num_curr > self.max_interven_num:
                if self.stdout_msgs and not done:
                    print '\n** All iterations stopped because the maximum number of interventions = {} has been reached\n'.format(self.max_interven_num)
                done = True

        if self.results_filename != '':
            with open(self.results_filename,'a') as f:
                f.write(']\n')

        elapsed_total_pt = str(timedelta(seconds = time.clock() - start_total_pt))
        elapsed_total_wt = str(timedelta(seconds = time.time() - start_total_wt))
        if self.stdout_msgs:
            print '\nFound a total of {} FORCE solutions'.format(found_solutions_num)
            print 'Finding FORCE sets took (hh:mm:ss) a total of {}/{} of processing/walltime\n'.format(elapsed_total_pt, elapsed_total_wt)


    def print_results_summary(self):
        """
        prints a summary of the current results in the output
        """
        print '\nMaxmin product yield = {:0.2f} mol/{} mol of carbon src = {:.2f} g/g of carbon src ({:0.2f}% of theoretical maximum = {:.2f})  , biomass flux = {} ({:.3f}%) of max biomass = {:.2f}), objective func value = {:.2f}'.format(self.optModel.v[self.product_exchrxn_id].value,self.moles_of_carbonSrc_takenup, self.optModel.v[self.product_exchrxn_id].value*self.product_MW/(self.moles_of_carbonSrc_takenup*self.carbonSrc_MW), 100*self.optModel.v[self.product_exchrxn_id].value/self.product_max_theor_yield, self.product_max_theor_yield, self.optModel.v[self.biomass_rxn_id].value, 100*self.optModel.v[self.biomass_rxn_id].value/self.max_biomass_flux, self.max_biomass_flux, self.optModel.objectiveFunc())

        if len(self._curr_soln['X_rxns']) > 0:
             print 'Knockouts = \n{}'.format(self._curr_soln['X_rxns'])
        else:
             print 'Knockouts = \nNone'

        print '\nDown-regulations = '
        if len(self._curr_soln['L_rxns']) > 0:
            for rxn in self._curr_soln['L_rxns']:
                print '{}:\tflux_bounds_ref = {} ,  flux_bounds_overprod = {}'.format(rxn,self.flux_bounds_ref[rxn],self.flux_bounds_overprod[rxn])
        else:
            print 'None'

        print '\nUp-regulations ='
        if len(self._curr_soln['U_rxns']) > 0:
            for rxn in self._curr_soln['U_rxns']:
                print '{}:\tflux_bounds_ref = {} ,  flux_bounds_overprod = {}'.format(rxn,self.flux_bounds_ref[rxn],self.flux_bounds_overprod[rxn])
        else:
            print 'None' 

    def run_primal_dual(self):
        """ 
        Runs primal and dual problems to test if they are equal 
        """
        # Total processing and wall time required to create the pyomo model, solve it and store the results 

        # Set flux bounds for the model
        self.set_model_flux_bounds()

        self.stdout_msgs_details = True
   
        # Create a solver and set the options
        self._optSolver = pyomoSolverCreator(self.optimization_solver)

        print '--------- Primal problem --------'
        start_pyomo_pt = time.clock()
        start_pyomo_wt = time.time()
        self.build_primal_optModel()
        self._elapsed_create_optModel_pt = str(timedelta(seconds = time.clock() - start_pyomo_pt))
        self._elapsed_create_optModel_wt = str(timedelta(seconds = time.time() - start_pyomo_wt))

        # Add any reaction not in fixed_X_rxns, fixed_L_rxns and fixed_U_rxns to ignored_X_rxns, ignored_L_rxns and ignored_U_rxns
        self.ignored_X_rxns += [j for j in self.optModel.J if j not in self.fixed_X_rxns]
        self.ignored_L_rxns += [j for j in self.optModel.J if j not in self.fixed_L_rxns]
        self.ignored_U_rxns += [j for j in self.optModel.J if j not in self.fixed_U_rxns]
        self.ignored_X_rxns = list(set(self.ignored_X_rxns))
        self.ignored_L_rxns = list(set(self.ignored_L_rxns))
        self.ignored_U_rxns = list(set(self.ignored_U_rxns))

        # Fix binary variables
        self.fix_known_variables()

        # Solve the optimizaiton model 
        self.single_run()

        print '--------- Dual problem --------'
        start_pyomo_pt = time.clock()
        start_pyomo_wt = time.time()
        self.build_dual_optModel()
        self._elapsed_create_optModel_pt = str(timedelta(seconds = time.clock() - start_pyomo_pt))
        self._elapsed_create_optModel_wt = str(timedelta(seconds = time.time() - start_pyomo_wt))


        # Add any reaction not in fixed_X_rxns, fixed_L_rxns and fixed_U_rxns to ignored_X_rxns, ignored_L_rxns and ignored_U_rxns
        self.ignored_X_rxns += [j for j in self.optModel.J if j not in self.fixed_X_rxns]
        self.ignored_L_rxns += [j for j in self.optModel.J if j not in self.fixed_L_rxns]
        self.ignored_U_rxns += [j for j in self.optModel.J if j not in self.fixed_U_rxns]
        self.ignored_X_rxns = list(set(self.ignored_X_rxns))
        self.ignored_L_rxns = list(set(self.ignored_L_rxns))
        self.ignored_U_rxns = list(set(self.ignored_U_rxns))

        # Fix binary variables
        self.fix_known_variables()

        # Solve the optimizaiton model 
        self.single_run()

#-------------------------
if __name__ == '__main__':
    pass 
 
