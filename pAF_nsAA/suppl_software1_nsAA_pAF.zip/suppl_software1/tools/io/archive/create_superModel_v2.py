from __future__ import division
import sys, time
from datetime import timedelta  # To convert elapsed time to hh:mm:ss format
sys.path.append('../../')
from tools.userError import *
from tools.core.organism import organism
from tools.core.compartment import compartment
from tools.core.gene import gene
from tools.core.compound import compound
from tools.core.reaction import reaction
from tools.core.model import model
from tools.ancillary.get_ModelSEED_ids import remove_compartment
from models.ModelSEED.ModelSEED_cpds_master import cpds_master as ModelSEED_cpds
from models.ModelSEED.ModelSEED_rxns_master import rxns_master as ModelSEED_rxns
import cobra
from libsbml import readSBML
import re

def create_superModel(original_model, standard_to_model_compartID_map, validate = True,  warnings = True, stdout_msgs = True): 
    """
    INPUTS: 
    ------
    original_model: An instance of object model. The input model should have ModelSEED ids assigned to any 
                    compound or reaction if possible 
    standard_to_model_compartID_map: A dictionary where keys are one of the letters below (standard compartment
                    ids and values are the corresponding compartment ids in the model
                    id in the original model. 
                    c: Cytosol (cytoplasm),   e: Extracellular,   g: Golgi,     m: Mitochondria
                    n: Nucleus,   p: Periplasm,    r: Endoplasmic reticulum,    x: Peroxisome
                    For example, if a model has two compartments c and e, one can provide 
                    {'c':'c id in the model', 'e':'e id in the model'}. One can also provide
                    {'c':'', 'e': ''} in which the code searches for these two compartments 
                    in the model
    original_model: An
          validate: If True, the constructed model undergoes the validation process (this can be very
                    time-consuming take 2-3 h)
 
    OUTPUT:
    -------
      super_model: The integrated model containing both the original model and the compounds and reactions 
                   in the ModelSEED

    Ali R. Zomorrodi - Segre Lab @ BU
    Last updated: 04-08-2016
    """
    start_pt = time.clock()
    start_wt = time.time()

    if not isinstance(original_model,model):
        raise TypeError('Original model must be an instance of class model. An object of type {} was provided instead'.format(type(original_model)))

    if not isinstance(standard_to_model_compartID_map,dict):
        raise TypeError('A dicitonary expected for compart_id but an object of type {} was provided instead'.format(type(compart_id)))
    elif not set(standard_to_model_compartID_map.keys()).issubset(['c','e','g','m','n','p','r','x']):
        raise ValueError('Invalid key for standard_to_model_compartID_map. Eligible keys are: c, e, g, m, n, p, r, x')
    elif len([v for v in standard_to_model_compartID_map.values() if not isinstance(v,str)]) > 0:
        raise TypeError('A string expected for the values of dictionary compart_id but objects of type {} were provided instead'.format(list(set([type(v) for v in standard_to_model_compartID_map.values() if not isinstance(v,str)]))))

    # Reactions for specific types of organisms
    if original_model.organism.ModelSEED_type == '':
        raise userError('ModelSEED_type has not been assigned for the organism object of the original model')
    elif original_model.organism.ModelSEED_type.lower() == 'bacteria_grampositive':
        from models.ModelSEED.ModelSEED_rxns_GramPositive import rxns_GramPositive as organismType_specific_ModelSEED_rxns
    elif original_model.organism.ModelSEED_type.lower() == 'bacteria_gramnegative':
        from models.ModelSEED.ModelSEED_rxns_GramNegative import rxns_GramNegative as organismType_specific_ModelSEED_rxns
    elif original_model.organism.ModelSEED_type.lower() == 'human':
        from models.ModelSEED.ModelSEED_rxns_Human import rxns_Human as organismType_specific_ModelSEED_rxns

    #---- Compartments in the model ----
    # Map from compartment ids in the model to standard ones
    model_to_standard_compartID_map = dict([(standard_to_model_compartID_map[k],k) for k in standard_to_model_compartID_map.keys()])

    # c and e compartments are required
    if len([k for k in standard_to_model_compartID_map.keys() if standard_to_model_compartID_map[k] != '']) > 0:
        for cpt_key in standard_to_model_compartID_map.keys():
            exec cpt_key + "_compart = original_model.compartments_by_id[standard_to_model_compartID_map['" + cpt_key + "']]"

    # If compartment info has been provided do a search
    else:
        for cpt_key in standard_to_model_compartID_map.keys():
            if cpt_key == 'c':
                compart = [cpt for cpt in original_model.compartments if cpt.id in ['c','c0','[c]'] or cpt.name.lower() in ['cytosol','cytoplasm']]
            elif cpt_key == 'e':
                compart = [cpt for cpt in original_model.compartments if cpt.id in ['e','e0','[e]'] or 'extra' in cpt.name.lower()]
            elif cpt_key == 'g':
                compart = [cpt for cpt in original_model.compartments if cpt.id in ['g','g0','[g]'] or 'golgi' in cpt.name.lower()]
            elif cpt_key == 'm':
                compart = [cpt for cpt in original_model.compartments if cpt.id in ['m','m0','[m]'] or cpt.name.lower() == 'mitochondria']
            elif cpt_key == 'n':
                compart = [cpt for cpt in original_model.compartments if cpt.id in ['n','n0','[n]'] or cpt.name.lower() == 'nucleus']
            elif cpt_key == 'p':
                compart = [cpt for cpt in original_model.compartments if cpt.id in ['p','p0','[p]'] or cpt.name.lower() == 'periplasm']
            elif cpt_key == 'r':
                compart = [cpt for cpt in original_model.compartments if cpt.id in ['r','r0','[r]'] or 'endoplasmic' in cpt.name.lower() or 'reticulum' in cpt.name.lower()]
            elif cpt_key == 'x':
                compart = [cpt for cpt in original_model.compartments if cpt.id in ['x','x0','[x]'] or cpt.name.lower() == 'peroxisome' ]
            else:
                raise userError('No compartment was found for {} in the model'.format(cpt_key))

            if len(compart) == 1:
                exec cpt_key + '_compart = compart[0]'
            elif len(compart) > 0:
                raise userError('More than one compartment was found for {} in the model : {}'.format(cpt_key, [cpt.id for cpt in c_compart]))

    #------ Reset model-related attributes of reactions and compartments -----
    # First reset the properties of all compounds and reactions related to the model they belong to 
    # Also assign a new attribute external to each comound and reaction showing if it is an external 
    # reaciton (True) or not (False)
    for cpd in original_model.compounds:
        cpd.reset_props()
        cpd.external = False
    for rxn in original_model.reactions:
        rxn.reset_props()
        rxn.external = False        
    for cpt in original_model.compartments:
        cpt.model = None
    original_model.organism.model = None

    # ModelSEED if of compounds and reactions in the model with a unique ModelSEED id
    orig_model_cpds_ModelSEED_ids = []
    orig_model_rxns_ModelSEED_ids = [mid for r in original_model.reactions if len(r.ModelSEED_id) > 1 for mid in r.ModelSEED_id]

    # List of compounds and reactions in the super model
    organism = original_model.organism
    cpds_superModel = [] 
    rxns_superModel = []

    # Access reactions in the super_model by id. For compounds or reactions int he model, this id is the
    # ModelSEED id if that reaction or cmpound has at least one ModelSEED id. Otherwise, it is its id in the
    # original model. For compounds or reactions with more than one ModelSEED id we consider the first in the 
    # list assuming that these are equivalent due to having the same name, forumula, stoichioemtry, etc
    cpds_superModel_by_id = {}
    rxns_superModel_by_id = {}

    for cpd in original_model.compounds:
        cpds_superModel.append(cpd)
        if len(cpd.ModelSEED_id) > 1:
            if cpd.compartment == c_compart:
                cpds_superModel_by_id[cpd.ModelSEED_id[0] + '_c0'] = cpd
                orig_model_cpds_ModelSEED_ids.append(cpd.ModelSEED_id[0] + '_c0')
            elif cpd.compartment == e_compart:
                cpds_superModel_by_id[cpd.ModelSEED_id[0] + '_e0'] = cpd
                orig_model_cpds_ModelSEED_ids.append(cpd.ModelSEED_id[0] + '_e0')
            else:
                cpds_superModel_by_id[cpd.ModelSEED_id[0] + '_' + model_to_standard_compartID_map[cpd.compartment.id] + '0'] = cpd
                orig_model_cpds_ModelSEED_ids.append(cpd.ModelSEED_id[0] + '_' + model_to_standard_compartID_map[cpd.compartment.id] + '0')
        else:
            cpds_superModel_by_id[cpd.id] = cpd
            orig_model_cpds_ModelSEED_ids.append(cpd.id)

    for rxn in original_model.reactions:
        rxn.base_cost = 0
        if len(rxn.ModelSEED_id) > 1 and rxn.reversibility != 'exchange' and rxn.ModelSEED_id[0] in organismType_specific_ModelSEED_rxns.keys():
            rxn.forward_cost = organismType_specific_ModelSEED_rxns[rxn.ModelSEED_id[0]]['forward_cost']
            rxn.backward_cost = organismType_specific_ModelSEED_rxns[rxn.ModelSEED_id[0]]['backward_cost']
            rxn.probability_dG_lessThanZero = ModelSEED_rxns[rxn.ModelSEED_id[0]]['probability_dG_lessThanZero']
            rxns_superModel_by_id[rxn.ModelSEED_id[0]] = rxn
        else:
            # Reaction is reversible in the original model
            if rxn.reversibility == 'reversible':
                rxn.forward_cost = 0 
                rxn.backward_cost = 0
            # Reaction is irreversible (forward) in the original model
            if rxn.reversibility == 'irreversible':
                rxn.forward_cost = 0 
                rxn.backward_cost = 5 
            else: # Exchange reactions
                rxn.forward_cost = 0 
                rxn.backward_cost = 0 
            rxn.probability_dG_lessThanZero = None
            rxns_superModel_by_id[rxn.id] = rxn
        rxns_superModel.append(rxn)

    #-------- Modifications from the original model
    # All transport reactions in the ModelSEED database
    ModelSEED_transport_rxns = [r for r in ModelSEED_rxns if ModelSEED_rxns[r]['is_transport']]

    # For any compound in the cytosol for which there is not any corresponding compound in the e compaortment,
    # add a new compound in the [e] compartment along with transport and exchange reactions for that
    for no_e_cpd in [cpd_c for cpd_c in original_model.compounds if cpd_c.compartment == c_compart and len([cpd_e for cpd_e in original_model.compounds if cpd_e.compartment == e_compart and cpd_e.name == cpd_c.name]) == 0]:

        # Id with compartment name removed
        no_cpt_id = remove_compartment(input_string = no_e_cpd.id, compartments_info = [standard_to_model_compartID_map['c']])

        # Create a new compound in the [e] compartment
        cpd_e = compound(id = no_cpt_id + standard_to_model_compartID_map['e'], compartment = e_compart, name = no_e_cpd.name, name_aliases = no_e_cpd.name_aliases, KEGG_id = no_e_cpd.KEGG_id, ModelSEED_id = no_e_cpd.ModelSEED_id, BiGG_id = no_e_cpd.BiGG_id, formula = no_e_cpd.formula, deltaG = no_e_cpd.deltaG, deltaG_uncertainty = no_e_cpd.deltaG_uncertainty)

        cpd_e.external = True
        cpd_e.external_type = 'e compound original model'

        cpds_superModel.append(cpd_e)
        if len(cpd_e.ModelSEED_id) == 1:
            cpds_superModel_by_id[cpd_e.ModelSEED_id[0] + '_e0'] = cpd_e
        else:
            cpds_superModel_by_id[cpd_e.id] = cpd_e

        # Create an exchange reactions
        exch_rxn = reaction(id = 'EX_' + no_cpt_id + '_e0', stoichiometry = {cpd_e:-1}, reversibility = 'exchange', name = no_cpt_id + ' exchange', KEGG_id = [], ModelSEED_id = [], BiGG_id = [])
        exch_rxn.base_cost = 0
        exch_rxn.forward_cost = 0 
        exch_rxn.backward_cost = 0 
        exch_rxn.probability_dG_lessThanZero = None

        exch_rxn.external = True 
        exch_rxn.external_type = 'exchange'

        rxns_superModel.append(exch_rxn)
        rxns_superModel_by_id[exch_rxn.id] = exch_rxn
 
        # Add a transport reaciton only if there is no  transport reaction between [c] and [e] compartments 
        # in the ModelSEED
        if not (len(no_e_cpd.ModelSEED_id) == 1 and len([r for r in ModelSEED_transport_rxns if (no_e_cpd.ModelSEED_id[0],'c0') in ModelSEED_rxns[r]['stoichiometry'] and (no_e_cpd.ModelSEED_id[0],'e0') in ModelSEED_rxns[r]['stoichiometry']]) > 0):
            transport_rxn = reaction(id = no_cpt_id + '_transport', stoichiometry = {no_e_cpd:-1, cpd_e:1}, reversibility = 'reversible', name = no_e_cpd.name + ' transport', compartment = [c_compart, c_compart])

            transport_rxn.base_cost = 0 
            transport_rxn.forward_cost = 0 
            transport_rxn.backward_cost = 0 
            transport_rxn.probability_dG_lessThanZero = None

            transport_rxn.external = True 
            transport_rxn.external_type = 'transport'

            rxns_superModel.append(transport_rxn)
            rxns_superModel_by_id[transport_rxn.id] = transport_rxn

    #--- ModelSEED compounds ---
    # Exchange reactions in the ModelSEED
    ModelSEED_exchrxns = [r for r in ModelSEED_rxns if 'exchange' in ModelSEED_rxns[r]['name'].lower() or len([n for n in ModelSEED_rxns[r]['name_aliases'] if 'exchange' in n]) > 0 or (ModelSEED_rxns[r]['BiGG_id'] != None and  'EX_' in ModelSEED_rxns[r]['BiGG_id'])]

    # List of compounds in the ModelSEED participating in the ModelSEED reactions
    # ** Consider only those in c0 and e0 compartments **
    cpds_in_ModelSEED_rxns = list(set([(cpd,cpt) for r in ModelSEED_rxns.keys() if ModelSEED_rxns[r]['stoichiometry'] != None and r not in ModelSEED_exchrxns + orig_model_rxns_ModelSEED_ids and 'a0' not in [cpd_cpt[1] for cpd_cpt in ModelSEED_rxns[r]['stoichiometry'].keys()] for (cpd,cpt) in ModelSEED_rxns[r]['stoichiometry'].keys() if cpt in ['c0','e0']]))

    # Compounds in the ModelSEED except those in the original model. Also excludes compounds that do not participate
    # in any ModelSEED reactions
    for (cid,cpt) in [(c,ct) for (c,ct) in cpds_in_ModelSEED_rxns if c + '_' + ct not in orig_model_cpds_ModelSEED_ids]:
        if cpt == 'c0':
           compart = c_compart
        elif cpt == 'e0':
            compart = e_compart
        else:
            raise userError('Unknonw compartment: {} for compound {}'.format(cpt,cid))

        ModelSEED_cpd = compound(id = cid + '_' + cpt, compartment = compart, name = ModelSEED_cpds[cid]['name'], name_aliases = ModelSEED_cpds[cid]['name_aliases'], KEGG_id = ModelSEED_cpds[cid]['KEGG_id'], ModelSEED_id = cid, BiGG_id = ModelSEED_cpds[cid]['BiGG_id'], formula = ModelSEED_cpds[cid]['formula'], deltaG = ModelSEED_cpds[cid]['deltaG'], deltaG_uncertainty = ModelSEED_cpds[cid]['deltaG_uncertainty'])

        ModelSEED_cpd.external = True
        ModelSEED_cpd.external_type = 'ModelSEED compound'

        cpds_superModel.append(ModelSEED_cpd)
        cpds_superModel_by_id[ModelSEED_cpd.id] = ModelSEED_cpd

    #--- ModelSEED reactions ---
    # Maximum cost of reactions whose template_rxn_type is NOT conditional
    max_cost_nonCond = max([organismType_specific_ModelSEED_rxns[rid]['base_cost'] + max(organismType_specific_ModelSEED_rxns[rid]['forward_cost'], organismType_specific_ModelSEED_rxns[rid]['backward_cost']) for rid in organismType_specific_ModelSEED_rxns.keys() if organismType_specific_ModelSEED_rxns[rid]['template_rxn_type'] != 'conditional']) 

    # Maximum cost of reactions whose template_rxn_type is conditional
    max_cost_cond = max([organismType_specific_ModelSEED_rxns[rid]['base_cost'] + max(organismType_specific_ModelSEED_rxns[rid]['forward_cost'], organismType_specific_ModelSEED_rxns[rid]['backward_cost']) for rid in organismType_specific_ModelSEED_rxns.keys() if organismType_specific_ModelSEED_rxns[rid]['template_rxn_type'] == 'conditional']) 

    counter = 0

    if stdout_msgs:
        print 'create_superModel: Started reading reactions ...',

    # Do not consider reactions in the original model and those having a compartment 'a0', which is related to 
    # template Human (the only compartments appearing in gram positive/negative are c0 and e0)
    for rid in [r for r in ModelSEED_rxns.keys() if ModelSEED_rxns[r]['stoichiometry'] != None and r not in ModelSEED_exchrxns + orig_model_rxns_ModelSEED_ids and 'a0' not in [cpd_cpt[1] for cpd_cpt in ModelSEED_rxns[r]['stoichiometry'].keys()] and r not in ModelSEED_exchrxns]:
        counter += 1
        if stdout_msgs: 
            if counter/5000 == int(counter/5000):
                print '{} '.format(counter),
            sys.stdout.flush()

        # Reaction stoichiometry and compartments
        r_stoic = {}
        r_compart = []
        for (cpd,cpt) in ModelSEED_rxns[rid]['stoichiometry'].keys():
            r_stoic[cpds_superModel_by_id[cpd + '_' + cpt]] = ModelSEED_rxns[rid]['stoichiometry'][(cpd,cpt)]
            if cpt == 'c0':
                r_compart.append(c_compart)
            elif cpt == 'e0':
                r_compart.append(e_compart)
            else:
                raise userError('Unknown compartment: {} for compound {} in reaction {}'.format(cpt,cpd, rid))

        # Reversibility
        if rid in organismType_specific_ModelSEED_rxns and organismType_specific_ModelSEED_rxns[rid]['reversibility_ModelSEED_curated_template'].lower() != 'unknown':
            r_rev = organismType_specific_ModelSEED_rxns[rid]['reversibility_ModelSEED_curated_template'] 
        else:
            r_rev = ModelSEED_rxns[rid]['reversibility_ModelSEED_curated_master']

        # Reaction compartments
        ModelSEED_rxn = reaction(id = rid, stoichiometry = r_stoic, reversibility = r_rev, name = ModelSEED_rxns[rid]['name'], name_aliases = [], KEGG_id = ModelSEED_rxns[rid]['KEGG_id'], ModelSEED_id = rid, BiGG_id = ModelSEED_rxns[rid]['BiGG_id'], EC_numbers = [], subsystem = '', pathways = [], compartment = r_compart, genes = [], gene_reaction_rule = '', deltaG = ModelSEED_rxns[rid]['deltaG_ModelSEED'], deltaG_uncertainty = ModelSEED_rxns[rid]['deltaG_uncertainty_ModelSEED'], deltaG_range = [ModelSEED_rxns[rid]['deltaG_min_ModelSEED'],ModelSEED_rxns[rid]['deltaG_max_ModelSEED']])

        ModelSEED_rxn.external = True
      
        # If an organism-type specific reaction 
        if rid in organismType_specific_ModelSEED_rxns.keys():
            ModelSEED_rxn.external_type = 'ModelSEED template rxn'
 
            # Base cost of adding this reaction
            if organismType_specific_ModelSEED_rxns[rid]['template_rxn_type'] != 'conditional':
                ModelSEED_rxn.base_cost = organismType_specific_ModelSEED_rxns[rid]['base_cost'] 
            else:
                # Add max + 1 to the base_cost of conditional reactions. This is to make sure that the cost of adding 
                # non-conditoinal reactions is lower than those of conditional ones
                ModelSEED_rxn.base_cost = organismType_specific_ModelSEED_rxns[rid]['base_cost'] + (max_cost_nonCond + 1) 

            # forward and backward costs of adding this reaction
            ModelSEED_rxn.forward_cost = organismType_specific_ModelSEED_rxns[rid]['forward_cost'] 
            ModelSEED_rxn.backward_cost = organismType_specific_ModelSEED_rxns[rid]['backward_cost'] 

            # template reaction type
            ModelSEED_rxn.template_rxn_type = organismType_specific_ModelSEED_rxns[rid]['template_rxn_type'] 

        else: 
            ModelSEED_rxn.external_type = 'ModelSEED non-template rxn'
 
            # The cost of adding reactions not in the template should be higher than the maximum cost of condiitonal
            # reactions in the template
            ModelSEED_rxn.base_cost = max_cost_cond + (max_cost_nonCond + 1) + 1

            # forward and backward costs are not defined for reactions not in the template, i.e., for these reactions
            # we cosider only the cost of adding them to the model in the direction specified by reversiblity 
            ModelSEED_rxn.forward_cost = None 
            ModelSEED_rxn.backward_cost = None 
        
        ModelSEED_rxn.probability_dG_lessThanZero = ModelSEED_rxns[rid]['probability_dG_lessThanZero'] 
        rxns_superModel.append(ModelSEED_rxn)
        rxns_superModel_by_id[ModelSEED_rxn.id] = ModelSEED_rxn

    if stdout_msgs:
        print '{}\n'.format(counter)
        sys.stdout.flush()

    #---------- Create the model -----------
    super_model =  model(id = 'super_model', type = 'metabolic', organism = original_model.organism, reactions = rxns_superModel, compounds = cpds_superModel, compartments = [cpt for cpt in original_model.compartments], validate = validate, warnings = warnings, stdout_msgs = stdout_msgs)

    elapsed_pt = str(timedelta(seconds = time.clock() - start_pt))
    elapsed_wt = str(timedelta(seconds = time.time() - start_wt))
    if stdout_msgs:
        print 'superModel: Super model was created. It took {}/{} of professing/wall time '.format(elapsed_pt,elapsed_wt)

    return super_model


