from __future__ import division
import sys
sys.path.append('../../')
from tools.userError import *
from tools.core.metabolite import metabolite
from tools.core.reaction import reaction
from tools.core.organism import organism
from tools.core.model import model
from models import *
from imp import load_source

def read_gams_model(gams_model_file,model_name,organism_name, model_type): 
    """
    A class to read a gams model in python-formatted data
    and to convert it into a format we need. 
        

    INPUTS: 
    ------
    gams_model_file: THe name of the python module (file) containing the model 
                     data extracted from a gams model. This string can contain 
                     the full path to the file
         model_name: Name of the model (string) 
      organism_name: Name of the organism (string)
         model_type: Type of the model (string, e.g., 'metabolic')

    OUTPUT:
               model: A model object

    Ali R. Zomorrodi - Segre Lab @ BU
    Last updated: 12-17-2014
    """

    # Import the data in module stored in gams_model_file
    if type(gams_model_file) == str:
        load_source('gams_model',gams_model_file)
    import gams_model

    # organism
    org = organism(id = organism_name)

    # Metabolites
    get_metab_by_id = []
    metabolites = []
    for metab_id in sorted(gams_model.metab_names):
        m = metabolite(id = metab_id)
        metabolites += [m]
        get_metab_by_id += [(metab_id,m)]

    get_metab_by_id = dict(get_metab_by_id)

    # reactions
    stoic_keys = gams_model.stoic_matrix.keys() # keys of the stoichiomteric matrix
    get_rxn_by_id = []
    reactions = []
    for rxn_id in sorted(gams_model.rxn_names):
        stoichiometry = []

        # Reaction type
        if gams_model.rxn_types[rxn_id] == 0:
            reaction_type = 'irreversible'
        elif gams_model.rxn_types[rxn_id] == 1 and 2 not in gams_model.rxn_types.values():
            reaction_type = 'reversible'
        elif gams_model.rxn_types[rxn_id] == 1 and 2 in gams_model.rxn_types.values():
            reaction_type = 'reversible_forward'
        elif gams_model.rxn_types[rxn_id] == 2: 
            reaction_type = 'reversible_backward'
        elif gams_model.rxn_types[rxn_id] == 3 and 4 not in gams_model.rxn_types.values():
            reaction_type = 'exchange'
        elif gams_model.rxn_types[rxn_id] == 3 and 4 in gams_model.rxn_types.values():
            reaction_type = 'exchange_forward'
        elif gams_model.rxn_types[rxn_id] == 4:
            reaction_type = 'exchange_backward'


        # Reaction stoichiometry
        for m_id in [m[0] for m in stoic_keys if m[1] == rxn_id]:
            stoichiometry.append((get_metab_by_id[m_id],gams_model.stoic_matrix[(m_id,rxn_id)]))   

        if len(stoichiometry) == 0:
            raise userError("**Error! The field 'stoichiometry' was not assigned for reaction " + str(rxn_id))

        reactions.append(reaction(id = rxn_id, stoichiometry = dict(stoichiometry), type = reaction_type))
 
    # biomass reaction
    biomass_reaction = [r for r in reactions for b in gams_model.biomass_rxn_names if r.id == b]
    if len(biomass_reaction) == 0:
        print 'WARNING! No biomass reactions found. Check the model manually\n'
        biomass_reaction = None
    elif len(biomass_reaction) > 1:
        print 'WARNING! More than one biomass reactions found: ',[r.id for r in biomass_reaction],'\n'

    # model
    return model(id = model_name, type = model_type, organism = org, reactions = reactions, metabolites = metabolites, biomass_reaction = biomass_reaction)

#------------ Sample run -------------
if __name__ == "__main__":
    testModel = read_gams_model(gams_model_file = '/fs/home06/alizom//models/test/testModelData.py',model_name = 'testModel',organism_name = 'testOrg',model_type = 'metabolic')
    print '# of reactions = ',len(testModel.reactions)
    print '# of metabolites = ',len(testModel.metabolites)
    
    testModel.get_reactions_by('equation') 
    print '\n'
    for rxn in testModel.reactions: 
        print rxn.id,'  ',rxn.type,'  ',rxn.flux_bounds
