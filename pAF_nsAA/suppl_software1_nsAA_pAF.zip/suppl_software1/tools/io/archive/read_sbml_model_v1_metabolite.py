from __future__ import division
import sys
sys.path.append('../../')
from tools.userError import *
from tools.core.organism import organism
from tools.core.compartment import compartment
from tools.core.gene import gene
from tools.core.metabolite import metabolite
from tools.core.reaction import reaction
from tools.core.model import model
import cobra

def read_sbml_model(file_name,model_name,model_organism, model_type,import_bounds = False): 
    """
    A class to read a sbml model into a model object. The sbml model is 
    first converted into a COBRApy model, which is used as an input to create
    the corresponding model object. 

    INPUTS: 
    ------
    file_name: The name of the sbml file containing the model (String)
                     This string can contain the full path to the file  
         model_name: Name of the model (string) 
     model_organism: Can be either a string containing the name of the organism or it can be 
                     an instance of the object organism
         model_type: Type of the model (string, e.g., 'metabolic')
      import_bounds: Indicates whether the flux bounds should be imported from
                     the sbml file (True) or not (False). The default is zero

    OUTPUT:
               model: A model object

    Ali R. Zomorrodi - Segre Lab @ BU
    Last updated: 03-12-2015
    """

    # Import the COBRApy model
    cobra_model = cobra.io.read_sbml_model(file_name) 

    cobra_model.optimize()
    for rxn in [r for r in cobra_model.reactions if len(r.metabolites) == 0]:
        print rxn.id,' in the original sbml file has no associated metabolites: ',rxn.reaction

    # organism
    if type(model_organism) is str:             # If name is provided
        model_organism = organism(id = model_organism)
    elif type(model_organism) is not organism:  # if an object of type organism is not provided
        raise userError('Model_organism must be either a string containing the name (id) of the organism or an instance of the class "organism"')

    # compartments
    compartments = []
    compartments_by_id = []
    for compartment_id in sorted(cobra_model.compartments.keys()):
        comp = compartment(id = compartment_id, name = cobra_model.compartments[compartment_id])
        compartments.append(comp)
        compartments_by_id.append((compartment_id,comp))
    compartments_by_id = dict(compartments_by_id)

    # genes
    genes = []
    genes_by_id = []
    for gene_cobra in sorted(cobra_model.genes,key=lambda x:x.id):
        g = gene(id = gene_cobra.id, name = gene_cobra.name, notes = gene_cobra.notes)
        genes.append(g)
        genes_by_id.append((gene_cobra.id,g))
    genes_by_id = dict(genes_by_id)

    # Metabolites. Note that the field 'reactions' for each metabolite is added
    # after constructing the reaction objects
    metabolites = []
    metabolites_by_id = []
    for metab in sorted(cobra_model.metabolites, key = lambda x:x.id):
        m = metabolite(id = metab.id, compartment = compartments_by_id[metab.compartment], name = metab.name, formula = metab.formula, charge = metab.charge, notes = metab.notes)
        metabolites.append(m)
        metabolites_by_id.append((metab.id,m))
    metabolites_by_id = dict(metabolites_by_id)

    # reactions
    reactions = []
    for rxn in sorted(cobra_model.reactions, key = lambda x:x.id):
        # Reaction type
        if rxn.id.find('EX_') == 0:
            rxn_type = 'exchange'
        elif rxn.reversibility == False: 
            rxn_type = 'irreversible'
        elif rxn.reversibility == True: 
            rxn_type = 'reversible'

        # Reaction stoichiometry
        stoichiometry = []
        for metab in rxn.metabolites: 
            stoichiometry.append((metabolites_by_id[metab.id],rxn.get_coefficient(metab)))   

        if len(stoichiometry) == 0:
            print "**WARNING! The field 'stoichiometry' was not assigned for reaction " + rxn.id

        # List of compartments for the reaction
        r_comps = []
        for comp_id in rxn.get_compartments():
            r_comps.append(compartments_by_id[comp_id])

        # Genes for this reaction 
        rxn_genes = []
        for cobra_gene in rxn.genes:
            rxn_genes.append(genes_by_id[cobra_gene.id])

        if import_bounds == True:
            r = reaction(id = rxn.id, stoichiometry = dict(stoichiometry), type = rxn_type, name = rxn.name, subsystem =rxn.subsystem, compartments = r_comps, genes = rxn_genes, gene_reaction_rule = rxn.gene_reaction_rule, flux_bounds = [rxn.lower_bound,rxn.upper_bound])
        elif import_bounds == False:
            r = reaction(id = rxn.id, stoichiometry = dict(stoichiometry), type = rxn_type, name = rxn.name, subsystem =rxn.subsystem, compartments = r_comps, genes = rxn.genes, gene_reaction_rule = rxn.gene_reaction_rule, notes = rxn.notes)
        else:
            raise userError('import_bounds should be either True or False!') 

        reactions.append(r)

    # Now add the field 'reactions' for each metabolite 
    for metab in metabolites:
        metab.reactions = [r for r in reactions if metab in r.stoichiometry.keys()]        
        metab.reactant_reactions = [r for r in metab.reactions if r.stoichiometry[metab] < 0]        
        metab.product_reactions = [r for r in metab.reactions if r.stoichiometry[metab] > 0]        

    # biomass reactions
    biomass_reaction = [r for r in reactions if r.id.lower().find('biomass') >= 0 or r.name.lower().find('biomass') >= 0 or r.id.lower().find('grow') >= 0 or r.name.lower().find('grow') >= 0]
    if len(biomass_reaction) == 0:
        print 'WARNING! No biomass reactions detected. Check the model manually\n'
        biomass_reaction = None
    elif len(biomass_reaction) > 1:
        print '\nMore than one biomass reactions detected: ',[r.id for r in biomass_reaction],'\nPlease choose one manually.\n'
    elif len(biomass_reaction) == 1:
        biomass_reaction = biomass_reaction[0]
        print '\nA biomass reactions detected: ',biomass_reaction.id,'\n'

    # ATP maintenance reaction 
    atpm_reaction = [r for r in reactions if r.id.lower().find('atpm') >= 0 or (r.name.lower().find('atp') >= 0 and r.name.lower().find('maintenance') >= 0) or r.name.lower().find('ngam') >= 0]
    if len(atpm_reaction) == 0:
        print 'WARNING! No NGAM  reaction found. Check the model manually\n'
        atpm_reaction = None
    elif len(atpm_reaction) > 1:
        print 'WARNING! More than one NGAM reactions found: ',[r.id for r in atpm_reaction],'\n'
    elif len(atpm_reaction) == 1:
        atpm_reaction = atpm_reaction[0] 

    # model
    return model(id = model_name, type = model_type, organism = model_organism, reactions = reactions, metabolites = metabolites, genes = genes, compartments = compartments, biomass_reaction = biomass_reaction,atpm_reaction = atpm_reaction)

#------------ Sample run -------------
if __name__ == "__main__":
    from cobra import test
    #model = read_sbml_model(file_name = test.salmonella_sbml,model_name = 'salmonella',organism_name = 'salmonella', model_type = 'metabolic',import_bounds = True)
    model = read_sbml_model(file_name = '/fs/home06/alizom/models/Pfluorescens/iSB1139/iSB1139_cobra.xml',model_name = 'Pf',organism_name = 'Pf', model_type = 'metabolic')
    print '# of reactions = ',len(model.reactions) 
    print '# of metabolites = ',len(model.metabolites) 
    print '# of genes = ',len(model.genes) 
