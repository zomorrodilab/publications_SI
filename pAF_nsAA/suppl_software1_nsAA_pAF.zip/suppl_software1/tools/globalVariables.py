# Home directory
home_dir = '/usr2/postdoc/alizom/'

# Directory for storing codes outputs
projectnb_home_dir = '/projectnb/bioinfor/SEGRE/alizom_projects/'

# Default optimization solver
#default_optim_solver = 'cplex'
default_optim_solver = 'gurobi'

# mip integrality tolerence
mip_integrality_tol = 1e-9

# Directory to store temporary files for pyomo
#pyomo_tmp_dir = /tmp
pyomo_tmp_dir = '/projectnb/bioinfor/SEGRE/tmp'
