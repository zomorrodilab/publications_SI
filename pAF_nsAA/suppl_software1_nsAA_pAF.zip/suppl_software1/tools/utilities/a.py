from __future__ import division
import sys, time
sys.path.append('../../')
from tools.userError import userError
from tools.core.compound import compound
from tools.core.reaction import reaction
from tools.core.model import model
from get_ModelSEED_ids import get_ModelSEED_ids, remove_compartment
from remove_non_alphanumeric import remove_non_alphanumeric

#--------------------------------------
# Ali R. Zomorrodi - Segre lab @ BU
# Last updated: 04-28-2016
#--------------------------------------

#--------------------------------------
#--------- Ancillary functions --------
#--------------------------------------
def create_ModelSEEDID_map(obj_list):
    """ 
    Creates a dictionary mapping the ModelSEED ids for componds or reactions to objects of
    type compound or reaction in a list. This is applied to objects with a ModelSEED id 

    INPUTS:
    -------
    obj_list: A list of objects of type compounds or reactions

    OUTPUTS:
    -------
    ModelSEED_id_map: A dictionary where keys are ModelSEED ids and values are 
                      objects of type compounds or reactions   
    """ 
    ModelSEED_id_map = {}
    for obj in [o for o in obj_list if o.ModelSEED_id != []]:
        for sid in obj.ModelSEED_id:
            if sid in ModelSEED_id_map.keys():
                ModelSEED_id_map[sid] += [obj]
            else:
                ModelSEED_id_map[sid] = [obj]
    return  ModelSEED_id_map

def create_KEGGID_map(obj_list):
    """ 
    Creates a dictionary mapping the KEGG ids for componds or reactions to objects of
    type compound or reaction in a list. This is applied to objects with a KEGG id 

    INPUTS:
    -------
    obj_list: A list of objects of type compound or reaction

    OUTPUTS:
    -------
    KEGG_id_map: A dictionary where keys are KEGG ids and values are 
                 objects of type compound or reaction   
    """ 
    KEGG_id_map = {}
    for obj in [o for o in obj_list if o.KEGG_id != []]:
        for kid in obj.KEGG_id:
            if kid in KEGG_id_map.keys():
                KEGG_id_map[kid] += [obj]
            else:
                KEGG_id_map[kid] = [obj]
    return KEGG_id_map

def create_BiGGID_map(obj_list):
    """ 
    Creates a dictionary mapping the BiGG ids for componds or reactions to objects of
    type compound or reaction in a list. This is applied to objects with a BiGG id 

    INPUTS:
    -------
    obj_list: A list of objects of type compounds or reactions

    OUTPUTS:
    -------
    BiGG_id_map: A dictionary where keys are BiGG ids and values are 
                      objects of type compounds or reactions   
    """ 
    BiGG_id_map = {}
    for obj in [o for o in obj_list if o.BiGG_id != []]:
        for bid in obj.BiGG_id:
            if bid in BiGG_id_map.keys():
                BiGG_id_map[bid] += [obj]
            else:
                BiGG_id_map[bid] = [obj]
    return  BiGG_id_map

def create_cleanNames_map(obj_list,compart_list):
    """ 
    Creates a dictionary mapping the non-alphanumeric names of componds or reactions to 
    objects of type compound or reaction in a list

    INPUTS:
    -------
        obj_list: A list of objects of type compound or reaction
    compart_list: A list of strings containing the ids of compartments for obj_list 

    OUTPUTS:
    -------
    clean_names_map: A dictionary where keys are non-alphanumeric names and values are 
    """ 
    clean_names_map = {}
    for obj in obj_list:
        for name in [obj.name] + obj.name_aliases:
            clean_name = remove_non_alphanumeric(remove_compartment(name,compartments_info = compart_list)).lower()
            if clean_name in clean_names_map.keys():
                clean_names_map[clean_name] += [obj]
            else:
                clean_names_map[clean_name] = [obj]
    # Names of objects in model2 where all non-alpahnumeric characters are removed 
    return clean_names_map

def create_cpd_formulas_map(cpd_list):
    """ 
    Create a dictionary mapping the non-alphanumeric formula of the compounds to  
    compound objects in a given list of compounds. This is applied only to objects
    with a given formula

    INPUTS:
    -------
    cpd_list: A list of objects of type compound

    OUTPUTS:
    -------
    clean_formulas_map: A dictionary where keys are non-alphanumeric names and values are 
    """ 
    formulas_map = {}
    for cpd in [c for c in cpd_list if c.formula != None]:
        if cpd.formula in formulas_map.keys():
            formulas_map[cpd.formula)] += [cpd]
        else:
            formulas_map[cpd.formula] = [cpd]
    return formulas_map

#--------------------------------------
#--------- Main functions --------
#--------------------------------------
def compare_compounds(cpds_list1,cpds_list2, standard_to_cpds_list1_cpt_ids_map, standard_to_cpds_list2_cpt_ids_map, cpds_list1_id = None, cpds_list2_id = None, warnings = True, stdout_msgs = True):
    """
    Find common compounds in two given list of compounds

    INPUTS:
    -------
                cpds_list1: An instance of object compound or a list of such objects
                cpds_list2: An instance of object compound or a list of such objects
             cpds_list1_id: An id for cpds_list1. This is requried if not all compounds in 
                            cpds_list1 belong to the same model or if no model is assigned 
                            to all reactions of list 1
             cpds_list2_id: An id for cpds_list2. This is requried if not all compounds in 
                            cpds_list1 belong to the same model or if no model is assigned 
                            to all reactions of list 2
    standard_to_cpds_list1_cpt_ids_map:
    standard_to_cpds_list2_cpt_ids_map: 
                            A dictionary where keys are standard compartment ids as follows:
                            c: Cytosol (cytoplasm),   e: Extracellular,   g: Golgi,     m: Mitochondria
                            n: Nucleus,   p: Periplasm,    r: Endoplasmic reticulum,    x: Peroxisome
                            and values are corresponding compartment ids in cpds_list1 and cpds_list2

    OUTPUTS:
    --------
    cpd1_to_cpd2_map: A dictionary where the keys are the compounds objects from cpds_list1 and values 
                      are a list of compound objects corresponding to this compound from cpds_list2 
    cpd2_to_cpd1_map: A dictionary where the keys are the compounds objects from cpds_list2 and values 
                      are a list of compound objects corresponding to this compound from cpds_list1 
    cpd1_to_cpd2_noCopart_map:
    cpd2_to_cpd1_noCopart_map:
                      Same as cpd1_to_cpd2_map and cpd2_to_cpd1_map except that the mataches here are found
                      without considering the compartments
    cpd1_to_cpd2_match_found_by:
    cpd2_to_cpd1_match_found_by:
                      A dictionary with keys being ids of compounds in cpds_list1 or cpds_list2 and values being a 
                      string showing how the matches in cpd1_to_cpd2_map and cpd2_to_cpd1_map were found 
    cpd1_to_cpd2_noCompart_match_found_by:
    cpd2_to_cpd1_noCompart_match_found_by:
                      Same cpd1_to_cpd2_match_found_by and cpd2_to_cpd1_match_found_by for cpd1_to_cpd2_noCopart_map 
                      and cpd2_to_cpd1_noCopart_map
    """
    if not isinstance(strdout_msgs,bool):
        raise TypeError('stdout_msgs must be True or False')
    if not isinstance(warnings,bool):
        raise TypeError('warnings must be True or False')

    if cpds_list1_id == None:
        model1_id = list(set([c.model.id for c in cpds_list1 if 'model' in dir(c)]))
        if len(model1_id) == 1:
            cpds_list1_id = model1_id[0]
        else:
            raise userError('cpds_list1_id is needed because not all compounds in cpds_list1 have the same model id (' + str(model1_id) + ')')

    if cpds_list2_id == None:
        model2_id = list(set([c.model.id for c in cpds_list2 if 'model' in dir(c)]))
        if len(model2_id) == 1:
            cpds_list2_id = model2_id[0]
        else:
            raise userError('cpds_list2_id is needed because not all compounds in cpds_list2 have the same model id (' + str(model2_id) + ')')

    # Dictionaries where keys are compartment ids in cpds_list1 and cpds_list2 and values are corresponding standard 
    # comaprtment ids
    cpds_list1_cpt_ids_to_standard_map = {}
    cpds_list2_cpt_ids_to_standard_map = {}
    for cpt_id in standard_to_cpds_list1_cpt_ids_map.values():
        cpds_list1_cpt_ids_to_standard_map[cpt_id] = [sid for sid in standard_to_cpds_list1_cpt_ids_map.keys() if standard_to_cpds_list1_cpt_ids_map[sid] == cpt_id][0]
    for cpt_id in standard_to_cpds_list2_cpt_ids_map.values():
        cpds_list2_cpt_ids_to_standard_map[cpt_id] = [sid for sid in standard_to_cpds_list2_cpt_ids_map.keys() if standard_to_cpds_list2_cpt_ids_map[sid] == cpt_id][0]


    # A dictionary mapping the ids of componds in cpds_list2 to compound objects
    cpds_list2_id_map = dict([(c.id,c) for c in cpds_list2]) 
    # ModelSEED ids for compounds in model2
    cpds_list2_ids = cpds_list2_id_map.keys()

    # A dictionary mapping the ModelSEED ids of componds to compounds in cpds_list2
    cpds_list2_ModelSEED_id_map = create_ModelSEEDID_map(cpds_list2)
    # ModelSEED ids for compounds in model2
    cpds_list2_ModelSEED_ids = cpds_list2_ModelSEED_id_map.keys()

    # A dictionary mapping the KEGG ids of componds to compounds in model2
    cpds_list2_KEGG_id_map = create_KEGGID_map(cpds_list2)
    # ModelSEED ids for compounds in model2
    cpds_list2_KEGG_ids = cpds_list2_KEGG_id_map.keys()

    # A dictionary mapping the BiGG ids of componds to compounds in model2
    cpds_list2_BiGG_id_map = create_BiGGID_map(cpds_list2)
    # ModelSEED ids for compounds in model2
    cpds_list2_BiGG_ids = cpds_list2_BiGG_id_map.keys()

    # A dictionary, which maps the non-alphanumeric names of the compounds to 
    # compounds in model2 
    cpds_list2_clean_names_map = create_cleanNames_map(cpds_list2,compart_list = cpds_list1_compar2_ids)
    # Names of compounds in model2 where all non-alpahnumeric characters are removed 
    cpds_list2_clean_names = cpds_list2_clean_names_map.keys()

    # Create a dictionary which maps the non-alphanumeric formul of the compounds and 
    # their ids in model2 
    cpds_list2_formulas_map = create_cpd_formulas_map(cpds_list2)
    # Formulas of compounds in model2 where all non-alpahnumeric characters are removed 
    cpds_list2_formulas = cpds_list2_formulas_map.keys()

    #-------- Find common compounds ----
    if stdout_msgs:
        print 'Checking for common compounds ...'

    cpd1_to_cpd2_map = dict((cpd1,[]) for cpd1 in cpds_list1) 
    cpd1_to_cpd2_noCopart_map = dict((cpd1,[]) for cpd1 in cpds_list1) 
    cpd1_to_cpd2_match_found_by = dict((cpd1.id,'No match') for cpd1 in cpds_list1) 
    cpd1_to_cpd2_noCompart_match_found_by = dict((cpd1.id,'No match') for cpd1 in cpds_list1) 

    # counters showing how many of common reactions were found by comparing their
    # ModelSEED id, KEGG id, name or model id
    id_counter = 0
    ModelSEED_counter = 0
    KEGG_counter = 0
    BiGG_counter = 0
    name_counter = 0
    formula_counter = 0

    for cpd1 in cpds_list1:

        # A list containing compounds form cpds_list2 matching cpd1 by id, BiGG id, KEGG id, name and formula
        match_byID = []
        match_byModelSEED = []
        match_byBiGG = []
        match_byKEGG = []
        match_byName = []
        match_byFormula = []

        # Search by id, If a match found by id no need to search by other criteria
        if cpd1.id in cpds_list2_ids:
            cpd1_to_cpd2_map[cpd1] += cpds_list2_id_map[cpd1.id]
            id_counter += 1

        else:
            # Compre ModelSEED ids. Consider ModelSEED id only if it is unique for cpd1
            ModelSEED_intersect = list(set(cpd1.ModelSEED_id).intersection(set(cpds_list2_ModelSEED_ids)): 
            if len(ModelSEED_intersect) > 0:
                ModelSEED_counter += 1
                for mid in ModelSEED_intersect:
                    match_byModelSEED += cpds_list2_ModelSEED_id_map[mid] 
                match_byModelSEED = list(set(match_byModelSEED))
  
            # Compre KEGG ids. Consider KEGG id only if it is unique for cpd1
            KEGG_intersect = list(set(cpd1.KEGG_id).intersection(set(cpds_list2_KEGG_ids)): 
            if len(KEGG_intersect) > 0:
                KEGG_counter += 1
                for kid in KEGG_intersect:
                    match_byKEGG += cpds_list2_KEGG_id_map[kid] 
                match_byKEGG = list(set(match_byKEGG))

            # Compre BiGG ids. Consider BiGG id only if it is unique for cpd1
            BiGG_intersect = list(set(cpd1.BiGG_id).intersection(set(cpds_list2_BiGG_ids)): 
            if len(BiGG_intersect) > 0:
                BiGG_counter += 1
                for bid in BiGG_intersect:
                    match_byBiGG += cpds_list2_BiGG_id_map[bid] 
                match_byBiGG = list(set(match_byBiGG))    

            # Compare names
            if cpd1.name != '':
                clean_names = [remove_non_alphanumeric(remove_compartment(cpd1.name,compartments_info = cpds_list1_compart_ids)).lower()] + [remove_non_alphanumeric(remove_compartment(n,compartments_info = cpds_list1_compart_ids)).lower() for n in cpd1.name_aliases]
                clean_names_intersect = list(set(clean_names).intersection(set(cpds_list2_clean_names)): 
                if len(clean_names_intersect) > 0:
                    clean_name_counter += 1
                    match_byName += clean_names_intersect 
                match_byName = list(set(match_byName))    

            # Compare formula
            elif cpd1.formula != '' and cpd.formula in cpds_list2_formulas: 
                formula_counter += 1
                match_byFormula = cpds_list2_formulas_map[cpd1.formula] 
             
        #--- Assign an accurate ModelSEED id according to searches above ---
        # If match_byID is not '', you've found a unique match id
        if match_byID != []:
            cpd1_to_cpd2_map[cpd1] = match_byID
            cpd1_to_cpd2_noCompart_map[cpd1] = match_byID
            cpd1_to_cpd2_match_found_by[cpd.id] = 'model id'
            cpd1_to_cpd2_noCompart_match_found_by[cpd.id] = 'model id'

        else:
            # If only one match was found by ModelSEED_id, you're done
            if len(match_byModelSEED_id) == 1:
                cpd.ModelSEED_id = match_byModelSEED_id
                cpd1_to_cpd2_noCompart_match_found_by[cpd.id] = 'ModelSEED_id id'
    
            # If only one match was found by KEGG_id, you're done
            elif len(match_byKEGG) == 1:
                cpd.ModelSEED_id = match_byKEGG
                cpd1_to_cpd2_noCompart_match_found_by[cpd.id] = 'KEGG id'
    
            # If only one match was found by BiGG_id, you're done
            elif len(match_byBiGG) == 1:
                cpd.ModelSEED_id = match_byBiGG
                cpd1_to_cpd2_noCompart_match_found_by[cpd.id] = 'BiGG id'
    
            # If only one match was found by formula, you're done
            elif len(match_byFormula) == 1:
                cpd.ModelSEED_id = match_byFormula
                cpd1_to_cpd2_noCompart_match_found_by[cpd.id] = 'formula'
            else:
                # Find the intersection of all searches
                if len([lst for lst in [match_byModelSEED, match_byKEGG, match_byBiGG, match_byName, match_byFormula] if len(lst) > 0]) > 0:
                    match_intersect = list(set.intersection(*[set(lst) for lst in [match_byKEGG,match_byBiGG,match_byName] if len(lst) > 0]))
                    if len(match_intersect) == 0:
                        cpd1_to_cpd2_noComaprt_map[cpd1] = match_intersect
                        cpd1_to_cpd2_noCompart_match_found_by[cpd.id] = 'intersection'
    
                    # Otherwise find their union
                    else:
                        cpd1_to_cpd2_noCompart_map[cpd1] = list(set(match_byKEGG + match_byBiGG + match_byName))
                        cpd1_to_cpd2_noCompart_match_found_by[cpd.id] = 'union'

    # If any match has found by ModelSEED_id, kEGG_id, BiGG_id, Name or Formula, check whether the compartments match too
    if len(cpd1_to_cpd2_map[cpd1]) == 0 and len(cpd1_to_cpd2_noCompart_map[cpd1]) > 0:   
        cpd1_to_cpd2_map[cpd1] = [cpd2 for cpd2 in cpd1_to_cpd2_noCompart_map[cpd] if cpds_list1_cpt_ids_to_standard_map[cpd1.compartment.id] = cpds_list2_cpt_ids_to_standard_map[cpd2.compartment.id]]        

    cpd2_to_cpd1_map = dict((cpd2,[]) for cpd2 in cpds_list2) 
    cpd2_to_cpd1_noCompart_map = dict((cpd2,[]) for cpd2 in cpds_list2) 
    cpd2_to_cpd1_match_found_by = dict((cpd2.id,'No match') for cpd2 in cpds_list1) 
    cpd2_to_cpd1_noCompart_match_found_by = dict((cpd2.id,'No match') for cpd2 in cpds_list1) 
    for cpd1 in [c for c in cpds_list1 if len(cpd1_to_cpd2_map[c]) > 0]:
        for cpd2 in cpd1_to_cpd2_map[cpd1]
            cpd2_to_cpd1_map[cpd2].append(cpd1)
        cpd2_to_cpd1_match_found_by[cpd2.id] = cpd1_to_cpd2_match_found_by[cpd1]
    for cpd1 in [c for c in cpds_list1 if len(cpd1_to_cpd2_noCompart_map[c]) > 0]:
        for cpd2 in cpd1_to_cpd2_noCompart_map[cpd1]
            cpd2_to_cpd1_noCompart_map[cpd2].append(cpd1)
        cpd2_to_cpd1_noCompart_match_found_by[cpd2.id] = cpd1_to_cpd2_noCompart_match_found_by[cpd1]

    # Compounds with no match
    no_match_cpds_list1 = [c for c in cpds_list1 if len(cpd1_to_cpd2_map) == 0] 
    no_match_cpds_list2 = [c for c in cpds_list2 if len(cpd2_to_cpd1_map) == 0] 

    # Compounds with more than one match
    more_than_one_match_cpds_list1 = [(c1.id,[c2.id for c2 in cpd1_to_cpd2_map[c1]]) for c1 in cpds_list1 if len(cpd1_to_cpd2_map) > 1] 
    more_than_one_match_cpds_list2 = [(c2.id,[c1.id for c1 in cpd2_to_cpd1_map[c2]]) for c2 in cpds_list2 if len(cpd2_to_cpd1_map) > 1] 

    if warnings:
        print '\n**WARNING! No match found for {} compounds in cpds_list1 and for {} compounds in cpds_list2'.format(len(no_match_cpds_list1),len(no_match_cpds_list2))
        print '\n**WARNING! More than one match found for the following {} compounds in cpds_list1: {}'.format(len(more_than_one_match_cpds_list1.keys()1),more_than_one_match_cpds_list1)
        print '\n**WARNING! More than one match found for the following {} compounds in cpds_list2: {}'.format(len(more_than_one_match_cpds_list2.keys()1),more_than_one_match_cpds_list2)
 
    if stdout_msgs:
        print '\nSummary of the compare_compounds:'
        print '\tTotal # of compounds in cpds_list1 with a match = {} (out of {})'.format(len([c for c in cpds_list1 if  cpd1_to_cpd2_map[c] != []]), len(cpds_list1))
        print '\tTotal # of compounds in cpds_list2 with a match = {} (out of {})'.format(len([c for c in cpds_list2 if  cpd2_to_cpd1_map[c] != []]), len(cpds_list2))
        print '\t\t# of compounds with a matched model id = ',id_counter
        print '\t\t# of compounds with a match KEGG id = ',KEGG_counter
        print '\t\t# of compounds with a matched BiGG id = ',BiGG_counter
        print '\t\t# of compounds with a matched name = ',name_counter
        print '\t\t# of compounds with a matached formula = ',formula_counter

        print '\n\t\t# of compounds in cpds_list1 with matches found by model id = ',len([c for c in cpd1_to_cpd2_match_found_by.keys() if cpd1_to_cpd2_match_found_by[c] == 'model id'])
        print '\t\t# of compounds with matches found by ModelSEED id = ',len([c for c in cpd1_to_cpd2_match_found_by.keys() if cpd1_to_cpd2_match_found_by[c] == 'ModelSEED id'])
        print '\t\t# of compounds with matches found by KEGG id = ',len([c for c in cpd1_to_cpd2_match_found_by.keys() if cpd1_to_cpd2_match_found_by[c] == 'KEGG id'])
        print '\t\t# of compounds with matches found by BiGG id = ',len([c for c in cpd1_to_cpd2_match_found_by.keys() if cpd1_to_cpd2_match_found_by[c] == 'BiGG id'])
        print '\t\t# of compounds with matches found by formula = ',len([c for c in cpd1_to_cpd2_match_found_by.keys() if cpd1_to_cpd2_match_found_by[c] == 'formula id'])
        print '\t\t# of compounds with matches found by intersecton of ModelSEED ids matching their KEGG id, BiGG id and names = ',len([c for c in cpd1_to_cpd2_match_found_by.keys() if cpd1_to_cpd2_match_found_by[c] == 'intersection'])
        print '\t\t# of compounds with matches found by union of ModelSEED ids matching their KEGG id, BiGG id and names = ',len([c for c in cpd1_to_cpd2_match_found_by.keys() if cpd1_to_cpd2_match_found_by[c] == 'union'])

    return cpd1_to_cpd2_map, cpd2_to_cpd1_map, cpd1_to_cpd2_noCopart_map, cpd2_to_cpd1_noCopart_map, cpd1_to_cpd2_match_found_by, cpd2_to_cpd1_match_found_by, cpd1_to_cpd2_noCompart_match_found_by, cpd2_to_cpd1_noCompart_match_found_by


def compare_reactions(rxn_list1, rxn_list2, standard_to_cpds_list1_cpt_ids_map, standard_to_cpds_list2_cpt_ids_map, rxn_list1_id = None, rxn_list2_id = None, warnings = True, stdout_msgs = True):
    """
    Find common reactions in two given list of reactions

    INPUTS:
    -------
        rxn_list1: A list of reaction objects 
        rxn_list2: A list of reaction objects
     rxn_list1_id: An id for rxn_list1. This is requried if not all reactions in 
                   rxn_list1 belong to the same model or if not model is assigned 
                   to all reactions of list 1
     rxn_list2_id: An id for rxn_list2. This is requried if not all reactions in 
                   rxn_list1 belong to the same model or if not model is assigned 
                   to all reactions of list 2
    standard_to_rxn_list1_cpt_ids_map:
    standard_to_rxn_list2_cpt_ids_map: 
                            A dictionary where keys are standard compartment ids as follows:
                            c: Cytosol (cytoplasm),   e: Extracellular,   g: Golgi,     m: Mitochondria
                            n: Nucleus,   p: Periplasm,    r: Endoplasmic reticulum,    x: Peroxisome
                            and values are corresponding compartment ids in rxns_list1 and rxns_list2

    OUTPUTS:
    --------
    rxn1_to_rxn2_map: A dictionary where the keys are the reactions objects from rxns_list1 and values 
                      are a list of reaction objects corresponding to this reaction from rxns_list2 
    rxn2_to_rxn1_map: A dictionary where the keys are the reactions objects from rxns_list2 and values 
                      are a list of reaction objects corresponding to this reaction from rxns_list1 
    rxn1_to_rxn2_noCopart_map:
    rxn2_to_rxn1_noCopart_map:
                      Same as rxn1_to_rxn2_map and rxn2_to_rxn1_map except that the mataches here are found
                      without considering the compartments
    rxn1_to_rxn2_match_found_by:
    rxn2_to_rxn1_match_found_by:
                      A dictionary with keys being ids of reactions in rxns_list1 or rxns_list2 and values being a 
                      string showing how the matches in rxn1_to_rxn2_map and rxn2_to_rxn1_map were found 
    rxn1_to_rxn2_noCompart_match_found_by:
    rxn2_to_rxn1_noCompart_match_found_by:
                      Same rxn1_to_rxn2_match_found_by and rxn2_to_rxn1_match_found_by for rxn1_to_rxn2_noCopart_map 
                      and rxn2_to_rxn1_noCopart_map
    """
    if not isinstance(strdout_msgs,bool):
        raise TypeError('stdout_msgs must be True or False')
    if not isinstance(warnings,bool):
        raise TypeError('warnings must be True or False')

    if rxn_list1_id == None:
        model1_id = list(set([r.model.id for r in rxn_list1 if 'model' in dir(r)]))
        if len(model1_id) == 1:
            rxn_list1_id = model1_id[0]
        else:
            raise userError('rxn_list1_id is needed because not all reactions in rxn_list1 have the same model id (' + str(model1_id) + ')')

    if rxn_list2_id == None:
        model2_id = list(set([r.model.id for r in rxn_list2 if 'model' in dir(r)]))
        if len(model2_id) == 1:
            rxn_list2_id = model2_id[0]
        else:
            raise userError('rxn_list2_id is needed because not all reactions in rxn_list2 have the same model id (' + str(model2_id) + ')')

    # List oc compartments
    if cpds_list1_compart_ids == None:
       cpds_list1_compart_ids = list(set([compart.id for r in rxn_list1 for compart in r.compartments]))
    if cpds_list1_compar2_ids == None:
       cpds_list1_compar2_ids = list(set([compart.id for r in rxn_list2 for compart in r.compartments]))


    # A dictionary mapping the ModelSEED ids of reactions ito reactions in model2
    rxn_list2_ModelSEED_id_map = create_ModelSEEDID_map(rxn_list2)
    # ModelSEED ids for reactions in model2
    rxn_list2_ModelSEED_ids = rxn_list2_ModelSEED_id_map.keys()

    # A dictionary mapping the ModelSEED ids of reactions into reactions in model2
    rxn_list2_KEGG_id_map = create_KEGGID_map(rxn_list2)
    # ModelSEED ids for reactions in model2
    rxn_list2_KEGG_ids = rxn_list2_KEGG_id_map.keys()

    # A dictionary which maps the non-alphanumeric names of the reactions to 
    # ids in model2 
    rxn_list2_clean_names_map = create_cleanNames_map(rxn_list2,compart_list = cpds_list1_compar2_ids)
    # Names of reactions in model2 where all non-alpahnumeric characters are removed 
    rxn_list2_clean_names = rxn_list2_clean_names_map.keys()

    common_reactions = [] 
    common_reaction = []

    # Add a new field termed hasMatch to all reactions, which indicates whether
    # it has a match in another model
    for rxn in rxn_list1:
        rxn.match = None

    for rxn in rxn_list2:
        rxn.match = None

    # counters showing how many of common reactions were found by comparing their
    # ModelSEED id, KEGG id, name or model id
    ModelSEED_counter = 0
    KEGG_counter = 0
    name_counter = 0
    id_counter = 0

    #--- Start the search ----
    for rxn1 in rxn_list1:
        # Remove non-alphanumeric characters and compartment ids from the id and replace 
        # all upper case letters with lowercase for name, id and formula
        clean_id = remove_non_alphanumeric(remove_compartment(rxn1.id,compartments_info = cpds_list1_compart_ids)).lower()
        if rxn1.name != None:
            if isinstance(rxn1.name,str):
                clean_name = remove_non_alphanumeric(remove_compartment(rxn1.name,compartments_info = cpds_list1_compart_ids)).lower()
            else: # if it is a list
                clean_name = [remove_non_alphanumeric(remove_compartment(n,compartments_info = cpds_list1_compart_ids)).lower() for n in rxn1.name]

        # Reactions in model 2 that match to this reaction
        match_m2 = []

        # Comprae ModelSEED ids. Consider the ModelSEED id if it is unique for rxn1
        if isinstance(rxn1.ModelSEED_id,str) and rxn1.ModelSEED_id in rxn_list2_ModelSEED_ids: 
            ModelSEED_counter += 1
            match_m2 += rxn_list2_ModelSEED_id_map[rxn1.ModelSEED_id] 

        # Compare kegg ids
        elif rxn1.KEGG_id != None and rxn1.KEGG_id in rxn_list2_KEGG_ids: 
            KEGG_counter += 1
            match_m2 += rxn_list2_KEGG_id_map[rxn1.KEGG_id] 

        # Compare ids
        elif len([rxn2 for rxn2 in rxn_list2 if rxn2.match == None and rxn2.id.lower() == rxn1.id.lower()]) > 0:
            id_counter += 1
            match_m2 += [rxn2 for rxn2 in rxn_list2 if rxn2.match == None and rxn2.id.lower() == rxn1.id.lower()]

        # Compare names
        elif rxn1.name != None and clean_name in rxn_list2_clean_names: 
            name_counter += 1
            match_m2 += rxn_list2_clean_names_map[clean_name] 

        if len(match_m2) >= 1:
            # Check the compartments
            compartment_match = [r for r in match_m2 if set([c.id.lower() for c in r.compartments]) == set([c.id.lower() for c in rxn1.compartments]) or set([c.name.lower() for c in r.compartments]) == set([c.name.lower() for c in rxn1.compartments])]
            if len(compartment_match) == 1:
                match_m2 = compartment_match[0]
            elif len(compartment_match) > 1:
                match_m2 = compartment_match
            else:
                match_m2 = []

            if len(match_m2) >= 1:
                rxn1.match = match_m2
                match_m2.match = rxn1
                common_reactions.append((rxn1,match_m2))           

    # Reactions in rxn_list1 with more than one match in rxn_list2
    more_than_one_match_rxns = [rxn_pair for rxn_pair in common_reactions if isinstance(rxn_pair[1],list)]
    if len(more_than_one_match_rxns) > 0 and warnings:
         print 'WARNING! ',len(more_than_one_match_rxns),' reactions in ',rxn_list1_id,' have more than one match in ',rxn_list2_id
         for rxn_pair in  more_than_one_match_rxns:
             print '\t', (((rxn_list1_id,rxn_pair[0].id),(rxn_list2_id,rxn_pair[1].id)))

    if stdout_msgs:
        print '\nSummary of the compare_reactiongs:'
        print '\tTotal # of reactiongs in %s = %i '%(rxn_list1_id,len(rxn_list1)) 
        print '\tTotal # of reactiongs in %s = %i '%(rxn_list2_id,len(rxn_list2)) 
        print '\tTotal # of common reactions = ',len(common_reactions)
        print '\t\t# of reactiongs matched by ModelSEED id = ',ModelSEED_counter
        print '\t\t# of reactiongs matched by KEGG id = ',KEGG_counter
        print '\t\t# of reactiongs matched by name = ',name_counter
        print '\t\t# of reactiongs matached by model id = ',id_counter
        print '\tTotal # of reactiongs unique to %s = %i '%(rxn_list1_id,len([c for c in rxn_list1 if c.match != None])) 
        print '\tTotal # of reactiongs unique to %s = %i\n'%(rxn_list2_id,len([c for c in rxn_list2 if c.match != None])) 
    
    return common_reactions


def compare_models(model1,model2,stdout_msgs = True):
    """
    This compares two metabolic models. It comapres both reactions and compounds. 
    by comparing their id, KEGG_id and ModelSEED_id, names or formula (for compunds only)

    INPUTS:
    ------
         model1: Model 1
         model2: Model 2
    stdout_msgs: Can be True or False showing whether details of comparison should be
                 written in the output


    OUTPUTS:
    --------
    common_compounds: A list of tuples where the first element is an object of type reaction
                      referring to a compound in cpd_list 1 and the second element is an object 
                      of list of objects of type compound containing the corresponding compounds
                      in cpds_list2 
    common_reactions: A list of tuples where the first element is an object of type reaction
                      referring to a compound in rxn_list 1 and the second element is an object 
                      of list of objects of type reaction containing the corresponding reactions
                      in rxn_list2 
               match: This function also assigns to each compound and reaction object a new field 
                      termed match. If match is None it means that reaction or compound has no 
                      match in other models. Otherwise it is a list of objects of type compound
                      (for compounds) or reactions (for reactions) that match to this compound
                      or reaction in other models 
    """
    if not isinstance(strdout_msgs,bool):
        raise TypeError('stdout_msgs must be True or False')
       
    # Try to get the ModelSEED ids 
    if stdout_msgs:
        print '\n---------- Compre two metabolic models -----------\n'

    # Get ModelSEED ids for reactions and metabolites
    get_ModelSEED_ids(model1,stdout_msgs = stdout_msgs)
    get_ModelSEED_ids(model2,stdout_msgs = stdout_msgs)

    if stdout_msgs:
        print '\n'
        print len([r for r in model1.reactions if r.ModelSEED_id != None]),' (out of ',len(model1.reactions),') reactions have ModelSEED id in ',model1.id
        print len([c for c in model1.compounds if c.ModelSEED_id != None]),' (out of ',len(model1.compounds),') compounds have ModelSEED id in ',model1.id
        print len([r for r in model2.reactions if r.ModelSEED_id != None]),' (out of ',len(model2.reactions),') reactions have ModelSEED id in ',model2.id
        print len([c for c in model2.compounds if c.ModelSEED_id != None]),' (out of ',len(model2.compounds),') compounds have ModelSEED id in ',model2.id
        print '\n'

    # List of compartment ids
    model1_comparts = [compart.id for compart in model1.compartments]
    model2_comparts = [compart.id for compart in model2.compartments]

    # Compare compounds
    common_compounds = compare_compounds(cpds_list1 = model1.compounds,cpds_list2 = model2.compounds,cpds_list1_compart_ids = model1_comparts, cpds_list1_compar2_ids = model2_comparts, stdout_msgs = stdout_msgs)

    # Compare reactions
    common_reactions = compare_reactions(rxn_list1 = model1.reactions,rxn_list2 = model2.reactions,cpds_list1_compart_ids = model1_comparts, cpds_list1_compar2_ids = model2_comparts, stdout_msgs = stdout_msgs)

    if stdout_msgs:
        print '\n---------- Done with comparing models -----------\n'

    return [common_compounds,common_reactions]

