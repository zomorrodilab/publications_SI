from __future__ import division
import sys, time
sys.path.append('../')
import os
import matplotlib
from imp import load_source
from matplotlib import colors 
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from tools.userError import userError
import numpy as np

#------------------------------------------
# Ali R. Zomorrodi - Segre Lab @ BU
# Last updated: 10-04-2018
#------------------------------------------

"""
TIPS:
-----
Specify the position of the legend using loc and bbox_to_anchor:
---------------------------------------------------------------
When using bbox_to_anchor and loc together, beware that if you like your legend to appear on the right
you should specify "left" in loc and vice versa. For example, to have your legend appear in the center right
you should specify "center left" for loc.
Example: For legend to appear on the right side of the graph and outside it use:
        'center left', 'bbox_to_anchor': (1,0.5)
Example: For legend to appear in the bottom center use 'location':'lower center', 'bbox_to_anchor': (0.5,-0.5)
          Here 0.5 and -0.5 determines the x and y coordinates of bottom left corner of the legen.
          You should play with -0.5 to find the
          best distance of the legend from the graph


Render text in a plot
---------------------
1. The following line makes the math font regular (the same size the normal font)
Source: http://stackoverflow.com/questions/15836050/matplotlib-change-math-font-size 
matplotlib.rcParams['mathtext.default']='regular'
This is not easy to set back to default. See:
http://stackoverflow.com/questions/22569071/matplotlib-change-math-font-size-and-then-go-back-to-default 
Instead you can consider using \mathdefault{...} or its alias \mathregular{...}
Source: http://matplotlib.org/users/mathtext.html#fonts

3. To make part of mathtext bold use \bf{} or \mathbf
3. To remove italic in part of a mathtext use \rm{} 
"""

#--- Define some global default values ---
"""
NOTE about using fonts:
The Arial, Helvetica, and Times New Toman fonts are proprietary ones that are not typically installed on Linux systems. We do have free equivalents of those available. Please see this page for more details: https://en.wikipedia.org/wiki/Liberation_fonts
 
The font substitutions are:
Times New Roman --> Liberation Serif
Arial or Helvetica --> Liberation Sans
For monospaced fonts like Courier New you can try and of the fonts with Mono in the name - Liberation Mono, etc).
 
You can add any TrueType font you like to your user directory by copying the .ttf file(s) to a special subdirectory that will be automatically scanned for fonts: $HOME/ .local/share/fonts/
 
For example:
# connect to an SCC login node
mkdir .local/share/fonts/
# From your computer upload .ttf files to: /usr2/postdoc/alizom/.local/share/fonts/
"""
# Defaulty figure font family and name (set by rcParam)
#figure_default_fontfamily = 'sans-serif'
#figure_default_fontname = figure_default_fontfamily 
#figure_default_fontfamily = 'Liberation Serif'
#figure_default_fontname = 'Liberation Serif'
figure_default_fontfamily = 'Liberation Sans'
figure_default_fontname = 'Liberation Sans'

# Default font size for figure, title, axes labels, tick labels and legend 
if figure_default_fontfamily in ['Liberation Serif', 'Liberation Sans']:
    figure_default_fontsize = 32
    title_default_fontsize = 42 
    axes_label_default_fontsize = 38
    ticklabels_default_fontsize = 32
    legend_default_fontsize = 32
else: 
    figure_default_fontsize = 26
    title_default_fontsize = 28 
    axes_label_default_fontsize = 26
    ticklabels_default_fontsize = 24
    legend_default_fontsize = 26

# Defaulty figure font weight  
figure_default_fontweight = 'regular'

# Default font size for title
title_default_fontname = figure_default_fontname

# Defaul font size for axes and colorbar labels
axes_label_default_fontname = figure_default_fontname 

# Default font name and size for tick labels 
ticklabels_default_fontname = None

# Default font name and size for legend 
legend_default_fontname = None

# Defaulty figure size
figsize_default = None 

# default colormap
#colormap_default = matplotlib.cm.RdBu
colormap_default = None 

class axis(object):
    """
    A class holding the axes properties
    """
    def __init__(self,label = '', label_format = {'fontname': None,'fontweight':None, 'fontsize':axes_label_default_fontsize, 'distance_from_ticklabels':None, 'position': None}, limits = None, set_minorticks = False, minorticks_spacing = None, majorticks_spacing = None, custom_ticks = None, custom_ticklabels = None, ticklabels_format = {'fontname':None, 'fontweight':None, 'fontsize':ticklabels_default_fontsize,'rotation':0, 'string_format':None, 'position':None,'horizontalalignment': None, 'verticalalignment':None}, plot_gridlines = False, gridlines_format = {'color':'black', 'linestyle':'dashed', 'linewidth':1}, spines_format = {}, invert = False, scale = None):
        """
        INPUTS:
        -------
        label: 
        Axis label (a string)

        label_format: 
        A dictionary showing the format of the axis label

        limits: 
        Axis limits. A tuple in the form of (min,max)

        set_minorticks: 
        Showing whether to set the minor ticks (True) or nor (False)

        minorticks_spacing: 
        Space between minor ticks

        majorticks_spacing: 
        Space between major ticks

         custom_ticks: 
         Custom ticks

         custom_ticklabels: 
         Custom tick labels

         ticklabels_format: 
         Format of the tick labels

         plot_gridlines: 
         Showing whether to plot the grid lines (True) or not (False)
            gridlines_fomrat: A dictionary containing the gridlines properties
                 show_legend: Whether to show the legend (True) or not (False)
               legend_format: A dictionary containing the legend properties

        spines_format: 
        Format of the axis lines. This a dictionary with allowed keys being 'top', 'bottom', 
        'left', 'right'. The values must be another dictionary with either of these three keys: 
       'linewidth', 'linestyle' and 'linecolor'

        invert: 
        Shows whether to invert an axis (True) or not (False)

        scale: 
        The scale of the axis. Allowed choices are 'linear', 'log', 'logit', 'symlog'
        """
        # Axis label
        self.label = label

        # label format
        # NOTE: fontname and fontweight default values are set in customize_and_save function
        self.label_format = label_format
        if 'fontsize' not in self.label_format.keys():
            self.label_format['fontsize'] = axes_label_default_fontsize 
        if 'rotation' not in self.label_format.keys():
            self.label_format['rotation'] = 0 
        if 'distance_from_ticklabels' not in self.label_format.keys():
            # To increase distance from ticklabels set this parameter to 25
            self.label_format['distance_from_ticklabels'] = None 
        if 'position' not in self.label_format.keys():
            self.label_format['position'] = None 

        # ticklabels_format
        # NOTE: fontname and fontweight default values are set in customize_and_save function
        self.ticklabels_format = ticklabels_format 
        if 'fontsize' not in self.ticklabels_format.keys():
            self.ticklabels_format['fontsize'] = ticklabels_default_fontsize
        if 'rotation' not in self.ticklabels_format.keys():
            self.ticklabels_format['rotation'] = 0 
        if 'string_format' not in self.ticklabels_format.keys():  # string_format is like %1.2f or %d
            self.ticklabels_format['string_format'] = None 
        if 'position' not in self.ticklabels_format.keys():  
            self.ticklabels_format['position'] = None 
        if 'horizontalalignment' not in self.ticklabels_format.keys(): 
            self.ticklabels_format['horizontalalignment'] = None 
        if 'verticalalignment' not in self.ticklabels_format.keys(): 
            self.ticklabels_format['verticalalignment'] = None 

        # If ticklables are rotated, set the horizontal alignment to 'right' ir rotation is between 0 and 180
        # and to left it rotation is between 180 and 360 because otherwise tick labels do not match the
        # the ticks themselves
        # see: https://stackoverflow.com/questions/14852821/aligning-rotated-xticklabels-with-their-respective-xticks
        if (self.ticklabels_format['rotation'] != None and (self.ticklabels_format['rotation'] > 0 and self.ticklabels_format['rotation'] < 180)) and self.ticklabels_format['horizontalalignment'] == None:
            self.ticklabels_format['horizontalalignment'] = 'right'
        elif (self.ticklabels_format['rotation'] != None and self.ticklabels_format['rotation'] < 0 or(self.ticklabels_format['rotation'] > 180 and self.ticklabels_format['rotation'] < 360)) and self.ticklabels_format['horizontalalignment'] == None:
            self.ticklabels_format['horizontalalignment'] = 'left'

        # Axis limits (a tuple with the first and second elements being the min and max)
        self.limits = limits

        # Set minor ticks (True or False)
        self.set_minorticks = set_minorticks

        # Specify minor tick spacing
        self.minorticks_spacing = minorticks_spacing

        # Specify major tack spacing
        self.majorticks_spacing = majorticks_spacing

        # Custom ticks (must be an array of integers or float) 
        self.custom_ticks = custom_ticks

        # Custom tick labels (must be an array of strings) 
        self.custom_ticklabels = custom_ticklabels

        # Grid lines
        self.plot_gridlines = plot_gridlines 
    
        # gridlines format
        if self.plot_gridlines:
            self.gridlines_format = gridlines_format
            gridlines_format_keys = [k.lower() for k in gridlines_format.keys()]
            if 'color' not in gridlines_format_keys:
                self.gridlines_format['color'] = 'k' 
            if 'linestyle' not in gridlines_format_keys:
                self.gridlines_format['linestyle'] = 'dashed' 
            if 'linewidth' not in gridlines_format_keys:
                self.gridlines_format['linewidth'] = 2 

        # Spines (axes and graph's border lines) format
        # Here main and opposite are the main axis spine and the one opoosite to it. For example, for 
        # an x axis main may refer to the one in the bottom and opposite to that on the top. Similarly for a y
        # axis, main and opoosite refer to the left and right spines. The definision, which one is main and which one
        # is the opposite is up to the user
        # Source: http://matplotlib.org/api/spines_api.html#matplotlib.spines.Spine.set_position
        self.spines_format = spines_format

        # Whether to use inverted axis
        self.invert = invert

        # Scale. Acceptable choices are 'linear', 'log', 'logit', 'symlog'
        self.scale = scale

    def __setattr__(self,attr_name,attr_value):
        """
        Redefines funciton __setattr__
        INPUTS:
        -------
        attr_name: Attribute name
        attr_value: Attribute value
        """
        if attr_name.lower() == 'label' and not isinstance(attr_value,str):
            raise TypeError('label must be a string')
 
        if attr_name.lower() == 'limits' and attr_value != None and not isinstance(attr_value,tuple):
            raise TypeError('limits must be a tuple')
        else:
            if attr_name.lower() == 'limits' and attr_value != None and len(attr_value) != 2:
                raise ValueError('limits must be a tuple in the form of (min_value,max_value)')
            if attr_name.lower() == 'limits' and attr_value != None and attr_value[0] != None and attr_value[1] != None and attr_value[0] >= attr_value[1]:
                raise ValueError('The second entry in limits must be greater than the first one. The entered value for limits is: {}'.format(attr_value))
 
        if attr_name.lower() == 'set_minorticks' and not isinstance(attr_value,bool):
            raise TypeError('set_minorticks must be either True or False')
 
        if attr_name.lower() == 'set_majorticks' and not isinstance(attr_value,bool):
            raise TypeError('set_majorticks must be either True or False')
         
        if attr_name.lower() == 'label_format' and not isinstance(attr_value,dict):
            raise TypeError('label_format must be a dictionary')
        elif attr_name.lower() == 'label_format' and len([k.lower() for k in attr_value.keys() if k not in ['fontname','fontweight','fontsize','rotation','distance_from_ticklabels','position']]) > 0:
            raise ValueError('Unknown key(s) for label_format: {}'.format([k for k in attr_value.keys() if k.lower() not in ['fontname','fontweight','fontsize','distance_from_ticklabels','position']]))
 
        if attr_name.lower() == 'ticklabels_format' and not isinstance(attr_value,dict):
            raise TypeError('ticklabels_format must be a dictionary')
        elif attr_name.lower() == 'ticklabels_format' and len([k for k in attr_value.keys() if k.lower() not in ['fontname','fontweight','fontsize','rotation','string_format','position','horizontalalignment','verticalalignment','distance_from_ticklabels']]) > 0: 
            raise ValueError('Unknown key(s) for label_format: {}'.format([k for k in attr_value.keys() if k.lower() not in ['fontname','fontweight','fontsize','rotation','string_format','position','horizontalalignment','verticalalignment','distance_from_ticklabels']]))
 
        if attr_name.lower() == 'custom_ticks' and attr_value is not None and not isinstance(attr_value,list) and not isinstance(attr_value,np.ndarray):
            raise TypeError('custom_ticks must be an array of integers or floats')
        elif attr_name.lower() == 'custom_ticks' and attr_value is not None and len([k for k in attr_value if not isinstance(k,int) and not isinstance(k,float)]): 
            raise ValueError('custom_ticks must be an array of integers or floats. Non-integer and non-float values were entered: {}'.format([k for k in attr_value if not isinstance(k,int) and not isinstance(k,float)]))
 
        if attr_name.lower() == 'custom_ticklabels' and attr_value != None and not isinstance(attr_value,list):
            raise TypeError('custom_ticklabels must be an array of strings')
        elif attr_name.lower() == 'custom_ticklabels' and attr_value != None and len([k for k in attr_value if not isinstance(k,str)]) > 0: 
            raise ValueError('custom_ticklabels must be an array of strings. Non-string values were entered: {}'.format([k for k in attr_value if not isinstance(k,str)]))
 
        if attr_name.lower() == 'invert' and not isinstance(attr_value,bool):
            raise TypeError('invert must be either True or False')
 
        if attr_name.lower() == 'scale' and attr_value != None and not isinstance(attr_value,str):
            raise TypeError('scale must be a string')
        elif attr_name.lower() == 'scale' and attr_value != None and attr_value not in ['linear', 'log', 'logit', 'symlog']: 
           raise ValueError('Invalid value for scale! Allowed choices are: linear, log, logit, symlog')

        # Gridlines
        if attr_name.lower() == 'plot_gridlines' and not isinstance(attr_value,bool):
            raise TypeError('plot_gridlines must be either True or False')
 
        if attr_name.lower() == 'gridlines_format' and not isinstance(attr_value,dict):
            raise TypeError('gridlines_format must be a dictionary')
        elif attr_name.lower() == 'gridlines_format' and len([k for k in attr_value.keys() if k.lower() not in ['color', 'linestyle', 'linewidth']]) > 0: 
            raise ValueError('Unknown key(s) for label_format: {}'.format([k for k in attr_value.keys() if k.lower() not in ['color', 'linestyle', 'linewidth']]))


        # Spines (axes and graph's border lines)
        if attr_name.lower() == 'spines_format':
            if  not isinstance(attr_value,dict):
                raise TypeError('spines_format must be a dictionary')
            if len([k for k in attr_value.keys() if k.lower() not in ['top','bottom','left','right']]) > 0:
                raise ValueError('Invalid key for spines_format: {}. Allowed keys are [top, bottom, left, right]'.format([k for k in attr_value.keys() if k.lower() not in ['top','bottom', 'left', 'right']]))

            for spines_key in attr_value.keys():
                if not isinstance(attr_value[spines_key],dict):
                    raise TypeError("spines_format['{}'] must be a dictionary".format(spines_key))
                if len([k for k in attr_value[spines_key].keys() if k.lower() not in ['linewidth','linestyle','linecolor']]) > 0:
                    raise ValueError("Invalid key for spines_format['{}']: {}. Allowed keys are [linestyle,linewidth,linecolor]".format(spines_key,[k for k in attr_value[spines_key].keys() if k.lower() not in ['linestyle','linewidth','linecolor']]))


        self.__dict__[attr_name] = attr_value

class color_bar(object):
    """
    A class holding the properties of the color bar (for related graphs)

    See examples here:
    https://matplotlib.org/gallery/statistics/barchart_demo.html
    Faren_project > OptForce_sim > function epistatic_func
    Game_theory project (Ecoli_pairs) > leakiness_ss
    """
    def __init__(self, colormap = None, colorlimits = None, label = '', label_format = {'fontname': None, 'fontweight':None, 'fontsize':axes_label_default_fontsize,'rotation':270,'distance_from_ticklabels':None, 'string_format': None}, set_minorticks = False, minorticks_spacing = None, majorticks_spacing = None, custom_ticks = None, custom_ticklabels = None, ticklabels_format = {'fontname':None, 'fontweight':None,'fontsize':ticklabels_default_fontsize,'rotation':0, 'string_format':None, 'axis_position':None, 'ticks_position':None, 'horizontalalignment': None, 'verticalalignment':None}):

        # colorbar
        if colormap != None:
            self.colormap = colormap
        else:
            self.colormap = colormap_default
        
        # colorlimits: A tuple in the form (min,max) indicating the Color range for the colormap. These values are 
        # used as vmin and vmax for pcolor, pcolormesh, matshow or imshow.  
        # As a general rule for pcolor and pcolormesh mesh vmin = data.min() and vmax = data.max(). 
        # If you like to have ticklabels placed in the middle of ticks in (1) a discerete colormap for pcolor 
        # and pcolormesh, or (2) in general for matshow and imshow use: 
        # vmin = data.min() - 0.5 and vmax = data.max() + 0.5. 
        self.colorlimits = colorlimits

        # Label
        self.label = label

        # label_format
        # NOTE: fontname and fontweight default values are set in customize_and_save function
        self.label_format = label_format
        if 'fontsize' not in self.label_format.keys():
            self.label_format['fontsize'] = axes_label_default_fontsize 
        if 'rotation' not in self.label_format.keys():
            self.label_format['rotation'] = 270 
        if 'distance_from_ticklabels' not in self.label_format.keys():
            self.label_format['distance_from_ticklabels'] = None 
        if 'string_format' not in self.label_format.keys():
            self.label_format['string_format'] = None 

        # Set minor ticks (True or False)
        self.set_minorticks = set_minorticks

        # Specify minor tick spacing
        self.minorticks_spacing = minorticks_spacing

        # Specify major tack spacing
        self.majorticks_spacing = majorticks_spacing

        # Custom ticks (must be an array of integers or float) 
        self.custom_ticks = custom_ticks

        # Custom tick labels (must be an array of strings) 
        self.custom_ticklabels = custom_ticklabels

        # ticklabels_format
        # NOTE: fontname and fontweight default values are set in customize_and_save function
        self.ticklabels_format = ticklabels_format 
        if 'fontsize' not in self.ticklabels_format.keys():
            self.ticklabels_format['fontsize'] = ticklabels_default_fontsize
        if 'rotation' not in self.ticklabels_format.keys():
            self.ticklabels_format['rotation'] = 0 
        if 'string_format' not in self.ticklabels_format.keys():  # string_format is like %1.2f or %d
            self.ticklabels_format['string_format'] = None 
        if 'axis_position' not in self.ticklabels_format.keys(): # Tick labels on top/bottom/left/right acis 
            self.ticklabels_format['axis_position'] = None 
        if 'ticks_position' not in self.ticklabels_format.keys(): # Tick labels position w.r.t. to ticks. The only aalowed choice is 'middle' 
            self.ticklabels_format['ticks_position'] = None 
        if 'horizontalalignment' not in self.ticklabels_format.keys(): 
            self.ticklabels_format['horizontalalignment'] = None 
        if 'verticalalignment' not in self.ticklabels_format.keys(): 
            self.ticklabels_format['verticalalignment'] = None 


    def __setattr__(self,attr_name,attr_value):
        """
        Redefines funciton __setattr__
        INPUTS:
        -------
        attr_name: Attribute name
        attr_value: Attribute value
        """
        if attr_name.lower() == 'label' and not isinstance(attr_value,str):
            raise TypeError('label must be a string')

        if attr_name.lower() == 'colorlimits' and attr_value != None and not isinstance(attr_value,tuple):
            raise TypeError('colorlimits must be a tuple of form (min,max)')
        if attr_name.lower() == 'colorlimits' and attr_value != None and len(attr_value) != 2:
            raise TypeError('colorlimits must be a tuple of size two (min,max)')
        elif attr_name.lower() == 'colorlimits' and attr_value != None and not attr_value[1] > attr_value[0]:
            raise TypeError('min value in colorlimits is greater than its max: {}'.format(attr_value))

        if attr_name.lower() == 'label_format' and not isinstance(attr_value,dict):
            raise TypeError('label_format must be a dictionary')
        elif attr_name.lower() == 'label_format' and len([k for k in attr_value.keys() if k.lower() not in ['fontname', 'fontweight','fontsize','rotation','distance_from_ticklabels','string_format']]) > 0: 
            raise ValueError('Unknown key(s) for label_format: {}'.format([k for k in attr_value.keys() if k.lower() not in ['fontname', 'fontweight','fontsize','rotation','distance_from_ticklabels','string_format']]))

        if attr_name.lower() == 'ticklabels_format' and not isinstance(attr_value,dict):
            raise TypeError('ticklabels_format must be a dictionary')
        elif attr_name.lower() == 'ticklabels_format' and len([k for k in attr_value.keys() if k.lower() not in ['fontname','fontweight','fontsize','rotation','string_format','axis_position', 'ticks_position','horizontalalignment','verticalalignment','distance_from_ticklabels']]) > 0: 
            raise ValueError('Unknown key(s) for label_format: {}'.format([k for k in attr_value.keys() if k.lower() not in ['fontname','fontweight','fontsize','rotation','string_format','axis_position', 'ticks_position','horizontalalignment','verticalalignment','distance_from_ticklabels']]))

        if attr_name.lower() == 'set_minorticks' and not isinstance(attr_value,bool):
            raise TypeError('set_minorticks must be either True or False')
 
        if attr_name.lower() == 'set_majorticks' and not isinstance(attr_value,bool):
            raise TypeError('set_majorticks must be either True or False')
 
        if attr_name.lower() == 'custom_ticks' and attr_value != None and not isinstance(attr_value,list) and not isinstance(attr_value, np.ndarray):
            raise TypeError('custom_ticks must be an array of integers or floats or a numpy ndarray')
        elif attr_name.lower() == 'custom_ticks' and attr_value != None and len([k for k in attr_value if not isinstance(k,int) and not isinstance(k,float)]): 
            raise ValueError('custom_ticks must be an array of integers or floats or a numpy ndarray. Non-integer and non-float values were entered: {}'.format([k for k in attr_value if not isinstance(k,int) and not isinstance(k,float)]))
 
        if attr_name.lower() == 'custom_ticklabels' and attr_value != None and not isinstance(attr_value,list):
            raise TypeError('custom_ticklabels must be an array of strings')
        elif attr_name.lower() == 'custom_ticklabels' and attr_value != None and len([k for k in attr_value if not isinstance(k,str)]) > 0: 
            raise ValueError('custom_ticklabels must be an array of strings. Non-string values were entered: {}'.format([k for k in attr_value if not isinstance(k,str)]))

        self.__dict__[attr_name] = attr_value

class plot(object):
    """
    Makes different types of plots including
    2D plot
    3D plot
    Heatmap plots
    """
    def __init__(self, title = '', title_format = {'fontname':None, 'fontweight':None, 'fontsize':title_default_fontsize, 'distance_from_graph':1.05}, xaxis = None, yaxis = None,zaxis = None, plot_gridlines = False, gridlines_format = {'color':'black', 'linestyle':'dashed', 'linewidth':1}, show_legend = False, legend_format = {'location':0, 'fontname':None, 'fontsize': figure_default_fontsize, 'fontweight':None, 'linewidth': 2, 'bbox_to_anchor': None, 'save_in_separate_figure': False, 'output_filename':''}, fig_format = {'figsize':figsize_default, 'fontfamily':figure_default_fontfamily, 'fontname': figure_default_fontname, 'fontsize':figure_default_fontsize,'fontweight':figure_default_fontweight,'use_tight_layout':True, 'use_equal_scale':False, 'dpi':None, 'use_LaTex': False, 'mathtext_fontname':None}, output_filename = ''):
        """
        Constructor takes only inputs that are general to all types of plots
        INPUTS:
        -------
        title: 
        Title of the figure

        title_format: 
        A dictionary containing the title format properties

        xaxis, yaxis and zaxis: 
        An instance of class axis
                   
        plot_gridlines: 
        Showing whether to plot the grid lines (True) or not (False). If True,
        gridlines are plotted for ALL axes by setting their plot_gridlines to True.
        To plot gridlines only for specific axes, set this parameter to False here,
        but set it to True for the desired axis.

        gridlines_fomrat: 
        A dictionary containing the gridlines properties. This format is used for 
        ALL axes. To choose different formats for different axes, set this parameter
        for each axis separately (see class axis for details)

        show_legend: 
        Whether to show the legend (True) or not (False)

        legend_format: 
        A dictionary containing the legend properties
        NOTE: output_filename represents the name of the file to whcih the legend should be
        save if save_in_separate_figure = True

        fig_format: 
        Figure format. Keys include:
                    figsize: A tuple showing the dimensions of the figure
                                  fontname: Font name (font family) of the figure
                                  fontsize: Font size of the figure
                          use_tight_layout: Showing whether to to use a tight layout (True) or not (False)
                                       dpi: dpi of the output figure
                           use_equal_scale: Use equal scale for x and y axis
                                 use_LaTex: use Latex to render the text elements in the figure
                         mathtext_fontname: Custom fontname for mathtext (build-in matplotlib LaTex)
 
        output_filename: 
        Name of the output file to save the figure
    
        Ali R. Zomorrodi, Segre Lab @ BU
        Last updated: 12-04-2018
        """
        # Title
        self.title = title
    
        # Title format
        # Font name and weight are set after initializing fig_format
        self.title_format = title_format
        title_format_keys = [k.lower() for k in title_format.keys()]
        if 'fontsize' not in title_format_keys: 
            self.title_format['fontsize'] = title_default_fontsize 
        if 'distance_from_graph' not in title_format_keys: 
            self.title_format['distance_from_graph'] = 1.05 
    
        # x axes
        if xaxis == None:
            self.xaxis = axis
        else:
            self.xaxis = xaxis
    
        # y axes
        if yaxis == None:
            self.yaxis = axis
        else:
            self.yaxis = yaxis

        # z axis  
        if zaxis != None:
            self.zaxis = zaxis
    
        # Grid lines and their format
        if plot_gridlines:
            gridlines_format_keys = [k.lower() for k in gridlines_format.keys()]
            if 'color' not in gridlines_format_keys:
                gridlines_format['color'] = 'k' 
            if 'linestyle' not in gridlines_format_keys:
                gridlines_format['linestyle'] = 'dashed' 
            if 'linewidth' not in gridlines_format_keys:
                gridlines_format['linewidth'] = 2 

            self.xaxis.plot_gridlines = True
            self.xaxis.gridlines_format = gridlines_format

            self.yaxis.plot_gridlines = True
            self.yaxis.gridlines_format = gridlines_format

            if zaxis != None:
                self.zaxis.plot_gridlines = True
                self.zaxis.gridlines_format = gridlines_format

        # Show legend
        self.show_legend = show_legend
        self._legend_handles = []
        self._legend_labels = []
        self._legend_title = ''

        # Legend properties
        # NOTE: fontname and fontweight default values are set after initializing fig_format
        self.legend_format = legend_format
        # See http://matplotlib.org/api/legend_api.html for help on location
        legend_format_keys = [k.lower() for k in self.legend_format.keys()]
        if self.legend_format != None and 'location' not in legend_format_keys:
            self.legend_format['location'] = 'best'
        if self.legend_format != None and 'fontsize' not in legend_format_keys:
            self.legend_format['fontsize'] = figure_default_fontsize
        if self.legend_format != None and 'linewidth' not in legend_format_keys:
            self.legend_format['linewidth'] = 2 
        if self.legend_format != None and 'frame_linewidth' not in legend_format_keys:
            self.legend_format['frame_linewidth'] = 1 
        if self.legend_format != None and 'frame_linecolor' not in legend_format_keys:
            self.legend_format['frame_linecolor'] = 'Black' 
        if self.legend_format != None and 'bbox_to_anchor' not in legend_format_keys:
            self.legend_format['bbox_to_anchor'] = None 
        if self.legend_format != None and 'save_in_separate_figure' not in legend_format_keys:
            self.legend_format['save_in_separate_figure'] = False 
        if self.legend_format != None and 'output_filename' not in legend_format_keys:
            self.legend_format['output_filename'] = '' 
    
        # Figure format
        self.fig_format = fig_format
        fig_format_keys = [k.lower() for k in self.fig_format.keys()] 
        if 'figsize' not in fig_format_keys:
            self.fig_format['figsize'] = figsize_default
        if 'fontfamily' not in fig_format_keys:
            self.fig_format['fontfamily'] = figure_default_fontfamily
        if 'fontname' not in fig_format_keys:
            self.fig_format['fontname'] = figure_default_fontname
        if 'fontsize' not in fig_format_keys:
            self.fig_format['fontsize'] = figure_default_fontsize
        if 'fontweight' not in fig_format_keys:
            self.fig_format['fontweight'] = figure_default_fontweight 
        if 'use_tight_layout' not in fig_format_keys:
            self.fig_format['use_tight_layout'] = True
        if 'use_equal_scale' not in fig_format_keys:
            self.fig_format['use_equal_scale'] = False
        if 'dpi' not in fig_format_keys: 
            self.fig_format['dpi'] = None
        if 'use_latex' not in fig_format_keys: 
            self.fig_format['use_LaTex'] = False
        if 'mathtext_fontname' not in fig_format_keys: 
            self.fig_format['mathtext_fontname'] = None

        # font name and weight for title
        if 'fontname' not in title_format_keys or self.title_format['fontname'] == None: 
            self.title_format['fontname'] = self.fig_format['fontname'] 
        if 'fontweight' not in title_format_keys or self.title_format['fontweight'] == None: 
            self.title_format['fontweight'] = self.fig_format['fontweight'] 


        # font name and weight for legend
        if 'fontname' not in legend_format_keys or self.legend_format['fontname'] == None:
            self.legend_format['fontname'] = self.fig_format['fontname']
        if 'fontweight' not in legend_format_keys or self.legend_format['fontweight'] == None:
            self.legend_format['fontweight'] = self.fig_format['fontweight']
        
        # File name storing the figure
        self.output_filename = output_filename
    
        # A parameter showing the type of plot ('heatmap', '2d_line', '3d'), The value is assigned inside each function 
        self._plot_type = ''
    
        # Update the matplotlib configuration parameters:
        # NOTE: When using rcParams it changes all font properties of the figure (it overwrites individual
        # font properties)
        # If use_LaTex - True and the fontweight is bold then one needs to load amsmath into the TeX preamble to enable
        # bold LaTex fonts, otherwise the fonts will not be bold.
        # Source: http://stackoverflow.com/questions/14324477/bold-font-weight-for-latex-axes-label-in-matplotlib
        # Also, see: https://tex.stackexchange.com/questions/595/how-can-i-get-bold-math-symbols/596
        # use \boldsymbol{} if using amsmath, or use \bm{} if using bm packages, respectively.
        if self.fig_format['fontweight'].lower() == 'bold' and self.fig_format['use_LaTex']:
            #matplotlib.rcParams.update({'font.family': self.fig_format['fontfamily'], 'font.serif':self.fig_format['fontname'], 'font.weight':self.fig_format['fontweight'],'font.size': self.fig_format['fontsize'], 'text.usetex': self.fig_format['use_LaTex'], 'text.latex.preamble':r"\usepackage{amsmath}"})
            matplotlib.rcParams.update({'font.family': self.fig_format['fontfamily'], 'font.serif':self.fig_format['fontname'], 'font.weight':self.fig_format['fontweight'],'font.size': self.fig_format['fontsize'], 'text.usetex': self.fig_format['use_LaTex'], 'text.latex.preamble':r"\usepackage{bm}"})
            #matplotlib.rcParams.update({'font.family': self.fig_format['fontfamily'], 'font.serif':self.fig_format['fontname'], 'font.weight':self.fig_format['fontweight'],'font.size': self.fig_format['fontsize'], 'text.usetex': self.fig_format['use_LaTex'], 'text.latex.preamble':r'\boldmath'})
        elif self.fig_format['fontweight'].lower() == 'bold' and not self.fig_format['use_LaTex']:
            matplotlib.rcParams.update({'font.family': self.fig_format['fontfamily'], 'font.serif':self.fig_format['fontname'], 'font.weight':self.fig_format['fontweight'],'font.size': self.fig_format['fontsize'], 'text.usetex': self.fig_format['use_LaTex'], 'mathtext.fontset':'custom'})
        else:
            matplotlib.rcParams.update({'font.family': self.fig_format['fontfamily'], 'font.serif':self.fig_format['fontname'], 'font.weight':self.fig_format['fontweight'],'font.size': self.fig_format['fontsize'], 'text.usetex': self.fig_format['use_LaTex']})

        # Custom font for mathtext
        if self.fig_format['mathtext_fontname'] != None:
            # The folloiwng lines changes the latext font to a custom font
            # Source: http://stackoverflow.com/questions/11367736/matplotlib-consistent-font-using-latex
            # http://matplotlib.org/users/mathtext.html#fonts
            matplotlib.rcParams.update({'mathtext.fontset':'custom', 'mathtext.rm':self.fig_format['mathtext_fontname'], 'mathtext.it':self.fig_format['mathtext_fontname'] + ':italic', 'mathtext.bf':self.fig_format['mathtext_fontname'] + ':bold'})


    def __setattr__(self,attr_name,attr_value):
        """
        Redefines funciton __setattr__
        INPUTS:
        -------
        attr_name: Attribute name
        attr_value: Attribute value
        """
        if attr_name.lower() == 'title' and not isinstance(attr_value,str):
            raise TypeError('title must be a string')
 
        if attr_name.lower() == 'title_format' and not isinstance(attr_value,dict):
            raise TypeError('title_format must be a dictionary')
        elif attr_name.lower() == 'title_format' and len([k for k in attr_value.keys() if k.lower() not in ['fontname','fontweight','fontsize','distance_from_graph']]) > 0: 
            raise ValueError('Unknown key(s) for label_format: {}'.format([k for k in attr_value.keys() if k.lower() not in ['fontname','fontweight','fontsize','distance_from_graph']]))
 
        if attr_name.lower() == 'xaxis' and attr_value != None and not isinstance(attr_value,axis):
            raise TypeError('xaxis must be either None or an instance of class axis')
        if attr_name.lower() == 'yaxis' and attr_value != None and not isinstance(attr_value,axis):
            raise TypeError('yaxis must be either None or an instance of class axis')
        if attr_name.lower() == 'zaxis' and attr_value != None and not isinstance(attr_value,axis):
            raise TypeError('zaxis must be either None or an instance of class axis')
 
        # Gridlines
        if attr_name.lower() == 'plot_gridlines' and not isinstance(attr_value,bool):
            raise TypeError('plot_gridlines must be either True or False')
 
        if attr_name.lower() == 'gridlines_format' and not isinstance(attr_value,dict):
            raise TypeError('gridlines_format must be a dictionary')
        elif attr_name.lower() == 'gridlines_format' and len([k for k in attr_value.keys() if k.lower() not in ['color', 'linestyle', 'linewidth']]) > 0: 
            raise ValueError('Unknown key(s) for label_format: {}'.format([k for k in attr_value.keys() if k.lower() not in ['color', 'linestyle', 'linewidth']]))

        # Legend
        if attr_name.lower() == 'show_legend' and not isinstance(attr_value,bool):
            raise TypeError('show_legend must be either True or False')

        if attr_name.lower() == 'legend_format' and attr_value != None and not isinstance(attr_value,dict):
           raise TypeError('legend_format must be a dicitionary')
        elif attr_name.lower() == 'legend_format' and attr_value != None and len([k for k in attr_value.keys() if k not in ['location','fontname','fontsize','fontweight','linewidth','frame_linewidth', 'frame_linecolor','bbox_to_anchor', 'save_in_separate_figure', 'output_filename']]) > 0:
            raise ValueError('Invalid key(s) for legend_format: {}. Allowed keys are: [location, fontsize,fontweight,linewidth, bbox_to_anchor, save_in_separate_figure, output_filename]'.format([k for k in attr_value.keys() if k not in ['location','fontname','fontsize','fontweight','linewidth','frame_linewidth', 'frame_linecolor', 'bbox_to_anchor', 'save_in_separate_figure', 'output_filename']]))

        # Figure format
        if attr_name.lower() == 'fig_format' and not isinstance(attr_value,dict):
            raise TypeError('fig_format must be a dictionary')
        elif attr_name.lower() == 'fig_format' and len([k for k in attr_value.keys() if k.lower() not in ['figsize','fontname','fontsize','fontweight','use_tight_layout','use_equal_scale','dpi','use_latex','mathtext_fontname']]) > 0:
            raise ValueError('Unknown key(s) for fig_format: {}. Allowed keys include [figsize,use_tight_layout,dpi,use_latex]'.format([k for k in attr_value.keys() if k.lower() not in ['figsize','fontname','fontsize','fontweight','use_tight_layout','use_equal_scale','dpi','use_latex','mathtext_fontname']])) 
 
        # plot_type
        if attr_name.lower() == 'plot_type' and attr_value != None and not isinstance(attr_value,str):
            raise TypeError('plot_type must be a string')
        if attr_name.lower() == 'plot_type' and attr_value != None and attr_value.lower() not in ['heatmap', '2d_line', '3d']:
            raise ValueError('Invalid plot_type: {}. Allowed choices are: heatmap, 2d_line, 3d'.format(attr_value))
 
        if attr_name.lower() == 'output_filename' and not isinstance(attr_value,str):
            raise TypeError('output_filename must be a string')

        # Color bar
        if attr_name.lower() == 'clrbar' and not isinstance(attr_value, color_bar):
            raise TypeError('clorbar must be an instance of color_bar')

        self.__dict__[attr_name] = attr_value

    def plot2D(self, x, y, xerror = None, yerror = None, sort_data = False, label = '', line_format = {'color':None, 'width': 3, 'style': '-'}, show_markers = False, markers_format = {'style':'o','size':2,'facecolor':None,'edgewidth':None, 'edgecolor': None}, errorbars_format = {'color': None, 'linewidth':1, 'capsize':6, 'capthick':None}, twinX = False, create_new_figure = True, save_current = True):
        """
        Creates a 2D line plot

        INPUTS:
        ------
        x: 
        x values (q list or a numpy array). NOTE: x values must be ordered

        y: 
        y values (a list or a numpy array)

        xerror, yerror:
        Errors for x and y values. They can be a scalar, a 1xN or 2xN array
        If a scalar or an 1xNN array, errorbars are drawn at +/-value relative to the data.
        If a sequence of shape 2xN, errorbars are drawn at -row1 and +row2 relative to the data.

        sorte_data: 
        If True, x is sorted and y is sorted according to the softed x

        label: 
        Label (legend text) for the current plotted line. The format of the label
        is specified for the legend

        line_format: 
        Line properties. This is a dicitonary with keys including 'style', 'color', 'width'

        show_markers: 
        Indicates whether to show the markers

        markers_format: 
        A dictionary containing the markers format information 

        errorbars_format:
        Format of errobars. See errobar docs for more info

        spines_format: 
        Format axes and graph's border lines

        save_current: 
        If True, runs customize_and_save at the end. This parameter can be set to 
        False if this funciton is going to run for multiple datasets, where one 
        wants to make several line plots in the same figure and save the final 
        figure at the end. 


        NOTE:
        errobar doc: http://matplotlib.org/api/axes_api.html#matplotlib.axes.Axes.errorbar
        """
        self._plot_type = '2d_line' 

        # x and y 
        if isinstance(x,list):
            x = np.array(x)
        elif not isinstance(x,np.ndarray):
            raise TypeError('x must be either a list or a numpy array')
        if isinstance(y,list):
            y = np.array(y)
        elif not isinstance(y,np.ndarray):
            raise TypeError('y must be either a list or a numpy array')
        # Make sure x andy are of the same size
        if x.shape != y.shape:
            raise userError('x and y are of the same size. size of x is: {}, size of of y is: {}'.format(x.shape,y.shape))
        # Sort x and accordingly y
        if sort_data:
            data_dict = dict([(x[i],y[i]) for i in range(x.shape[0])])
            X = np.array(sorted(data_dict.keys()))
            Y = np.array([data_dict[xx] for xx in X])
        else:
            X, Y = x, y 

        # error bars 
        if isinstance(xerror, list):
            xerror = np.array(xerror)
        if xerror != None and not isinstance(xerror, int) and not isinstance(xerror, float) and not isinstance(xerror, np.ndarray):
            raise TypeError('xerror must be a non-negative scalar or a one- or two-diimensional array-like object')
        elif xerror != None and (isinstance(xerror, int) or isinstance(xerror, float)) and xerror < 0:
            raise ValueError('xerror must be a non-negative')
        elif xerror != None and isinstance(xerror, np.ndarray) and xerror.shape != (max(X.shape),) and xerror.shape != (2, max(X.shape)):
            raise ValueError('xerror must be a 1xN or 2xN array, where N is the size of x: xerror.shape = {} , (max(X.shape),) = {}'.format(xerror.shape, (max(X.shape),)))       

        if isinstance(yerror, list):
            yerror = np.array(yerror)
        if yerror != None and not isinstance(yerror, int) and not isinstance(yerror, float) and not isinstance(yerror, np.ndarray):
            raise TypeError('yerror must be a non-negative scalar or a one- or two-diimensional array-like object')
        elif yerror != None and (isinstance(yerror, int) or isinstance(yerror, float)) and yerror < 0:
            raise ValueError('yerror must be a non-negative')
        elif yerror != None and isinstance(yerror, np.ndarray) and yerror.shape != (max(Y.shape),) and yerror.shape != (2, max(Y.shape)): 
            raise ValueError('yerror must be a 1xN or 2xN array, where N is the size of y: yerror.shape = {}, (max(Y.shape),) = {}'.format(yerror.shape, (max(Y.shape),)))       
         
        # label
        if not isinstance(label,str):
            raise TypeError('lable must be a string')

        # Whether to save the current figure
        if not isinstance(save_current,bool):
            raise TypeError('save_current must be either True or False')        
    
        # line format
        if not isinstance(line_format,dict):
           raise TypeError('line_format must be a dicitionary. A {} was provided'.format(type(line_format)))
        elif len([k for k in line_format.keys() if k not in ['color','width','style']]) > 0:
            raise ValueError('Invalid key(s) for line_format: {}. Allowed keys are: [color,width,style]'.format([k for k in line_format.keys() if k not in ['color','width','style']]))
    
        if 'width' not in line_format.keys():
            line_format['width'] = 2
        if 'color' not in line_format.keys():
            line_format['color'] = None
        if 'style' not in line_format.keys():
            line_format['style'] = '-'
    
        # markers
        if not isinstance(show_markers,bool):
            raise TypeError('show_markers must be either True or False')
        if not isinstance(markers_format,dict):
           raise TypeError('markers_format must be a dicitionary')
        elif len([k for k in markers_format.keys() if k not in ['style','size','facecolor','edgewidth','edgecolor']]) > 0:
            raise ValueError('Invalid key(s) for markers_format: {}. Allowed keys are: [style,size,facecolor,edgewidth,edgecolor]'.format([k for k in markers_format.keys() if k not in ['style','size','facecolor','edgewidth','edgecolor']]))
    
        if markers_format == None:
            markers_format = {'style':'o','size':2,'facecolor':None,'edgewidth':None, 'edgecolor': None}
        if 'style' not in markers_format.keys():
            markers_format['style'] = 'o'
        if 'size' not in markers_format.keys():
            markers_format['size'] = 2
        if 'facecolor' not in markers_format.keys():
            markers_format['facecolor'] = None
        if 'edgewidth' not in markers_format.keys():
            markers_format['edgewidth'] = None
        if 'edgecolor' not in markers_format.keys():
            markers_format['edgecolor'] = None

        # Errobars format
        if not isinstance(errorbars_format, dict):
            raise TypeError('errorbars_format must be a dictionary')
        if 'color' not in errorbars_format.keys():
            errorbars_format['color'] = None
        if 'linewidth' not in errorbars_format.keys():
            errorbars_format['linewidth'] = 1
        if 'capsize' not in errorbars_format.keys():
            errorbars_format['capsize'] = 6
        if 'capthick' not in errorbars_format.keys():
            errorbars_format['capthick'] = None

        # create_new_figure
        if not isinstance(create_new_figure, bool):
            raise TypeError('create_new_figure must be eithter True or False')

        # save_current_figure
        if not isinstance(save_current, bool):
            raise TypeError('save_current must be eithter True or False')

        if create_new_figure:
            self.fig, self.ax = plt.subplots(figsize = self.fig_format['figsize'])

        #--- Make the plot ----    
        if show_markers:
            self.ax.plot(X, Y, label = label, color = line_format['color'], linewidth = line_format['width'], linestyle = line_format['style'], marker = markers_format['style'], markersize = markers_format['size'], markerfacecolor = markers_format['facecolor'], markeredgewidth = markers_format['edgewidth'], markeredgecolor = markers_format['edgecolor'])  
        else:
            self.ax.plot(X, Y, label = label, color = line_format['color'], linewidth = line_format['width'], linestyle = line_format['style'])  
     
        if xerror != None or yerror != None:
            (_, caps, _) = self.ax.errorbar(X, Y, xerr = xerror, yerr = yerror, linewidth = 0, ecolor = errorbars_format['color'], elinewidth = errorbars_format['linewidth'], capsize = errorbars_format['capsize'], capthick = errorbars_format['capthick'])  
            # Set the tickness of caps. if markers_format['edgewidth'] is provided, even if it is None, capthick does not work
            # Source: http://stackoverflow.com/questions/7601334/how-to-set-the-line-width-of-error-bar-caps-in-matplotlib
            for cap in caps:
                cap.set_markeredgewidth(errorbars_format['capthick'])

        # Save the current figure         
        if save_current:
            self.customize_and_save()


    def bar(self, orientation = 'Vertical', bars_x_coordinate = None, bars_y_coordinate = None, bars_height = None, bars_width = 0.8, bars_bottom_pos = None, bars_left_pos = None, xerror = None, yerror = None, bars_format = {'color': None, 'edgecolor':None, 'linewidth': 1, 'opacity':1}, errorbars_format = {'color': None, 'linewidth':1, 'capsize':6, 'capthick':None}, legend_text = '', legend_titme = '', create_new_figure = True, save_current = True):
        """
        Makes a bar plot of categorical data
        See: http://matplotlib.org/api/pyplot_api.html

        This function makea a bar plot with rectangles bounded by:
        bars_left_pos, bars_left_pos + bars_width, bars_bottom_pos, bars_bottom_pos + bar_height
        (left, right, bottom and top edges)

        INPUTS:
        -------
        orientation: Vertical or Horizonal bar graph
 
        bars_x_coordinate and bars_y_coordinate:
        The x coordinate of bars for matplotlib.bar() and 
        the y coordinate of bars for matplotlib.barh()

        bars_height, bars_width, bars_bottom_pos, bars_left_pos = None:
        bars_height, bars_width correspond to width and height and matplotlib.bar() and matplotlib.barh()
        bars_bottom_pos corresponds to bottom in matplotlib.bar()
        bars_left_pos corresponds to left in matplotlib.bar() 

        save_current: 
        If True, runs customize_and_save at the end. This parameter can be set to 
        False if this funciton is going to run for multiple datasets, where one 
        wants to make several line plots in the same figure and save the final 
        figure at the end. 
        """
        self._plot_type = '2d_bar' 

        # orientation
        if orientation is not None and not isinstance(orientation, str):
            raise TypeError('orientation for bar plot must be a string') 
        elif orientation is not None and orientation.lower() not in ['vertical', 'horizontal']: 
            raise ValueError('The value of orientation for bar plot must be either Vertical or Horizontal') 

        # bars_x_coordinate, bars_y_coordinate, bars_left_pos
        props = {'bars_x_coordinate':bars_x_coordinate, 'bars_y_coordiante': bars_y_coordinate}
        for prop in props.keys():
            if props[prop] is not None and not isinstance(props[prop], list) and not isinstance(props[prop], tuple) and not isinstance(props[prop], np.ndarray):
                raise TypeError('{} must be a list, tuple or numpy array of scalars'.format(prop)) 
            if isinstance(props[prop], list) or isinstance(props[prop], tuple):
                props[prop] = np.array(props[prop])

         # bars height, width left position and bottom position
        if orientation.lower() == 'vertical':
            # bars_height must be an array
            if bars_height is not None and not isinstance(bars_height, list) and not isinstance(bars_height, tuple) and not isinstance(bars_height, np.ndarray):
                raise TypeError('bars_height must be a list, tuple or numpy array of scalars') 
            if bars_height is not None and isinstance(bars_height, list) or isinstance(bars_height, tuple):
                bars_height = np.array(bars_height)
            if bars_height is not None and len(bars_height) != len(bars_x_coordinate):
                raise userError('length of bar_left pos = {} is not equal to the length of bars_height = {}'.format(len(bars_left_pos), len(bars_height)))

            # bars_width and bars_bottom_pos must be scalars
            props = {'bars_width':bars_width, 'bars_bottom_pos': bars_bottom_pos}
            for prop in props.keys():
                if props[prop] is not None and not isinstance(props[prop], int) and not isinstance(props[prop], float):
                    raise TypeError('{} must be None or a scalar'.format(prop))
                elif props[prop] != None and props[prop] <= 0:
                    raise ValueError('{} must be a positive scalar'.format(prop))

        if orientation.lower() == 'horizontal':
            # bars_width must be an array
            if bars_width is not None and not isinstance(bars_width, list) and not isinstance(bars_width, tuple) and not isinstance(bars_width, np.ndarray):
                raise TypeError('bars_width must be a list, tuple or numpy array of scalars') 
            if bars_width is not None and isinstance(bars_width, list) or isinstance(bars_width, tuple):
                bars_width = np.array(bars_width)
            if bars_width is not None and len(bars_width) != len(bars_y_coordinate):
                raise userError('length of bar_left pos = {} is not equal to the length of bars_width = {}'.format(len(bars_left_pos), len(bars_width)))


            # bars_height and bars_left_pos must be scalars
            props = {'bars_height':bars_height, 'bars_left_pos': bars_left_pos}
            for prop in props.keys():
                if props[prop] is not  None and not isinstance(props[prop], int) and not isinstance(props[prop], float):
                    raise TypeError('{} must be None or a scalar'.format(prop))
                elif props[prop] != None and props[prop] <= 0:
                    raise ValueError('{} must be a positive scalar'.format(prop))
        
        # error bars 
        if isinstance(xerror, list):
            xerror = np.array(xerror)
        if xerror != None and not isinstance(xerror, int) and not isinstance(xerror, float) and not isinstance(xerror, np.ndarray):
            raise TypeError('xerror must be a non-negative scalar or a one- or two-diimensional array-like object')
        elif xerror != None and (isinstance(xerror, int) or isinstance(xerror, float)) and xerror < 0:
            raise ValueError('xerror must be a non-negative')
        elif xerror != None and isinstance(xerror, np.ndarray) and xerror.shape != (max(bars_left_pos.shape),) and xerror.shape != (2, max(bars_left_pos.shape)):
            raise ValueError('xerror must be a 1xN or 2xN array, where N is the size of x: xerror.shape = {} , (max(X.shape),) = {}'.format(xerror.shape, (max(bars_left_pos.shape),)))       

        if isinstance(yerror, list):
            yerror = np.array(yerror)
        if yerror != None and not isinstance(yerror, int) and not isinstance(yerror, float) and not isinstance(yerror, np.ndarray):
            raise TypeError('yerror must be a non-negative scalar or a one- or two-diimensional array-like object')
        elif yerror is not None and (isinstance(yerror, int) or isinstance(yerror, float)) and yerror < 0:
            raise ValueError('yerror must be a non-negative')
        elif yerror is not None and isinstance(yerror, np.ndarray) and yerror.shape != (max(bars_left_pos.shape),) and yerror.shape != (2, max(bars_left_pos.shape)): 
            raise ValueError('yerror must be a 1xN or 2xN array, where N is the size of y: yerror.shape = {}, (max(Y.shape),) = {}'.format(yerror.shape, (max(bars_left_pos.shape),)))       

        if not isinstance(errorbars_format, dict):
            raise TypeError('errorbars_format must be a dictionary')
        if 'color' not in errorbars_format.keys():
            errorbars_format['color'] = None
        if 'linewidth' not in errorbars_format.keys():
            errorbars_format['linewidth'] = 1
        if 'capsize' not in errorbars_format.keys():
            errorbars_format['capsize'] = 6
        if 'capthick' not in errorbars_format.keys():
            errorbars_format['capthick'] = None

        # bars format
        if not isinstance(bars_format, dict):
            raise TypeError('bars_format must be a dictionary')
        if 'color' not in bars_format.keys():
            bars_format['color'] = None
        if 'edgecolor' not in bars_format.keys():
            bars_format['edgecolor'] = None
        if 'linewidth' not in bars_format.keys():
            bars_format['linewidth'] = 1
        if 'opacity' not in bars_format.keys():
            bars_format['opacity'] = 1

        # legend
        if not isinstance(legend, str):
            raise TypeError('legend must be a string')

        # create_new_figure
        if not isinstance(create_new_figure, bool):
            raise TypeError('create_new_figure must be eithter True or False')

        # save_current_figure
        if not isinstance(save_current, bool):
            raise TypeError('save_current must be eithter True or False')

        if create_new_figure:
            self.fig, self.ax = plt.subplots(figsize = self.fig_format['figsize'])
            self._barplot_objects = []
            self._barplot_legends = []

        if orientation.lower() == 'vertical':
            barplot = self.ax.bar(bars_x_coordinate, height = bars_height, width = bars_width, bottom = bars_bottom_pos, xerr = xerror, yerr = yerror, color = bars_format['color'], alpha = bars_format['opacity'],  edgecolor = bars_format['edgecolor'], linewidth = bars_format['linewidth'], error_kw = dict(ecolor = errorbars_format['color'], elinewidth = errorbars_format['linewidth'], capsize = errorbars_format['capsize'], capthick = errorbars_format['capthick'])) 
        elif orientation.lower() == 'horizontal':
            barplot = self.ax.barh(bars_y_coordinate, width = bars_width, height = bars_height, left = bars_left_pos, xerr = xerror, yerr = yerror, color = bars_format['color'], alpha = bars_format['opacity'],  edgecolor = bars_format['edgecolor'], linewidth = bars_format['linewidth'], error_kw = dict(ecolor = errorbars_format['color'], elinewidth = errorbars_format['linewidth'], capsize = errorbars_format['capsize'], capthick = errorbars_format['capthick'])) 

        if legend != '':
            self._legend_handles.append(barplot[0])
            self._legend_labels.append(legend)
        self._legend_title = legend_title

        # Save the current figure         
        if save_current:
            self.customize_and_save()

    def plot3D(self, x, y, z, sort_data = False, plot_func = 'plot_trisurf', line_format = {'color':None, 'width': 3, 'style': '-'}, clrbar = None, save_current = True):
        """
        Creates a 3D line plot

        INPUTS:
        ------
                     x: x values (q list or a numpy array). NOTE: x values must be ordered
                     y: y values (a list or a numpy array)
                     z: z values (a list or a numpy array)
            sorte_data: If True, x is sorted and y is sorted according to the softed x
             plot_func: 3D plot function to use. Allowed choices are plot, scatter, plot_wireframe,
                        plot_surface, plot_trisurf, contour, contourf,quiver  
           line_format: Line properties. This is a dicitonary with keys including 'style', 'color', 'width'
                clrbar: An instance of class colorbar 
        save_current: If True runs customize_and_save at the end. This parameter can be set to False if this funciton
                      is going to run for multiple datasets, where one wants to make several line plots in the same figure
                      and save the final figure at the end. 

        Sources:
        http://matplotlib.org/mpl_toolkits/mplot3d/tutorial.html
        http://stackoverflow.com/questions/21161884/plotting-a-3d-surface-from-a-list-of-tuples-in-matplotlib
        """
        from mpl_toolkits.mplot3d import Axes3D

        self._plot_type = '3d' 

        # x, y and z 
        if isinstance(x,list):
            x = np.array(x)
        elif not isinstance(x,np.ndarray):
            raise TypeError('x must be either a list or a numpy array')
        if isinstance(y,list):
            y = np.array(y)
        elif not isinstance(y,np.ndarray):
            raise TypeError('y must be either a list or a numpy array')
        if isinstance(z,list):
            z = np.array(z)
        elif not isinstance(z,np.ndarray):
            raise TypeError('z must be either a list or a numpy array')
        # Make sure x andy are of the same size
        if x.shape != y.shape or x.shape != z.shape or y.shape != z.shape:
            raise userError('x, y and z are not of the same size. size of x is: {}, size of of y is: {}, size of z is: {}'.format(x.shape,y.shape,z.shape))

        # Sort x and accordingly y
        if sort_data:
            data_dict = dict([((x[i],y[i]), z[i]) for i in range(x.shape[0])])
            # Here, we first sort x and then find the y values corresponding to the sorted x
            # Next, we sort y and find the z values corresponidng ot sorted y
            sorted_x_y = sorted(data_dict.keys() , key = lambda m:(m[0],m[1]))
            X = np.array([s[0] for s in sorted_x_y]) 
            Y = np.array([s[1] for s in sorted_x_y]) 
            Z = np.array([data_dict[xy] for xy in sorted_x_y])
        else:
            X, Y, Z = x, y, z 

        # plot_func
        if not isinstance(plot_func,str):
            raise TypeError('plot_func must be a string')
        elif plot_func not in ['plot', 'scatter', 'plot_wireframe', 'plot_surface', 'plot_trisurf', 'contour', 'contourf','quiver']:
            raise ValueError('Invalid plot_func value! Allowed choices are [plot, scatter, plot_wireframe, plot_surface, plot_trisurf, contour, contourf,quiver]')

        # line format
        if not isinstance(line_format,dict):
           raise TypeError('line_format must be a dicitionary. A {} was provided'.format(type(line_format)))
        elif len([k for k in line_format.keys() if k not in ['color','width','style']]) > 0:
            raise ValueError('Invalid key(s) for line_format: {}. Allowed keys are: [color,width,style]'.format([k for k in line_format.keys() if k not in ['color','width','style']]))
    
        if 'width' not in line_format.keys():
            line_format['width'] = 2
        if 'color' not in line_format.keys():
            line_format['color'] = None
        if 'style' not in line_format.keys():
            line_format['style'] = '-'
    
        # Color bar
        self.clrbar = clrbar
        if self.clrbar.colorlimits == None:
            clrbar.colorlimits = (z.min(),z.max())

        self.fig = plt.figure(figsize = self.fig_format['figsize'])
        self.ax = self.fig.gca(projection='3d')

        #------ plot_trisurf -------
        self.ax.plot_trisurf(X, Y, Z, linewidth = line_format['width'], linestyle = line_format['style'], cmap = clrbar.colormap, vmin = clrbar.colorlimits[0], vmax = clrbar.colorlimits[1])

        plt.draw()

    def heatmap(self, x, y, data, plot_func = 'pcolor', interpolate = False, clrbar = None):
        """
        Creates a heatmap of data 
     
        INPUTS:
        ------
                  x: horizontal axis data (list or numpy array)
                  y: Vertical axis data (list or numpy array)
               data: 2-D numpy array where ROWS correspond to data on VERTIACAL axis and COLUMNS correspond to data on
                     HORIZONTAL axis.
          plot_func: Eligible choices are 'pcolor', 'pcolormesh', 'matshow', 'imshow'
             clrbar: An instance of class colorbar 
        interpolate: Interpolate data (applicable only to matshow and imshow)
        """
        self.fig, self.ax = plt.subplots(figsize = self.fig_format['figsize'])

        self._plot_type = 'heatmap'
    
        if clrbar == None:
            clrbar = color_bar()
        self.clrbar = clrbar

        # Color bar
        if self.clrbar.colorlimits == None:
            self.clrbar.colorlimits = (data.min(),data.max())
 
        # If you like to have ticklabels placed in the middle of ticks (e.g., in a discerete colormap for pcolor 
        # and pcolormesh), use: vmin = data.min() - 0.5 and vmax = data.max() + 0.5. 
        if self.clrbar.ticklabels_format['ticks_position'] == 'middle':
            (vmin,vmax) = (self.clrbar.colorlimits[0] - 0.5, self.clrbar.colorlimits[1] + 0.5)
        else:
            (vmin,vmax) = (self.clrbar.colorlimits[0], self.clrbar.colorlimits[1])

        #------------ pcolor and pcolormesh ----------------
        if plot_func.lower() in ['pcolor','pcolormesh']:
            if plot_func.lower() == 'pcolor':
                pc = self.ax.pcolor(x,y,data, cmap = clrbar.colormap, vmin = vmin, vmax = vmax)
            elif plot_func.lower() == 'pcolormesh':
                pc = self.ax.pcolormesh(x,y,data, cmap = clrbar.colormap, vmin = vmin, vmax = vmax) 
    
            #-- colorbar --
            if clrbar.custom_ticklabels != None:
                # Source: http://stackoverflow.com/questions/14777066/matplotlib-discrete-colorbar
                # It's better to use self.clrbar.colorlimits[0] and self.clrbar.colorlimits[1] here
                # instead of min(data) and max(data) as sometimes the color bar might have more than one color (considering all possible cases)
                # but the actual data can have less than that, e.g., when considering a particular case
                #self.cbar = self.fig.colorbar(pc,ticks = np.arange(np.nanmin(data),np.nanmax(data)+1))
                self.cbar = self.fig.colorbar(pc,ticks = np.arange(self.clrbar.colorlimits[0], self.clrbar.colorlimits[1] + 1))
            else:
                self.cbar = self.fig.colorbar(pc, ticks = self.clrbar.custom_ticks)

        #------------ imshow and matshow ----------------
        elif plot_func.lower() in ['matshow','imshow']:
    
            if plot_func.lower() == 'matshow':
                if interpolate:
                    ms = self.ax.matshow(data, cmap = clrbar.colormap, vmin = vmin, vmax = vmax, interpolation = 'bilinear')
                else: 
                    ms = self.ax.matshow(data, cmap = clrbar.colormap, vmin = vmin, vmax = vmax)
    
            elif plot_func.lower() == 'imshow':
                if interpolate:
                    ms = self.ax.imshow(data, cmap = clrbar.colormap, vmin = clrbar.colorlimits[0], vmax = clrbar.colorlimits[1], interpolation = 'bilinear')
                else:
                    ms = self.ax.imshow(data, cmap = clrbar.colormap, vmin = clrbar.colorlimits[0], vmax = clrbar.colorlimits[1])

            #-- colorbar --
            if self.clrbar.custom_ticklabels != None:
                # Source: http://stackoverflow.com/questions/14777066/matplotlib-discrete-colorbar
                # It's better to use self.clrbar.colorlimits[0] and self.clrbar.colorlimits[1] here
                # instead of min(data) and max(data) as sometimes the color bar might have more than one color (considering all possible cases)
                # but the actual data can have less than that, e.g., when considering a particular case
                #self.cbar = self.fig.colorbar(ms,ticks = np.arange(np.nanmin(data),np.nanmax(data)+1))
                self.cbar = self.fig.colorbar(ms,ticks = np.arange(self.clrbar.colorlimits[0], self.clrbar.colorlimits[1] + 1))
            else:
                self.cbar = self.fig.colorbar(ms, ticks = self.clrbar.custom_ticks)

            #--- Put the major ticks at the middle of each cell (don't do this for pcolor and pcolormesh) ---
            # Source: http://stackoverflow.com/questions/14391959/heatmap-in-matplotlib-with-pcolor
            self.ax.set_xticks(np.arange(data.shape[1]), minor = False)
            self.ax.set_yticks(np.arange(data.shape[0]), minor = False)
    
            # Custom tick labels
            if self.xaxis.custom_ticklabels == None:
                self.xaxis.custom_ticklabels = [str(i) for i in x]
            if self.yaxis.custom_ticklabels == None:
                self.yaxis.custom_ticklabels = [str(i) for i in y]
    
        # Customize other properties of the plot
        self.customize_and_save()

    def pie(self, data, explode = None, labels = None, labeldistance = 1.1, colors = None, autopct = None, pctdistance = 0.6, shadow = True, startangle = 0, radius = None, wedgeprops = {'linewidth':1, 'edgecolor':'Black'}, textprops = {'name':figure_default_fontfamily, 'fontsize':figure_default_fontsize, 'weight':'regular', 'color':'black'}, frame = False, show_labels = True, legend_title = '', create_new_figure = True, save_current = True):
        """
        Plots a pie chart.

        Reference: https://matplotlib.org/api/_as_gen/matplotlib.pyplot.pie.html

        INPUTS:
        ------
        data:
        An array of floats or integers (list, tuple or numpy array)

        show_lables:
        IF True, labels are shown on the pie. You may want to not show the labels on the pie ubt 
        show them as the legend, in which case you need to provide lables but you set show_labels to False

        save_current: 
        If True, runs customize_and_save at the end. This parameter can be set to 
        False if this funciton is going to run for multiple datasets, where one 
        wants to make several line plots in the same figure and save the final 
        figure at the end. 

        For the rest of inputs see matplotlib pie chart manual (ref above)

        """
        self._plot_type = 'pie' 

        if create_new_figure:
            self.fig, self.ax = plt.subplots(figsize = self.fig_format['figsize'])

        if show_labels:
            pie_labels = labels
        
        (wedges, texts, autotexts) = self.ax.pie(data, explode = explode, labels = pie_labels, colors = colors, autopct = autopct, pctdistance = pctdistance, shadow = shadow, labeldistance = labeldistance, startangle = startangle, radius = radius, wedgeprops = wedgeprops, textprops = textprops, frame = frame)

        if self.show_legend:
            self._legend_handles = wedges
            if not isinstance(labels, list):
                raise TypeError('A list of strings must be provided for labels to appear in the legend')
            self._legend_labels = labels
        self._legend_title = legend_title

        # Save the current figure         
        if save_current:
            self.customize_and_save()

    def customize_and_save(self, customize_fig = True, save_fig = True):
        """
        This function customizes axes
        """
        if customize_fig:
            # Make the plot fill the picture
            if self.fig_format['use_tight_layout']:
                self.ax.set_aspect('auto')
                self.fig.tight_layout() 
    
            # Equal scale for axes
            if self.fig_format['use_equal_scale']:
                self.ax.set_aspect('equal', adjustable='box')
        
            #--- Axes limits ---
            if self.xaxis.limits != None: 
                self.ax.set_xlim([self.xaxis.limits[0],self.xaxis.limits[1]])
            if self.yaxis.limits != None: 
                self.ax.set_ylim([self.yaxis.limits[0],self.yaxis.limits[1]])
            if self._plot_type.lower() == '3d' and self.zaxis.limits != None:
                self.ax.set_zlim([self.zaxis.limits[0],self.zaxis.limits[1]])
    
            #---- Ticks and tick labels ---- 
            #-- Set the position of tick labels (top, bottom, left, right) --
            # x axis
            if self.xaxis.ticklabels_format['position'] != None and self.xaxis.ticklabels_format['position'].lower() == 'bottom':
                self.ax.xaxis.tick_bottom()
            elif self.xaxis.ticklabels_format['position'] != None and self.xaxis.ticklabels_format['position'].lower() == 'top':
                self.ax.xaxis.tick_top()
            elif self.xaxis.ticklabels_format['position'] != None and self.xaxis.ticklabels_format['position'].lower() not in ['bottom','top']:
                raise userError('Invalid ticklabels position for the x axis: {}. Allowed choices are top and bottom'.format(self.xaxis.ticklabels_format['position']))
    
            # y axis
            if self.yaxis.ticklabels_format['position'] != None and self.yaxis.ticklabels_format['position'].lower() == 'left':
                self.ax.yaxis.tick_left()
            elif self.yaxis.ticklabels_format['position'] != None and self.yaxis.ticklabels_format['position'].lower() == 'right':
                self.ax.yaxis.tick_right()
            elif self.yaxis.ticklabels_format['position'] != None and self.yaxis.ticklabels_format['position'].lower() not in ['left','right']:
                raise userError('Invalid ticklabels position for the y axis: {}. Allowed choices are left and right'.format(self.yaxis.ticklabels_format['position']))
    
            # z axis
            if self._plot_type.lower() == '3d':
                if self.zaxis.ticklabels_format['position'] != None and self.zaxis.ticklabels_format['position'].lower() == 'left':
                    self.ax.zaxis.tick_left()
                elif self.zaxis.ticklabels_format['position'] != None and self.zaxis.ticklabels_format['position'].lower() == 'right':
                    self.ax.zaxis.tick_right()
                elif self.zaxis.ticklabels_format['position'] != None and self.zaxis.ticklabels_format['position'].lower() not in ['left','right']:
                    raise userError('Invalid ticklabels position for the y axis: {}. Allowed choices are left and right'.format(self.zaxis.ticklabels_format['position']))
    
            #-- Set the alignment of tick labels ---
            # This can be used to make the ticklabels closer to the axes (useful for 3d plots)
            # Source: http://stackoverflow.com/questions/16061349/tick-label-positions-for-matplotlib-3d-plot  
            # x axis
            if self.xaxis.ticklabels_format['horizontalalignment'] != None:
                for ticklabel in self.ax.get_xmajorticklabels():
                    ticklabel.set_horizontalalignment(self.xaxis.ticklabels_format['horizontalalignment'])     
            if self.xaxis.ticklabels_format['verticalalignment'] != None:
                for ticklabel in self.ax.get_ymajorticklabels():
                    ticklabel.set_verticalalignment(self.xaxis.ticklabels_format['verticalalignment'])     
    
            # y axis
            if self.yaxis.ticklabels_format['horizontalalignment'] != None:
                for ticklabel in self.ax.get_ymajorticklabels():
                    ticklabel.set_horizontalalignment(self.yaxis.ticklabels_format['horizontalalignment'])     
            if self.yaxis.ticklabels_format['verticalalignment'] != None:
                for ticklabel in self.ax.get_ymajorticklabels():
                    ticklabel.set_verticalalignment(self.yaxis.ticklabels_format['verticalalignment'])     
    
            # z axis
            if self._plot_type.lower() == '3d':
                if self.zaxis.ticklabels_format['horizontalalignment'] != None:
                    for ticklabel in self.ax.get_zmajorticklabels():
                        ticklabel.set_horizontalalignment(self.zaxis.ticklabels_format['horizontalalignment'])     
                if self.zaxis.ticklabels_format['verticalalignment'] != None:
                    for ticklabel in self.ax.get_zmajorticklabels():
                        ticklabel.set_verticalalignment(self.zaxis.ticklabels_format['verticalalignment'])     
    
            #-- Set major and minor ticks and tick labels and their font properties --
            # Source: http://matplotlib.org/examples/pylab_examples/major_minor_demo1.html
            #- x ticks --
            # Set the font name and weight
            if 'fontname' not in self.xaxis.ticklabels_format.keys() or self.xaxis.ticklabels_format['fontname'] == None:
                self.xaxis.ticklabels_format['fontname'] = self.fig_format['fontname'] 
            if 'fontweight' not in self.xaxis.ticklabels_format.keys() or self.xaxis.ticklabels_format['fontweight'] == None:
                self.xaxis.ticklabels_format['fontweight'] = self.fig_format['fontweight']
    
            # Minor tick labels
            if self.xaxis.set_minorticks:
                if self.xaxis.minorticks_spacing != None:
                    x_minorLocator = MultipleLocator(self.xaxis.minorticks_spacing)
                    self.ax.xaxis.set_minor_locator(x_minorLocator)
                    if self.xaxis.ticklabels_format['string_format'] != None: 
                        x_minorFormatter = FormatStrFormatter(self.xaxis.ticklabels_format['string_format'])
                        self.ax.xaxis.set_minor_formatter(x_minorFormatter)
                for ticklabel in self.ax.get_xminorticklabels():
                    ticklabel.set_fontname(self.xaxis.ticklabels_format['fontname']) 
                    ticklabel.set_fontsize(self.xaxis.ticklabels_format['fontsize']) 
                    ticklabel.set_fontweight(self.xaxis.ticklabels_format['fontweight']) 
                    ticklabel.set_rotation(self.xaxis.ticklabels_format['rotation']) 
                    
            # Major tick labels
            if self.xaxis.majorticks_spacing != None:
                x_majorLocator = MultipleLocator(self.xaxis.majorticks_spacing)
                self.ax.xaxis.set_major_locator(x_majorLocator)
                if self.xaxis.ticklabels_format['string_format'] != None: 
                    x_majorFormatter = FormatStrFormatter(self.xaxis.ticklabels_format['string_format'])
                    self.ax.xaxis.set_major_formatter(x_majorFormatter)
            for ticklabel in self.ax.get_xmajorticklabels():
                ticklabel.set_fontname(self.xaxis.ticklabels_format['fontname']) 
                ticklabel.set_fontsize(self.xaxis.ticklabels_format['fontsize']) 
                ticklabel.set_fontweight(self.xaxis.ticklabels_format['fontweight']) 
                ticklabel.set_rotation(self.xaxis.ticklabels_format['rotation']) 
                
        
            #- y ticks --
            # Set the font name and weight
            if 'fontname' not in self.yaxis.ticklabels_format.keys() or self.yaxis.ticklabels_format['fontname'] == None:
                self.yaxis.ticklabels_format['fontname'] = self.fig_format['fontname'] 
            if 'fontweight' not in self.yaxis.ticklabels_format.keys() or self.yaxis.ticklabels_format['fontweight'] == None:
                self.yaxis.ticklabels_format['fontweight'] = self.fig_format['fontweight']
    
            # Minor tick labels
            if self.yaxis.set_minorticks:
                if self.yaxis.minorticks_spacing != None:
                    y_minorLocator = MultipleLocator(self.yaxis.minorticks_spacing)
                    self.ax.yaxis.set_minor_locator(y_minorLocator)
                    if self.yaxis.ticklabels_format['string_format'] != None: 
                        y_minorFormatter = FormatStrFormatter(self.yaxis.ticklabels_format['string_format'])
                        self.ax.yaxis.set_minor_formatter(y_minorFormatter)
                for ticklabel in self.ax.get_yminorticklabels():
                    ticklabel.set_fontname(self.yaxis.ticklabels_format['fontname']) 
                    ticklabel.set_fontsize(self.yaxis.ticklabels_format['fontsize']) 
                    ticklabel.set_fontweight(self.yaxis.ticklabels_format['fontweight']) 
                    ticklabel.set_rotation(self.yaxis.ticklabels_format['rotation']) 
               
            # Major tick labels
            if self.yaxis.majorticks_spacing != None:
                y_majorLocator = MultipleLocator(self.yaxis.majorticks_spacing)
                self.ax.yaxis.set_major_locator(y_majorLocator)
                if self.yaxis.ticklabels_format['string_format'] != None: 
                    y_majorFormatter = FormatStrFormatter(self.yaxis.ticklabels_format['string_format'])
                    self.ax.yaxis.set_major_formatter(y_majorFormatter)
            for ticklabel in self.ax.get_ymajorticklabels():
                ticklabel.set_fontname(self.yaxis.ticklabels_format['fontname']) 
                ticklabel.set_fontsize(self.yaxis.ticklabels_format['fontsize']) 
                ticklabel.set_fontweight(self.yaxis.ticklabels_format['fontweight']) 
                ticklabel.set_rotation(self.yaxis.ticklabels_format['rotation']) 
              
    
            #- z ticks --
            if self._plot_type.lower() == '3d':
                # Set the font name and weight
                if 'fontname' not in self.zaxis.ticklabels_format.keys() or self.zaxis.ticklabels_format['fontname'] == None:
                    self.zaxis.ticklabels_format['fontname'] = self.fig_format['fontname'] 
                if 'fontweight' not in self.zaxis.ticklabels_format.keys() or self.zaxis.ticklabels_format['fontweight'] == None:
                    self.zaxis.ticklabels_format['fontweight'] = self.fig_format['fontweight']
    
                # Minor tick labels
                if self.zaxis.set_minorticks:
                    if self.zaxis.minorticks_spacing != None:
                        z_minorLocator = MultipleLocator(self.zaxis.minorticks_spacing)
                        self.ax.zaxis.set_minor_locator(z_minorLocator)
                        if self.zaxis.ticklabels_format['string_format'] != None: 
                            z_minorFormatter = FormatStrFormatter(self.zaxis.ticklabels_format['string_format'])
                            self.ax.zaxis.set_minor_formatter(z_minorFormatter)
                    for ticklabel in self.ax.get_zminorticklabels():
                        ticklabel.set_fontname(self.zaxis.ticklabels_format['fontname']) 
                        ticklabel.set_fontsize(self.zaxis.ticklabels_format['fontsize']) 
                        ticklabel.set_fontweight(self.zaxis.ticklabels_format['fontweight']) 
                        ticklabel.set_rotation(self.zaxis.ticklabels_format['rotation']) 
                # Major tick labels
                if self.zaxis.majorticks_spacing != None:
                    z_majorLocator = MultipleLocator(self.zaxis.majorticks_spacing)
                    self.ax.zaxis.set_major_locator(z_majorLocator)
                    if self.zaxis.ticklabels_format['string_format'] != None: 
                        z_majorFormatter = FormatStrFormatter(self.zaxis.ticklabels_format['string_format'])
                        self.ax.zaxis.set_major_formatter(z_majorFormatter)
                for ticklabel in self.ax.get_zmajorticklabels():
                    ticklabel.set_fontname(self.zaxis.ticklabels_format['fontname']) 
                    ticklabel.set_fontsize(self.zaxis.ticklabels_format['fontsize']) 
                    ticklabel.set_fontweight(self.zaxis.ticklabels_format['fontweight']) 
                    ticklabel.set_rotation(self.yaxis.ticklabels_format['rotation']) 
    
            #--- Cutom ticks ---
            if self.xaxis.custom_ticks is not None:
                self.ax.set_xticks(self.xaxis.custom_ticks)
            if self.yaxis.custom_ticks is not None:
                self.ax.set_yticks(self.yaxis.custom_ticks)
            if self._plot_type.lower() == '3d' and  self.zaxis.custom_ticks != None:
                self.ax.set_zticks(self.zaxis.custom_ticks)
        
            #-- Custom tick labels --
            # x axis
            if self.xaxis.custom_ticklabels != None:
                self.ax.set_xticklabels(self.xaxis.custom_ticklabels, fontname = self.xaxis.ticklabels_format['fontname'], fontsize = self.xaxis.ticklabels_format['fontsize'], weight = self.xaxis.ticklabels_format['fontweight'])
    
            # y axis
            if self.yaxis.custom_ticklabels != None:
                self.ax.set_yticklabels(self.yaxis.custom_ticklabels, fontname = self.yaxis.ticklabels_format['fontname'], fontsize = self.yaxis.ticklabels_format['fontsize'], weight = self.yaxis.ticklabels_format['fontweight'])
    
            # z axis
            if self._plot_type.lower() == '3d' and self.zaxis.custom_ticklabels != None:
                self.ax.set_zticklabels(self.zaxis.custom_ticklabels, fontname = self.zaxis.ticklabels_format['fontname'], fontsize = self.zaxis.ticklabels_format['fontsize'], weight = self.zaxis.ticklabels_format['fontweight'])
    
            #---- Title and Axes labels ----
            # Title
            # distance_from_graph represents the distance between the title and the graph
            # Source: http://stackoverflow.com/questions/12750355/python-matplotlib-figure-title-overlaps-axes-label-when-using-twiny
            if self.title != '':    
                self.ax.set_title(self.title,{'fontname':self.title_format['fontname'], 'weight':self.title_format['fontweight'],'size':self.title_format['fontsize']}, y = self.title_format['distance_from_graph'])
    
            # x axis label
            if self.xaxis.label != '':    
                # Set fontname and font weight if they have not already provided
                if 'fontname' not in self.xaxis.label_format.keys() or self.xaxis.label_format['fontname'] == None:
                    self.xaxis.label_format['fontname'] = self.fig_format['fontname']
                if 'fontweight' not in self.xaxis.label_format.keys() or self.xaxis.label_format['fontweight'] == None:
                    self.xaxis.label_format['fontweight'] = self.fig_format['fontweight'] 
    
                if self.xaxis.label_format['distance_from_ticklabels'] != None: 
                    self.ax.set_xlabel(self.xaxis.label,{'fontname': self.xaxis.label_format['fontname'],'weight':self.xaxis.label_format['fontweight'],'size':self.xaxis.label_format['fontsize']}, labelpad = self.xaxis.label_format['distance_from_ticklabels'])
                else:
                    self.ax.set_xlabel(self.xaxis.label,{'fontname': self.xaxis.label_format['fontname'],'weight':self.xaxis.label_format['fontweight'],'size':self.xaxis.label_format['fontsize']})
    
            # y axis label
            if self.yaxis.label != '':    
                # Set fontname and font weight if they have not already provided
                if 'fontname' not in self.yaxis.label_format.keys() or self.yaxis.label_format['fontname'] == None:
                    self.yaxis.label_format['fontname'] = self.fig_format['fontname']
                if 'fontweight' not in self.yaxis.label_format.keys() or self.yaxis.label_format['fontweight'] == None:
                    self.yaxis.label_format['fontweight'] = self.fig_format['fontweight'] 
    
                if self.yaxis.label_format['distance_from_ticklabels'] != None: 
                    self.ax.set_ylabel(self.yaxis.label,{'fontname': self.yaxis.label_format['fontname'], 'weight':self.yaxis.label_format['fontweight'],'size':self.yaxis.label_format['fontsize']}, labelpad = self.yaxis.label_format['distance_from_ticklabels'])
                else:
                    self.ax.set_ylabel(self.yaxis.label,{'fontname': self.yaxis.label_format['fontname'],'weight':self.yaxis.label_format['fontweight'],'size':self.yaxis.label_format['fontsize']})
    
            # z axis label
            if self._plot_type.lower() == '3d' and self.zaxis.label != '':    
                # Set fontname and font weight if they have not already provided
                if 'fontname' not in self.zaxis.label_format.keys() or self.zaxis.label_format['fontname']  == None:
                    self.zaxis.label_format['fontname'] = self.fig_format['fontname']
                if 'fontweight' not in self.zaxis.label_format.keys() or self.zaxis.label_format['fontweight'] == None:
                    self.zaxis.label_format['fontweight'] = self.fig_format['fontweight'] 
    
                if self.zaxis.label_format['distance_from_ticklabels'] != None: 
                    self.ax.set_zlabel(self.zaxis.label,{'fontname': self.zaxis.label_format['fontname'], 'weight':self.zaxis.label_format['fontweight'],'size':self.zaxis.label_format['fontsize']}, labelpad = self.zaxis.label_format['distance_from_ticklabels'])
                else:
                    self.ax.set_zlabel(self.zaxis.label,{'fontname': self.zaxis.label_format['fontname'],'weight':self.zaxis.label_format['fontweight'],'size':self.zaxis.label_format['fontsize']})
    
            #-- Position of axes labels --
            # x axis
            if self.xaxis.label_format['position'] != None and self.xaxis.label_format['position'].lower() == 'top':
                self.ax.xaxis.set_label_position('top') 
            elif self.xaxis.label_format['position'] != None and self.xaxis.label_format['position'].lower() == 'bottom':
                self.ax.xaxis.set_label_position('bottom') 
            elif self.xaxis.label_format['position'] != None and self.xaxis.label_format['position'].lower() not in ['top','bottom']:
                raise ValueError('Invalid label position for the x axis: {}. Allowed choices are top and bottom'.format(self.xaxis.label_format['position']))
    
            # y axis
            if self.yaxis.label_format['position'] != None and self.yaxis.label_format['position'].lower() == 'right':
                self.ax.yaxis.set_label_position('right') 
            elif self.yaxis.label_format['position'] != None and self.yaxis.label_format['position'].lower() == 'left':
                self.ax.yaxis.set_label_position('left') 
            elif self.yaxis.label_format['position'] != None and self.yaxis.label_format['position'].lower() not in ['left','right']:
                raise ValueError('Invalid label position for the y axis: {}. Allowed choices are right and left'.format(self.yaxis.label_format['position']))
    
            # z axis
            if self._plot_type.lower() == '3d':
                if self.zaxis.label_format['position'] != None and self.zaxis.label_format['position'].lower() == 'right':
                    self.ax.zaxis.set_label_position('right') 
                elif self.zaxis.label_format['position'] != None and self.zaxis.label_format['position'].lower() == 'left':
                    self.ax.zaxis.set_label_position('left') 
                elif self.zaxis.label_format['position'] != None and self.zaxis.label_format['position'].lower() not in ['left','right']:
                    raise ValueError('Invalid label position for the z axis: {}. Allowed choices are right and left'.format(self.zaxis.label_format['position']))
    
            #---- Invert axis ----
            if self.xaxis.invert:
                self.ax.invert_xaxis()
            if self.yaxis.invert:
                self.ax.invert_yaxis()
            if self._plot_type.lower() == '3d' and self.zaxis.invert:
                self.ax.invert_zaxis()
    
            #--- Axes scales ----
            if self.xaxis.scale != None:
                self.ax.set_xscale(self.xaxis.scale)
            if self.yaxis.scale != None:
                self.ax.set_yscale(self.yaxis.scale)
            if self._plot_type.lower() == '3d' and self.zaxis.scale != None:
                self.ax.set_zscale(self.zaxis.scale)
    
            #---- Grid lines ----
            if self._plot_type.lower() != '3d':
                # Gridlines format
                # From: http://stackoverflow.com/questions/9127434/how-to-create-major-and-minor-gridlines-with-different-linestyles-in-python
                # From: http://stackoverflow.com/questions/17925545/adjusting-gridlines-on-a-3d-matplotlib-figure
                # gridlines_format = {'color':'k', 'linestyle':'dashed', 'linewidth':2}   
                if self.xaxis.plot_gridlines:
                    self.ax.xaxis.grid(True, color = self.xaxis.gridlines_format['color'], linestyle = self.xaxis.gridlines_format['linestyle'], linewidth = self.xaxis.gridlines_format['linewidth'])
                if self.yaxis.plot_gridlines:
                    self.ax.yaxis.grid(True, color = self.yaxis.gridlines_format['color'], linestyle = self.yaxis.gridlines_format['linestyle'], linewidth = self.yaxis.gridlines_format['linewidth'])
    
            else: 
                # for 1 3d plot
                # From: http://stackoverflow.com/questions/17925545/adjusting-gridlines-on-a-3d-matplotlib-figure
                if self.xaxis.plot_gridlines:
                    self.ax.w_xaxis.gridlines.set_lw(self.xaxis.gridlines_format['linewidth'])
                    self.ax.w_xaxis.gridlines.set_linestyle(self.xaxis.gridlines_format['linestyle'])
                    self.ax.w_xaxis._axinfo.update({'grid': {'color': self.xaxis.gridlines_format['color']}})
    
                if self.yaxis.plot_gridlines:
                    self.ax.w_yaxis.gridlines.set_linestyle(self.yaxis.gridlines_format['linestyle'])
                    self.ax.w_yaxis.gridlines.set_lw(self.yaxis.gridlines_format['linewidth'])
                    self.ax.w_yaxis._axinfo.update({'grid': {'color': self.yaxis.gridlines_format['color']}})
    
                if self.zaxis.plot_gridlines:
                    self.ax.w_zaxis.gridlines.set_lw(self.zaxis.gridlines_format['linewidth'])
                    self.ax.w_zaxis.gridlines.set_linestyle(self.zaxis.gridlines_format['linestyle'])
                    self.ax.w_zaxis._axinfo.update({'grid': {'color': self.zaxis.gridlines_format['color']}})
    
            #--- Legend ---
            # Source: http://matplotlib.org/api/legend_api.html
            # and     http://stackoverflow.com/questions/4700614/how-to-put-the-legend-out-of-the-plot
            if self.show_legend:
                if self.legend_format['save_in_separate_figure']:
                    #self._fig_lgd, self._ax_lgd = plt.subplots(figsize = self.fig_format['figsize'])
                    self._fig_lgd, self._ax_lgd = plt.subplots()
                    self._ax_lgd.axis('off')
                    if len(self._legend_handles) == 0:
                        # Get legend handles from the current axis
                        self._legend_handles, self._legend_labels = self.ax.get_legend_handles_labels() 

                    # If legend is going to be saved in a separate figure ignore set loc to 'center' and ignore bbox_to_anchor
                    self.legend_format['location'] = 'center'
                    self.legend_format['bbox_to_anchor'] = None 
                else:
                    self._ax_lgd = self.ax 

                if self.legend_format['bbox_to_anchor'] != None:
                    if len(self._legend_handles) > 0 and len(self._legend_labels) > 0:
                        self._lgd = self._ax_lgd.legend(self._legend_handles, self._legend_labels, title = self._legend_title, loc = self.legend_format['location'], prop = {'family': self.legend_format['fontname'], 'size': self.legend_format['fontsize'],'weight':self.legend_format['fontweight']},handlelength = self.legend_format['linewidth'], bbox_to_anchor = self.legend_format['bbox_to_anchor'], numpoints = 1)
                    else:
                        self._lgd = self._ax_lgd.legend(loc = self.legend_format['location'], prop = {'family': self.legend_format['fontname'], 'size': self.legend_format['fontsize'],'weight':self.legend_format['fontweight']},handlelength = self.legend_format['linewidth'], bbox_to_anchor = self.legend_format['bbox_to_anchor'], numpoints = 1)

                else:  # If bbox_to_anchor is not provided
                    if len(self._legend_handles) > 0 and len(self._legend_labels) > 0:
                        self._lgd = self._ax_lgd.legend(self._legend_handles, self._legend_labels, title = self._legend_title, loc = self.legend_format['location'], prop = {'family':self.legend_format['fontname'], 'size': self.legend_format['fontsize'],'weight':self.legend_format['fontweight']}, handlelength = self.legend_format['linewidth'], numpoints = 1)
                    else:
                        self._lgd = self._ax_lgd.legend(loc = self.legend_format['location'], prop = {'family':self.legend_format['fontname'], 'size': self.legend_format['fontsize'],'weight':self.legend_format['fontweight']},handlelength = self.legend_format['linewidth'], numpoints = 1)

                self._lgd.get_frame().set_linewidth(self.legend_format['frame_linewidth'])
                self._lgd.get_frame().set_edgecolor(self.legend_format['frame_linecolor'])
    
            #--- Set axes and borders (spines) properties ---
            # Set zorder to a large value so it is drawn after gridnlines (otherwise if you change the color of spiens, gridlines
            # will show on top of the spines)
            # Source: http://matplotlib.org/api/artist_api.html#matplotlib.artist.Artist.set_zorder
            # Bottom
            self.ax.spines['bottom'].set_zorder(10)
            if 'bottom' in self.xaxis.spines_format.keys():
                if 'linewidth' in  self.xaxis.spines_format['bottom'].keys():
                    self.ax.spines['bottom'].set_linewidth(self.xaxis.spines_format['bottom']['linewidth'])
                if 'linestyle' in  self.xaxis.spines_format['bottom'].keys():
                    self.ax.spines['bottom'].set_linestyle(self.xaxis.spines_format['bottom']['linestyle'])
                if 'linecolor' in  self.xaxis.spines_format['bottom'].keys():
                    self.ax.spines['bottom'].set_color(self.xaxis.spines_format['bottom']['linecolor'])
    
            # Top
            self.ax.spines['top'].set_zorder(10)
            if 'top' in self.xaxis.spines_format.keys():
                if 'linewidth' in  self.xaxis.spines_format['top'].keys():
                    self.ax.spines['top'].set_linewidth(self.xaxis.spines_format['top']['linewidth'])
                if 'linestyle' in  self.xaxis.spines_format['top'].keys():
                    self.ax.spines['top'].set_linestyle(self.xaxis.spines_format['top']['linestyle'])
                if 'linecolor' in  self.xaxis.spines_format['top'].keys():
                    self.ax.spines['top'].set_color(self.xaxis.spines_format['top']['linecolor'])
    
            # Left
            self.ax.spines['left'].set_zorder(10)
            if 'left' in self.yaxis.spines_format.keys():
                if 'linewidth' in  self.yaxis.spines_format['left'].keys():
                    self.ax.spines['left'].set_linewidth(self.yaxis.spines_format['left']['linewidth'])
                if 'linestyle' in  self.yaxis.spines_format['left'].keys():
                    self.ax.spines['left'].set_linestyle(self.yaxis.spines_format['left']['linestyle'])
                if 'linecolor' in  self.yaxis.spines_format['left'].keys():
                    self.ax.spines['left'].set_color(self.yaxis.spines_format['left']['linecolor'])
    
            # Right
            self.ax.spines['right'].set_zorder(10)
            if 'left' in self.yaxis.spines_format.keys():
                if 'linewidth' in  self.yaxis.spines_format['right'].keys():
                    self.ax.spines['right'].set_linewidth(self.yaxis.spines_format['right']['linewidth'])
                if 'linestyle' in  self.yaxis.spines_format['right'].keys():
                    self.ax.spines['right'].set_linestyle(self.yaxis.spines_format['right']['linestyle'])
                if 'linecolor' in  self.yaxis.spines_format['right'].keys():
                    self.ax.spines['right'].set_color(self.yaxis.spines_format['right']['linecolor'])
    
    
            #--- Customize colorbar ---
            if hasattr(self,'cbar'): 
                # Set font name and weight properties
                if 'fontname' not in self.clrbar.label_format.keys() or self.clrbar.label_format['fontname'] == None:
                    self.clrbar.label_format['fontname'] = self.fig_format['fontname']
                if 'fontweight' not in self.clrbar.label_format.keys() or self.clrbar.label_format['fontweight'] == None:
                    self.clrbar.label_format['fontweight'] = self.fig_format['fontweight']
    
                if 'fontname' not in self.clrbar.ticklabels_format.keys() or self.clrbar.ticklabels_format['fontname'] == None:
                    self.clrbar.ticklabels_format['fontname'] = self.fig_format['fontname']
                if 'fontweight' not in self.clrbar.ticklabels_format.keys() or self.clrbar.ticklabels_format['fontweight'] == None:
                    self.clrbar.ticklabels_format['fontweight'] = self.fig_format['fontweight']
    
                # Coloarbar label format
                if self.clrbar.label_format['distance_from_ticklabels'] != None: 
                    self.cbar.set_label(self.clrbar.label, family = self.clrbar.label_format['fontname'], size = self.clrbar.label_format['fontsize'], weight = self.clrbar.label_format['fontweight'], rotation = self.clrbar.label_format['rotation'], labelpad = self.clrbar.label_format['distance_from_ticklabels'])
                else:
                    self.cbar.set_label(self.clrbar.label, family = self.clrbar.label_format['fontname'], size = self.clrbar.label_format['fontsize'], weight = self.clrbar.label_format['fontweight'], rotation = self.clrbar.label_format['rotation'])
    
                # Set the position of tick labels (top, bottom, left, right)
                if self.clrbar.ticklabels_format['axis_position'] != None and self.clrbar.ticklabels_format['axis_position'].lower() == 'left':
                    self.cbar.ax.yaxis.tick_left()
                elif self.clrbar.ticklabels_format['axis_position'] != None and self.clrbar.ticklabels_format['axis_position'].lower() == 'right':
                    self.cbar.ax.yaxis.tick_right()
                elif self.clrbar.ticklabels_format['axis_position'] != None and self.clrbar.ticklabels_format['axis_position'].lower() not in ['left','right']:
                    raise userError('Invalid ticklabels position for the y axis: {}. Allowed choices are left and right'.format(self.clrbar.ticklabels_format['position']))
    
                #- Set major and minor ticks and tick labels -
                # ***The following disrupts the color limit for some reasons. Use custom ticks instead
                # Source: http://matplotlib.org/examples/pylab_examples/major_minor_demo1.html
                # Minor tick labels
                if self.clrbar.set_minorticks:
                    if self.clrbar.minorticks_spacing != None:
                        y_minorLocator = MultipleLocator(self.clrbar.minorticks_spacing)
                        self.cbar.ax.yaxis.set_minor_locator(y_minorLocator)
                        if self.clrbar.ticklabels_format['string_format'] != None: 
                            y_minorFormatter = FormatStrFormatter(self.clrbar.ticklabels_format['string_format'])
                            self.cbar.ax.yaxis.set_minor_formatter(y_minorFormatter)
                    for ticklabel in self.cbar.ax.get_yminorticklabels():
                        ticklabel.set_fontname(self.clrbar.ticklabels_format['fontname']) 
                        ticklabel.set_fontsize(self.clrbar.ticklabels_format['fontsize']) 
                        ticklabel.set_fontweight(self.clrbar.ticklabels_format['fontweight']) 
                        ticklabel.set_rotation(self.clrbar.ticklabels_format['rotation']) 
                # Major tick labels
                if self.clrbar.majorticks_spacing != None:
                    y_majorLocator = MultipleLocator(self.clrbar.majorticks_spacing)
                    self.cbar.ax.yaxis.set_major_locator(y_majorLocator)
                    if self.clrbar.ticklabels_format['string_format'] != None: 
                        y_majorFormatter = FormatStrFormatter(self.clrbar.ticklabels_format['string_format'])
                        self.cbar.ax.yaxis.set_major_formatter(y_majorFormatter)
                for ticklabel in self.cbar.ax.get_ymajorticklabels():
                    ticklabel.set_fontname(self.clrbar.ticklabels_format['fontname']) 
                    ticklabel.set_fontsize(self.clrbar.ticklabels_format['fontsize']) 
                    ticklabel.set_fontweight(self.clrbar.ticklabels_format['fontweight']) 
                    ticklabel.set_rotation(self.clrbar.ticklabels_format['rotation']) 
    
                # Custom ticks --> ** This doesn't work for some reasons. Use ticks when defining the colorbar instead 
                if self.clrbar.custom_ticks != None:
                    self.cbar.ax.set_yticks(self.clrbar.custom_ticks)
    
                # Custom tick labels 
                if self.clrbar.custom_ticklabels != None:
                    self.cbar.ax.set_yticklabels(self.clrbar.custom_ticklabels, fontsize = self.clrbar.ticklabels_format['fontsize'], weight = self.clrbar.ticklabels_format['fontweight'])
    
        #--- Save the figure ---
        if self.output_filename != '' and save_fig:
            # If bbox_inches = 'tight' is not included part of the axes labels may be cut off in the saved image
            # Similarly, using bbox_extra_artists is to save part of the legend that is cut off
            # Source: http://stackoverflow.com/questions/4700614/how-to-put-the-legend-out-of-the-plot
            if self.fig_format['dpi'] == None:
                if self.show_legend:
                    if self.legend_format['save_in_separate_figure']:
                        # Save the main plot
                        self.fig.savefig(self.output_filename, bbox_inches='tight')

                        # Save the legend in a separate figure
                        # Define legend bbox in order to remove white spaces around in the legend 
                        # Then we need to xxpand the legend bbox in order to avoid clipping the border lines 
                        # of the legend frame
                        # (x0, y0) = lower left corner points   (x1, y1) = upper right corner points
                        # Source: https://stackoverflow.com/questions/4534480/get-legend-as-a-separate-picture-in-matplotlib
                        lgd_bbox = self._lgd.get_window_extent().transformed(self._fig_lgd.dpi_scale_trans.inverted())
                        (x_ll, y_ll), (x_ur, y_ur) = lgd_bbox.get_points()
                        w, h = x_ur - x_ll, y_ur - y_ll
                        x_ll_exp, y_ll_exp = x_ur - w*1.1, y_ur - h*1.1 # Expand by a factor of 1.1 
                        x_ur_exp, y_ur_exp = x_ll + w*1.1, y_ll + h*1.1 # Expand by a factor of 1.1
                        lgd_bbox = matplotlib.transforms.Bbox(np.array(((x_ll_exp, y_ll_exp),(x_ur_exp, y_ur_exp))))
 
                        self._fig_lgd.savefig(self.legend_format['output_filename'], bbox_extra_artists=(self._lgd,), bbox_inches = lgd_bbox)
                    else:
                        self.fig.savefig(self.output_filename, bbox_extra_artists=(self._lgd,), bbox_inches='tight')
                else:
                    self.fig.savefig(self.output_filename, bbox_inches='tight')
            else:
                if self.show_legend:
                    if self.legend_format['save_in_separate_figure']:
                        # Save the main plot
                        self.fig.savefig(self.output_filename, dpi = self.fig_format['dpi'], bbox_inches='tight')

                        # Save the legend in a separate figure
                        # Define legend bbox in order to remove white spaces around in the legend 
                        # Then we need to xxpand the legend bbox in order to avoid clipping the border lines 
                        # of the legend frame
                        # (x0, y0) = lower left corner points   (x1, y1) = upper right corner points
                        # Source: https://stackoverflow.com/questions/4534480/get-legend-as-a-separate-picture-in-matplotlib
                        lgd_bbox = self._lgd.get_window_extent().transformed(self._fig_lgd.dpi_scale_trans.inverted())
                        (x_ll, y_ll), (x_ur, y_ur) = lgd_bbox.get_points()
                        w, h = x_ur - x_ll, y_ur - y_ll
                        x_ll_exp, y_ll_exp = x_ur - w*1.1, y_ur - h*1.1 # Expand by a factor of 1.1 
                        x_ur_exp, y_ur_exp = x_ll + w*1.1, y_ll + h*1.1 # Expand by a factor of 1.1
                        lgd_bbox = matplotlib.transforms.Bbox(np.array(((x_ll_exp, y_ll_exp),(x_ur_exp, y_ur_exp))))
 
                        self._fig_lgd.savefig(self.legend_format['output_filename'], dpi = self.fig_format['dpi'], bbox_extra_artists=(self._lgd,), bbox_inches = lgd_bbox)
                    else:
                        self.fig.savefig(self.output_filename, dpi = self.fig_format['dpi'], bbox_extra_artists=(self._lgd,), bbox_inches='tight')
                else:
                    self.fig.savefig(self.output_filename, dpi = self.fig_format['dpi'], bbox_inches='tight')

        # Use the following piece to find out what font matplotlib is actually using
        if False:
            font_family = matplotlib.rcParams['font.family']
            from matplotlib.font_manager import findfont, FontProperties
            font_name = findfont(FontProperties(family=['sans-serif']))
            print '\nmatplotlib used font_family = {}, font_name = {}\n'.format(font_family, font_name)

        # Use draw instead of show so the graph gets updated it this is run after customzie_and_save
        plt.draw()

 
    def add_text(self,text = '', text_format = {'x_pos':None, 'y_pos':None, 'fontsize':figure_default_fontsize, 'fontweight':figure_default_fontweight}):
        """
        Adds a text to the graph

        INPUTS:
        -------
               text: Text to be added to the graph
        text_format: A dictionary containing the text format information 
        """
        if not isinstance(text,str):
            raise TypeError('text must be a string')

        if not isinstance(text_format,dict):
           raise TypeError('text_format must be a dicitionary')
        elif len([k for k in text_format.keys() if k not in ['x_pos','y_pos','fontsize','fontweight']]) > 0:
            raise ValueError('Invalid key(s) for text_format: {}. Allowed keys are: [x_pos, y_pos, fontsize, fontweight]'.format([k for k in text_format.keys() if k not in ['x_pos','y_pos','fontsize','fontweight']]))

        if 'x_pos' not in text_format.keys():
            text_format['x_pos'] = None
        if 'y_pos' not in text_format.keys():
            text_format['y_pos'] = None
        if text_format != None and 'fontsize' not in text_format.keys():
            text_format['fontsize'] = figure_default_fontsize
        if text_format != None and 'fontweight' not in text_format.keys():
            text_format['fontweight'] = figure_default_fontweight

        self.ax.text(text_format['x_pos'], text_format['y_pos'], text, fontsize = text_format['fontsize'], fontweight = text_format['fontweight'])

        # Use draw instead of show so the graph gets updated it this is run after customzie_and_save
        plt.draw()

    def shade(self,x_range = (), y_range = (),  shade_format = {'color':'green', 'transparency':0.5}):
        """
        Shades the area between x1 and x2 and y1 and y2

        INPUTS:
        -------
             x_range: A tuple with two elements showing the x range between which should be shaded.
                      The second element must be strictly greater than the first one.
             y_range: A tuple with two elements showing the y range between which should be shaded.
                      The second element must be strictly greater than the first one.
        shade_format: The format of shaded area. Here, transparency must be an integer or float
                      between 0 (fully transparent) to 1 (fully opaque).i.
                      See: http://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.axvspan

        See: http://stackoverflow.com/questions/23248435/fill-between-two-vertical-lines-in-matplotlib
        """
        # x_range 
        if not isinstance(x_range,tuple): 
            raise TypeError('x_range must be a tuple')
        elif len(x_range) == 2 and x_range[1] <= x_range[0]: 
            raise TypeError('The second entry in x_range must be strictly greater than the first one')
       
        # y_range 
        if not isinstance(y_range,tuple): 
            raise TypeError('y_range must be a tuple')
        elif len(y_range) == 2 and y_range[1] <= y_range[0]: 
            raise TypeError('The second entry in y_range must be strictly greater than the first one')

        # shade_format
        if not isinstance(shade_format,dict):
            raise TypeError('shade_format must be a dictionary')
        elif len([k for k in shade_format.keys() if k.lower() not in ['color','transparency']]) > 0:
            raise ValueError('Invalid key for shade_fomrat: {}. Allowed keys are [color, transparency]', [k for k in shade_format.keys() if k.lower() not in ['color','transparency']])
        elif shade_format['transparency'] < 0 or shade_format['transparency'] > 1:
           raise ValueError("shade_format['transparency'] must be between 0 and 1")
            
        if x_range != ():
            self.ax.axvspan(x_range[0], x_range[1], alpha = shade_format['transparency'], color = shade_format['color'])

        if y_range != ():
            self.ax.axhspan(y_range[0], y_range[1], alpha = shade_format['transparency'], color = shade_format['color'])

        # Use draw instead of show so the graph gets updated it this is run after customzie_and_save
        plt.draw()

#------------------------
if __name__ == '__main__':
    pass
