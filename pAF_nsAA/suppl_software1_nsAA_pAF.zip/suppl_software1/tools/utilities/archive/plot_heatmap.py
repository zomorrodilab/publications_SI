from __future__ import division
import sys, time
sys.path.append('../')
import os
import matplotlib
from imp import load_source
from matplotlib import colors 
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
import numpy as np

#--- Define some global default values ---
# Defaulty figure font size (set by rcParam)
default_figure_fontsize = 20

# Default font size for title
title_default_fontsize = 24

# Defaul font size for axes and colorbar labels
axes_label_default_fontsize = 23

# Default font size for axes and colorbar ticklabels'
ticklabels_default_fontsize = 22

# Defaulty figure size
figsize_default = [8,6]

# default colormap
#colormap_default = matplotlib.cm.RdBu
colormap_default = None 

def plot_heatmap(x, y, data, plot_func = 'pcolor', interpolate = False, title = '', title_format = {'font_weight':'bold','font_size':title_default_fontsize}, xaxis_label = '', xaxis_label_format = {'font_weight':'bold','font_size':axes_label_default_fontsize, 'distance_from_ticklabels':None}, yaxis_label = '', yaxis_label_format = {'font_weight':'bold','font_size':axes_label_default_fontsize, 'distance_from_ticklabels':None}, set_minor_xticks = False, x_minorticks_spacing = None, x_majorticks_spacing = None, set_minor_yticks = False, y_minorticks_spacing = None, y_majorticks_spacing = None, xticklabels_format = {'font_weight':'bold','font_size':ticklabels_default_fontsize,'rotation':0, 'string_format':None}, yticklabels_format = {'font_weight':'bold','font_size':ticklabels_default_fontsize,'rotation':0, 'string_format':None}, invert_xaxis = False, invert_yaxis = False, colormap = None, colorbar_label = '', colorbar_label_format = {'font_weight':'bold','font_size':axes_label_default_fontsize,'rotation':270,'distance_from_ticklabels':None}, colorbar_ticklabels = None, colorbar_ticklabels_format = {'font_weight':'bold','font_size':ticklabels_default_fontsize,'rotation':0}, grid = False, figsize = figsize_default, use_tight_layout = True, dpi = None, output_filename = ''):
    """
    Creates a heatmap of data 
 
    INPUTS:
    ------
                   x: horizontal axis (list or numpy array)
                   y: Vertical axis (list or numpy array)
                data: 2-D numpy array where ROWS correspond to data on VERTIACAL axis and COLUMNS correspond to data on
                      HORIZONTAL axis.
           plot_func: Eligible choices are 'pcolor', 'pcolormesh', 'matshow', 'imshow'
             figsize: figure size (in inches). THe input must be a tuple with two elements showing the width and height
                 dpi: DPI of the figure
           colorbar: A desired color map
    colorbar_ticklabels: Desired colorbar labeles (list of strings)
         interpolate: Interpolate data (applicable only to matshow and imshow)

    Ali R. Zomorrodi, Segre Lab @ BU
    Last updated: 01-15-2016
    """
    # Title format
    if 'font_size' not in title_format.keys():
        title_format['font_size'] = title_default_fontsize 
    if 'font_weight' not in title_format.keys():
        title_format['font_weight'] = 'bold' 

    # xaxis_label_format
    if 'font_size' not in xaxis_label_format.keys():
        xaxis_label_format['font_size'] = axes_label_default_fontsize 
    if 'font_weight' not in xaxis_label_format.keys():
        xaxis_label_format['font_weight'] = 'bold' 
    if 'distance_from_ticklabels' not in xaxis_label_format.keys():
        xaxis_label_format['distance_from_ticklabels'] = None 

    # yaxis_label_format
    if 'font_size' not in yaxis_label_format.keys():
        yaxis_label_format['font_size'] = axes_label_default_fontsize 
    if 'font_weight' not in yaxis_label_format.keys():
        yaxis_label_format['font_weight'] = 'bold' 
    if 'distance_from_ticklabels' not in yaxis_label_format.keys():
        yaxis_label_format['distance_from_ticklabels'] = None 

    # xticklabels_format 
    if 'font_size' not in xticklabels_format.keys():
        xticklabels_format['font_size'] = ticklabels_default_fontsize
    if 'font_weight' not in xticklabels_format.keys():
        xticklabels_format['font_weight'] = 'bold' 
    if 'rotation' not in xticklabels_format.keys():
        xticklabels_format['rotation'] = 0 
    if 'string_format' not in xticklabels_format.keys():  # string_format is like %1.2f or %d
        xticklabels_format['string_format'] = None 

    # yticklabels_format 
    if 'font_size' not in yticklabels_format.keys():
        yticklabels_format['font_size'] = ticklabels_default_fontsize 
    if 'font_weight' not in yticklabels_format.keys():
        yticklabels_format['font_weight'] = 'bold' 
    if 'rotation' not in yticklabels_format.keys():
        yticklabels_format['rotation'] = 0 
    if 'string_format' not in yticklabels_format.keys():
        yticklabels_format['string_format'] = None 

    # colorbar_label_format
    if 'font_size' not in colorbar_label_format.keys():
        colorbar_label_format['font_size'] = axes_label_default_fontsize 
    if 'font_weight' not in colorbar_label_format.keys():
        colorbar_label_format['font_weight'] = 'bold' 
    if 'rotation' not in colorbar_label_format.keys():
        colorbar_label_format['rotation'] = 270 
    if 'distance_from_ticklabels' not in colorbar_label_format.keys():
        colorbar_label_format['distance_from_ticklabels'] = None 

    # colorbar_ticklabels_format
    if 'font_size' not in colorbar_ticklabels_format.keys():
        colorbar_ticklabels_format['font_size'] = ticklabels_default_fontsize 
    if 'font_weight' not in colorbar_ticklabels_format.keys():
        colorbar_ticklabels_format['font_weight'] = 'bold' 
    if 'rotation' not in colorbar_ticklabels_format.keys():
        colorbar_ticklabels_format['rotation'] = 0 


    fig, ax = plt.subplots(figsize = figsize)

    # Update the matplotlib configuration parameters:
    matplotlib.rcParams.update({'font.size': default_figure_fontsize,'font.weight':'bold','font.family': 'serif'})
    
    # Make the plot fill the picture
    if use_tight_layout:
        ax.set_aspect('auto')
        fig.tight_layout() 

    #------------ pcolor and pcolormesh ----------------
    if plot_func.lower() in ['pcolor','pcolormesh']:
        if plot_func.lower() == 'pcolor':
            if colormap != None:
                pc = ax.pcolor(x,y,data, cmap=colormap, vmin = data.min() - 0.5, vmax = data.max() + 0.5)
            else:
                pc = ax.pcolor(x,y,data, cmap = colormap_default, vmin = data.min(), vmax = data.max())
        elif plot_func.lower() == 'pcolormesh':
            if colormap != None:
                pc = ax.pcolormesh(x,y,data, cmap=colormap, vmin = np.min(data) - 0.5, vmax = np.max(data) + 0.5)
            else:
                pc = ax.pcolormesh(x,y,data, cmap = colormap_default, vmin = np.min(data), vmax = np.max(data))

        #-- Make a discrete color bar with custom labels shown in the middle of each color --
        if colorbar_ticklabels != None:
            # Source: http://stackoverflow.com/questions/14777066/matplotlib-discrete-colorbar
            cbar = fig.colorbar(pc,ticks=np.arange(np.min(data),np.max(data)+1))
            cbar.ax.set_yticklabels(colorbar_ticklabels,fontsize = colorbar_ticklabels_format['font_size'], weight = colorbar_ticklabels_format['font_weight'])
            for ticklabel in cbar.ax.yaxis.get_ticklabels():
                ticklabel.set_rotation(colorbar_ticklabels_format['rotation'])
        else:
            cbar = fig.colorbar(pc)
            for ticklabel in cbar.ax.yaxis.get_ticklabels():
                ticklabel.set_fontsize(colorbar_ticklabels_format['font_size'])
                ticklabel.set_fontweight(colorbar_ticklabels_format['font_weight'])
                ticklabel.set_rotation(colorbar_ticklabels_format['rotation'])
        if colorbar_label_format['distance_from_ticklabels'] != None: 
            cbar.set_label(colorbar_label,size = colorbar_label_format['font_size'], weight = colorbar_label_format['font_weight'], rotation = colorbar_label_format['rotation'], labelpad = colorbar_label_format['distance_from_ticklabels'])
        else:
            cbar.set_label(colorbar_label,size = colorbar_label_format['font_size'], weight = colorbar_label_format['font_weight'], rotation = colorbar_label_format['rotation'])

        #-- Show the row and column labels -- 
        # Show the xtick labels in the bottom
        ax.xaxis.tick_bottom()
   
        ax.set_xlim([x.min(),x.max()])
        ax.set_ylim([y.min(),y.max()])
 
        # Set major and minor ticks and tick lables 
        # Source: http://matplotlib.org/examples/pylab_examples/major_minor_demo1.html
        # Minor tick labels
        if set_minor_xticks:
            if x_minorticks_spacing != None:
                x_minorLocator = MultipleLocator(x_minorticks_spacing)
                if xticklabels_format['string_format'] != None: 
                    x_minorFormatter = FormatStrFormatter(xticklabels_format['string_format'])
                    ax.xaxis.set_minor_locator(x_minorLocator)
                    ax.xaxis.set_minor_formatter(x_minorFormatter)
            for ticklabel in ax.get_xminorticklabels():
                ticklabel.set_fontsize(xticklabels_format['font_size']) 
                ticklabel.set_fontweight(xticklabels_format['font_weight']) 
                ticklabel.set_rotation(xticklabels_format['rotation']) 

        # Major tick labels
        if x_majorticks_spacing != None:
            x_majorLocator = MultipleLocator(x_majorticks_spacing)
            if xticklabels_format['string_format'] != None: 
                x_majorFormatter = FormatStrFormatter(xticklabels_format['string_format'])
                ax.xaxis.set_major_locator(x_majorLocator)
                ax.xaxis.set_major_formatter(x_majorFormatter)
        for ticklabel in ax.get_xmajorticklabels():
            ticklabel.set_fontsize(xticklabels_format['font_size']) 
            ticklabel.set_fontweight(xticklabels_format['font_weight']) 
            ticklabel.set_rotation(xticklabels_format['rotation']) 
    
        # Minor y tick labels
        if set_minor_yticks:
            if y_minorticks_spacing != None:
                y_minorLocator = MultipleLocator(y_minorticks_spacing)
                if yticklabels_format['string_format'] != None: 
                    y_minorFormatter = FormatStrFormatter(yticklabels_format['string_format'])
                    ax.yaxis.set_minor_locator(y_minorLocator)
                    ax.yaxis.set_minor_formatter(y_minorFormatter)
            for ticklabel in ax.get_yminorticklabels():
                ticklabel.set_fontsize(yticklabels_format['font_size']) 
                ticklabel.set_fontweight(yticklabels_format['font_weight']) 
                ticklabel.set_rotation(yticklabels_format['rotation']) 

        # Major tick labels
        if y_majorticks_spacing != None:
            y_majorLocator = MultipleLocator(y_majorticks_spacing)
            if yticklabels_format['string_format'] != None: 
                y_majorFormatter = FormatStrFormatter(yticklabels_format['string_format'])
                ax.yaxis.set_major_locator(y_majorLocator)
                ax.yaxis.set_major_formatter(y_majorFormatter)
        for ticklabel in ax.get_ymajorticklabels():
            ticklabel.set_fontsize(yticklabels_format['font_size']) 
            ticklabel.set_fontweight(yticklabels_format['font_weight']) 
            ticklabel.set_rotation(yticklabels_format['rotation']) 
    
        # Invert the x axis
        if invert_xaxis:
            ax.invert_xaxis()
        if invert_yaxis:
            ax.invert_yaxis()

        if title != '':    
            ax.set_title(title,{'weight':title_format['font_weight'],'size':title_format['font_size']})
        if xaxis_label != '':    
            if xaxis_label_format['distance_from_ticklabels'] != None: 
                ax.set_xlabel(xaxis_label,{'weight':xaxis_label_format['font_weight'],'size':xaxis_label_format['font_size']}, labelpad = xaxis_label_format['distance_from_ticklabels'])
            else:
                ax.set_xlabel(xaxis_label,{'weight':xaxis_label_format['font_weight'],'size':xaxis_label_format['font_size']})
        if yaxis_label != '':    
            if yaxis_label_format['distance_from_ticklabels'] != None: 
                ax.set_ylabel(yaxis_label,{'weight':yaxis_label_format['font_weight'],'size':yaxis_label_format['font_size']}, labelpad = yaxis_label_format['distance_from_ticklabels'])
            else:
                ax.set_ylabel(yaxis_label,{'weight':yaxis_label_format['font_weight'],'size':yaxis_label_format['font_size']})

        # Set the x-axis label on the top
        #ax.xaxis.set_label_position('top') 

        ax.grid(grid)
   
        # If bbox_inches = 'tight' is not included part of the axes labels may be cut off 
        if dpi == None:
            fig.savefig(output_filename, bbox_inches='tight')
        else:
            fig.savefig(output_filename, dpi = dpi, bbox_inches='tight')

        plt.show() 

    #------------ imshow and matshow ----------------
    elif plot_func.lower() in ['matshow','imshow']:

        if plot_func.lower() == 'matshow':
            if colormap != None and interpolate:
                ms = ax.matshow(data, cmap=colormap, vmin = np.min(data) - 0.5, vmax = np.max(data) + 0.5, interpolation = 'bilinear')
            elif colormap != None and not interpolate:
                ms = ax.matshow(data, cmap=colormap, vmin = np.min(data) - 0.5, vmax = np.max(data) + 0.5)
            elif colormap == None and interpolate:
                ms = ax.matshow(data, cmap = colormap_default, vmin = np.min(data), vmax = np.max(data), interpolation = 'bilinear')
            elif colormap == None and not interpolate:
                ms = ax.matshow(data, cmap = colormap_default, vmin = np.min(data), vmax = np.max(data))

        elif plot_func.lower() == 'imshow':
            if colormap != None and interpolate:
                ms = ax.imshow(data, cmap=colormap, vmin = np.min(data) - 0.5, vmax = np.max(data) + 0.5, interpolation = 'bilinear')
            elif colormap != None and not interpolate:
                ms = ax.imshow(data, cmap=colormap, vmin = np.min(data) - 0.5, vmax = np.max(data) + 0.5)
            elif colormap == None and interpolate:
                ms = ax.imshow(data, cmap = colormap_default, vmin = np.min(data), vmax = np.max(data), interpolation = 'bilinear')
            elif colormap == None and not interpolate:
                ms = ax.imshow(data, cmap = colormap_default, vmin = np.min(data), vmax = np.max(data))

        # Make the plot fill the picture
        ax.set_aspect('auto')

        #-- Make a discrete color bar with custom labels shown in the middle of each color --
        if colorbar_ticklabels != None:
            # Source: http://stackoverflow.com/questions/14777066/matplotlib-discrete-colorbar
            cbar = fig.colorbar(ms,ticks=np.arange(np.min(data),np.max(data)+1))
            cbar.ax.set_yticklabels(colorbar_ticklabels,fontsize = colorbar_ticklabels_format['font_size'], weight = colorbar_ticklabels_format['font_weight'])
            for ticklabel in cbar.ax.yaxis.get_ticklabels():
                ticklabel.set_rotation(colorbar_ticklabels_format['rotation'])
        else:
            cbar = fig.colorbar(ms)
            for ticklabel in cbar.ax.yaxis.get_ticklabels():
                ticklabel.set_fontsize(colorbar_ticklabels_format['font_size'])
                ticklabel.set_fontweight(colorbar_ticklabels_format['font_weight'])
                ticklabel.set_rotation(colorbar_ticklabels_format['rotation'])

        if colorbar_label_format['distance_from_ticklabels'] != None: 
            cbar.set_label(colorbar_label,size = colorbar_label_format['font_size'], weight = colorbar_label_format['font_weight'], rotation = colorbar_label_format['rotation'], labelpad = colorbar_label_format['distance_from_ticklabels'])
        else:
            cbar.set_label(colorbar_label,size = colorbar_label_format['font_size'], weight = colorbar_label_format['font_weight'], rotation = colorbar_label_format['rotation'])

        #-- Show the row and column labels -- 
        # Show the xtick labels in the bottom
        ax.xaxis.tick_bottom()
    
        # Put the tick labels in the middle of boxes (don't use this for pcolor and pcolormesh)
        # Source: http://stackoverflow.com/questions/14391959/heatmap-in-matplotlib-with-pcolor
        ax.set_xticks(np.arange(data.shape[1]), minor = False)
        ax.set_yticks(np.arange(data.shape[0]), minor = False)

        # Add x and y tick labels
        ax.set_xticklabels([str(i) for i in x],fontsize = xticklabels_format['font_size'], weight = xticklabels_format['font_weight'])
        ax.set_yticklabels([str(i) for i in y], fontsize = xticklabels_format['font_size'], weight = xticklabels_format['font_weight'])

        # Invert the x axis
        if invert_xaxis:
            ax.invert_xaxis()
        if invert_yaxis:
            ax.invert_yaxis()

        if title != '':    
            ax.set_title(title,{'weight':title_format['font_weight'],'size':title_format['font_size']})
        if xaxis_label != '':    
            if xaxis_label_format['distance_from_ticklabels'] != None: 
                ax.set_xlabel(xaxis_label,{'weight':xaxis_label_format['font_weight'],'size':xaxis_label_format['font_size']}, labelpad = xaxis_label_format['distance_from_ticklabels'])
            else:
                ax.set_xlabel(xaxis_label,{'weight':xaxis_label_format['font_weight'],'size':xaxis_label_format['font_size']})
        if yaxis_label != '':    
            if yaxis_label_format['distance_from_ticklabels'] != None: 
                ax.set_ylabel(yaxis_label,{'weight':yaxis_label_format['font_weight'],'size':yaxis_label_format['font_size']}, labelpad = yaxis_label_format['distance_from_ticklabels'])
            else:
                ax.set_ylabel(yaxis_label,{'weight':yaxis_label_format['font_weight'],'size':yaxis_label_format['font_size']})


        # Set the x-axis label on the top
        #ax.xaxis.set_label_position('top') 

        ax.grid(grid)
    
        if dpi == None:
            fig.savefig(output_filename, bbox_inches='tight')
        else:
            fig.savefig(output_filename, dpi = dpi, bbox_inches='tight')

        plt.show() 
        

#------------------------
if __name__ == '__main__':
    capture_efficiency = [0,0.001,0.002,0.003,0.004,0.005,0.006,0.007,0.008,0.009,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0]
    histidine_uptake_rate = [0,0.001,0.002,0.003,0.004,0.005,0.006,0.007,0.008,0.009,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0]

    #--- Load the data ---
    file_name = 'results/game_results.py'
    # Import the data in the module stored in file_name
    if type(file_name) == str:
        if not os.path.isfile(file_name):
            raise IOError("No such file was found :'" + file_name + "'")
        else:
            # First delete the model dataFile if it already exists. If it is not deleted
            # the new module data is merged with the previous ones
            try:
                del sys.modules['dataFile']
            except:
                pass
            load_source('dataFile',file_name)
            import dataFile

    results = dataFile.results
    data = np.zeros((len(capture_efficiency),len(histidine_uptake_rate)))

    for i, eff in enumerate(capture_efficiency):
        for j, his_uptake in enumerate(histidine_uptake_rate):
            if results[(eff,his_uptake)] == [[('player_1', 'Defect'), ('player_2', 'Defect')]]:
                data[i,j] = 0
            elif results[(eff,his_uptake)] == [[('player_1', 'Cooperate'), ('player_2', 'Cooperate')]]:
                data[i,j] = 1
            #elif results[(eff,his_uptake)] == [[('player_1', 'Defect'), ('player_2', 'Defect')], [('player_1', 'Cooperate'), ('player_2', 'Cooperate')]]:
            #    data[i,j] = 2
            elif results[(eff,his_uptake)] == [[('player_1', 'Defect'), ('player_2', 'Cooperate')], [('player_1', 'Cooperate'), ('player_2', 'Defect')]]:
                data[i,j] = 2
            else:
                raise ValueError('Unknown NE: ' + str(results[(eff,his_uptake)]))

    #-- Create a color map --
    # 0 = PD --> red  1 = MB --> green  2 = HR --> blue  3 = SD --> orange
    # Source: http://stackoverflow.com/questions/30893483/make-a-heatmap-with-a-specified-discrete-color-mapping-with-matplotlib-in-python
    colorbar = colors.ListedColormap(['red', 'green', 'cyan'])

    plot_heatmap(x = np.array(histidine_uptake_rate),y = 100*np.array(capture_efficiency),data = data,title = '', xaxis_label = 'Histidine uptake rate (mmol/gDW.h)', yaxis_label = 'Capture efficiency (%)', plot_func = 'matshow', colorbar = colorbar, colorbar_ticklabels = ["Prisoner's Dilemma",'Mutually Beneficial','Snowdrift'],set_minor_xticks = True, set_minor_yticks = True,x_majorticks_spacing = None, x_minorticks_spacing = 0.1,y_majorticks_spacing = None, y_minorticks_spacing = 10,invert_xaxis = True,invert_yaxis = True, grid = False, figsize = (25,15), dpi = None, output_filename = 'results/game_results_ss_matshow.pdf')

    plot_heatmap(x = np.array(histidine_uptake_rate),y = 100*np.array(capture_efficiency),data = data,title = '', xaxis_label = 'Histidine uptake rate (mmol/gDW.h)', yaxis_label = 'Capture efficiency (%)', plot_func = 'pcolor', colorbar = colorbar, colorbar_ticklabels = ["Prisoner's Dilemma",'Mutually Beneficial','Snowdrift'],set_minor_xticks = True, set_minor_yticks = True,x_majorticks_spacing = None, x_minorticks_spacing = 0.1,y_majorticks_spacing = None, y_minorticks_spacing = 10,invert_xaxis = True,invert_yaxis = False, grid = False, figsize = (25,15), dpi = None, output_filename = 'results/game_results_ss_pcolor.pdf')


