from __future__ import division
import sys, time
sys.path.append('../../')
from tools.userError import userError
from tools.core.compound import compound
from tools.core.reaction import reaction
from tools.core.model import model
from models.model_seed_database.ModelSeed_compounds import ModelSeed_compounds, ModelSeed_compounds_by_name, ModelSeed_compounds_by_KeggID, ModelSeed_compounds_by_formula
from models.model_seed_database.ModelSeed_reactions import ModelSeed_reactions, ModelSeed_reactions_by_name, ModelSeed_reactions_by_KeggID
import re

"""
This file contains the folloiwng functions:

FUNCTIONS:
---------
remove_non_alphanumeric: Replaces all non-alphanumeric characters in a string or list of
                         string with underline or otehr alphanumeric ones 
     remove_compartment: Removes compartment ids from metabolite or reaciton names or ids
   get_cmp_ModelSeed_id: Tries to get the ModelSeed ids for one or more compounds
   get_rxn_ModelSeed_id: Tries to get the ModelSeed ids for one or more reactions

Ali R. Zomorrodi - Segre Lab @ Boston University
Last updated: 03-28-2015 
"""

def remove_non_alphanumeric(input_string):
    """
    This functions replaces the following non-alphanumeric characters in the input string
    or the input list of string input_string:
    Replaces + with _plus
    Replaces ' with _prime
    Replaces all other non-alphanumeric characters with underline

    INPUTS:
    ------
    input_string: A string or a list of strings

    OUTPUTS:
    a string with all non-alaphabetical and non-numerical characters replaced with an underline
    """
    converted_string = []

    # If the input is a string convert it to a list with one element
    if isinstance(input_string,str):
        input_string = [input_string]

    elif not isinstance(input_string,list):
        raise userError('Invluad input for remove_non_alphanumeric! String or list of strings expected.')

    for s in input_string:
        # Replace + with _plus
        s = re.sub('\+','_plus',s)

        # Replace "'" with _prime 
        s = re.sub("'",'_prime',s)

        # Replace any other non-alphanumeric character with an underline
        s = re.sub('[^\w]','_',s)

        # Replace any two subsequent underlines with one
        while '__' in s:
            s = re.sub('__','_',s)

        # Repmove any underline at the begining or at the end of a name
        s = re.sub('^_','',s)
        s = re.sub('_$','',s)

        converted_string.append(s)

    if len(converted_string) == 1:
        converted_string = converted_string[0]

    return converted_string   

def remove_compartment(input_string,compartments_info = None):
    """
    This functions removes the compartment names and/or ids from the input strings,
    which can be compound or reaction names or ids 

    INPUTS:
    ------
         input_string: A string or a list of strings
    compartments_info: A list of strings containing the names and ids of compartments.
                       If not input is proivded a number of pre-set compartment ids
                       (including _c, _e, _m, _x, _v, _n, [c], [e], [m], [x], [n]) are used.

    OUTPUTS:
    a string with all non-alaphabetical and non-numerical characters replaced with an underline
    """
    converted_string = []

    # If the input is a string convert it to a list with one element
    if isinstance(input_string,str):
        input_string = [input_string]

    elif not isinstance(input_string,list):
        raise userError('Invluad input for remove_non_alphanumeric! String or list of strings expected.')

    for s in input_string:
        # First some pre-set patterns 
        pattern = '_[c,e,p,m,x,n,v,g]0$|_[c,e,p,m,x,n,v,g]$|\[[c,e,p,m,x,n,v,g]\]$|\[[c,e,p,m,x,n,v,g]0\]$'
        if compartments_info != None:
            for compt in compartments_info:
                pattern += '|_' + compt + '$|\[' + compt + '\]$'          

        s = re.sub(pattern,'',s)

        converted_string.append(s)

    if len(converted_string) == 1:
        converted_string = converted_string[0]

    return converted_string   

def get_cmp_ModelSeed_id(cmp_list):
    """
    This functions finds the ModelSeed id for a compound or a list of compounds cmp

    INPUTS:
    -------
    cmp_list: An instance of type compound or a list of compounds

    OUTPUTS:
    --------
    If a ModelSeed id is found it is added to the ModelSeed_id field of the object compound
    """
    # All ModelSeed ids in kegg
    ModelSeed_cmp_ids = ModelSeed_compounds.keys()

    # Names of compounds in the ModelSeed 
    ModelSeed_cmp_names = ModelSeed_compounds_by_name.keys() 

    # Create a dictionary which maps the non-alphanumeric names of the compounds and 
    # original names in the ModelSeed
    names_map = {}
    for name in ModelSeed_cmp_names:
        names_map[remove_non_alphanumeric(name).lower()] = name
    # Names of compounds in the ModelSeed where all non-alpahnumeric characters are removed 
    ModelSeed_cmp_clean_names = names_map.keys() 

    # Kegg ids for compounds in the ModelSeed 
    ModelSeed_cmp_keggIDs = ModelSeed_compounds_by_KeggID.keys() 

    # Formulas of all ModelSeed compounds 
    ModelSeed_cmp_formulas = ModelSeed_compounds_by_formula 

    # Create a dictionary which maps the non-alphanumeric formul of the compounds and 
    # original names in the ModelSeed
    formulamap = {}
    for formula in ModelSeed_cmp_formulas:
        formulas_map[remove_non_alphanumeric(formula).lower()] = formula
    # Formulas of compounds in the ModelSeed where all non-alpahnumeric characters are removed 
    ModelSeed_cmp_clean_formulas = formulas_map.keys() 

    if not isinstance(cmp_list,list):
        cmp_list = [cmp_list]

    # List of all compartments in the input compounds
    compart_list = list(set([c.compartment.id for c in cmp_list]))

    for cmp in [c for c in cmp_list if c.ModelSeed_id == None]:
        # Remove non-alphanumeric characters and compartment ids from the id and replace 
        # all upper case letters with lowercase for name, id and formula
        clean_id = remove_non_alphanumeric(remove_compartment(cmp.id,compartments_info = compart_list)).lower()
        if cmp.id != None:
            clean_name = remove_non_alphanumeric(remove_compartment(cmp.name,compartments_info = compart_list)).lower() 
        if cmp.formula != None:
            clean_formula = remove_non_alphanumeric(cmp.formula).lower() 

        # Search by Kegg_id, if it is available 
        if cmp.Kegg_id != None and cmp.Kegg_id in ModelSeed_cmp_keggIDs: 
            cmp.ModelSeed_id = ModelSeed_compounds_by_KeggID[cmp.Kegg_id] 
            print '    ',cmp.id,' (Kegg id)'

        # Search by id
        elif clean_id in ModelSeed_cmp_ids:
            cmp.ModelSeed_id = clean_id 
            print '    ',cmp.id,' (id)'

        # Search by name where all non-alphanumeric characters are removed 
        elif cmp.name != None and clean_name in ModelSeed_cmp_clean_names:
	    cmp.ModelSeed_id = ModelSeed_compounds_by_name[names_map[clean_name]]
            print '    ',cmp.id,' (name)'

        # Search by formula 
        elif cmp.formula != None and clean_formula in ModelSeed_cmp_clean_formulas: 
            cmp.ModelSeed_id = ModelSeed_compounds_by_formula[formulas_map(clean_formula)] 
            print '    ',cmp.id,' (formula)'

        else:
            print '    ',cmp.id,' (None)'
 
 
        # If a ModelSeed id is found replace the name, Kegg_id and formula from the ModelSeed 
        if cmp.ModelSeed_id != None:
            # If more than one ModelSeed is was found
            if isinstance(cmp.ModelSeed_id,list) and len(cmp.ModelSeed_id) > 1:
                cmp.name = []
                cmp.name = []
                cmp.Kegg_id = []
                for seed_id in cmp.ModelSeed_id:
                    cmp.name.append(ModelSeed_compounds[seed_id]['name'])
                    cmp.formula.append(ModelSeed_compounds[seed_id]['formula']) 
                    cmp.Kegg_id.append(ModelSeed_compounds[seed_id]['Kegg_id'])

            # If only ModelSeed id was found
            elif isinstance(cmp.ModelSeed_id,list) and len(cmp.ModelSeed_id) == 1:
                cmp.ModelSeed_id = cmp.ModelSeed_id[0]      
                cmp.name = ModelSeed_compounds[cmp.ModelSeed_id]['name']
                cmp.formula = ModelSeed_compounds[cmp.ModelSeed_id]['formula']
                cmp.Kegg_id = ModelSeed_compounds[cmp.ModelSeed_id]['Kegg_id']

            # If a ModelSeed has already been assigned (as a string) in the original model 
            else:
                cmp.name = ModelSeed_compounds[cmp.ModelSeed_id]['name']
                cmp.formula = ModelSeed_compounds[cmp.ModelSeed_id]['formula']
                cmp.Kegg_id = ModelSeed_compounds[cmp.ModelSeed_id]['Kegg_id']

def get_rxn_ModelSeed_id(rxn_list):
    """
    This functions finds the ModelSeed id for a reaction or a list of reactions

    INPUTS:
    -------
    rxn_list: An instance of type reaction or a list of reactions

    OUTPUTS:
    --------
    If a ModelSeed id is found it is added to the ModelSeed_id field of the object rxn
    """
    # All ModelSeed ids in kegg
    ModelSeed_rxn_ids = ModelSeed_reactions.keys()

    # Names of reactions in the ModelSeed 
    ModelSeed_rxn_names = ModelSeed_reactions_by_name.keys() 

    # Create a dictionary which maps the non-alphanumeric names of the reactions and 
    # original names in the ModelSeed
    names_map = {}
    for name in ModelSeed_rxn_names:
        names_map[remove_non_alphanumeric(name).lower()] = name
    # Names of reactions in the ModelSeed where all non-alpahnumeric characters are removed 
    ModelSeed_rxn_clean_names = names_map.keys() 

    # Kegg ids for reactions in the ModelSeed 
    ModelSeed_rxn_keggIDs = ModelSeed_reactions_by_KeggID.keys() 

    if not isinstance(rxn_list,list):
        rxn_list = [rxn_list]

    # List of all compartments in the input compounds
    compart_list = list(set([compart.id for r in rxn_list for compart in r.compartments]))

    # Examine non-exchange reacitons first
    for rxn in [r for r in rxn_list if r.ModelSeed_id == None and 'exchange' not in r.type.lower()]:
        # Remove non-alphanumeric characters and compartment ids from the id and replace 
        # all upper case letters with lowercase for name, id and formula
        clean_id = remove_non_alphanumeric(remove_compartment(rxn.id,compartments_info = compart_list)).lower()
        if rxn.name != None:
            clean_name = remove_non_alphanumeric(remove_compartment(rxn.name,compartments_info = compart_list)).lower() 

        # Search by Kegg_id, if it is available 
        if rxn.Kegg_id != None and rxn.Kegg_id in ModelSeed_rxn_keggIDs: 
            rxn.ModelSeed_id = ModelSeed_reactions_by_KeggID[rxn.Kegg_id] 
            print '    ',rxn.id,' (Kegg id)'

        # Search by id 
        elif clean_id in ModelSeed_rxn_ids:
            rxn.ModelSeed_id = clean_id 
            print '    ',rxn.id,' (id)'

        # Search by name where all non-alphanumeric characters are removed 
        elif rxn.name != None and clean_name in ModelSeed_rxn_clean_names:
	    rxn.ModelSeed_id = ModelSeed_reactions_by_name[names_map[clean_name]]
            print '    ',rxn.id,' (name)'

        else:
            print '    ',rxn.id,' (None)'

        # If a ModelSeed id is found replace the name, Kegg_id and EC_number from the ModelSeed 
        if rxn.ModelSeed_id != None:
            # If more than one ModelSeed id was found
            if isinstance(rxn.ModelSeed_id,list) and len(rxn.ModelSeed_id) > 1:
                rxn.name = []
                rxn.EC_number = []
                rxn.Kegg_id = []
                for seed_id in rxn.ModelSeed_id:
                    rxn.name.append(ModelSeed_reactions[seed_id]['name'])
                    rxn.EC_number.append(ModelSeed_reactions[seed_id]['EC_number']) 
                    rxn.Kegg_id.append(ModelSeed_reactions[seed_id]['Kegg_id'])
    
            # If only one ModelSeed id was found
            elif isinstance(rxn.ModelSeed_id,list) and len(rxn.ModelSeed_id) == 1:
                rxn.ModelSeed_id = rxn.ModelSeed_id[0]      
                rxn.name = ModelSeed_reactions[rxn.ModelSeed_id]['name']
                rxn.EC_number = ModelSeed_reactions[rxn.ModelSeed_id]['EC_number']
                rxn.Kegg_id = ModelSeed_reactions[rxn.ModelSeed_id]['Kegg_id']
    
            # If a ModelSeed id has already been assigned (as a string) in the original model
            else: 
                rxn.name = ModelSeed_reactions[rxn.ModelSeed_id]['name']
                rxn.EC_number = ModelSeed_reactions[rxn.ModelSeed_id]['EC_number']
                rxn.Kegg_id = ModelSeed_reactions[rxn.ModelSeed_id]['Kegg_id']

    # Now examine exchange reactions by checking whether the metabolite participating in 
    # this exchange reaction has a kegg id (cmpModelSeedid). If it did, then assign 
    # EX_cmpModelSeedid_e0 as the ModelSeed id for the exchange reaction
    for rxn in [r for r in rxn_list if r.ModelSeed_id == None and 'exchange' in r.type.lower()]:
        # Check whether the compound participating in this exchange reaction has a ModelSeed id
        if rxn.compounds[0].ModelSeed_id != None:
            print '    ',rxn.id,' (compound ModelSeed_id)'
            if isinstance(rxn.compounds[0].ModelSeed_id,str):
                rxn.ModelSeed_id = 'EX_' + rxn.compounds[0].ModelSeed_id + '_e0'
            elif isinstance(rxn.compounds[0].ModelSeed_id,list):
                rxn.ModelSeed_id = []
                for sid in rxn.compounds[0].ModelSeed_id:
                    rxn.ModelSeed_id.append('EX_' + sid + '_e0')
        else: 
            print '    ',rxn.id,' (None)'

def get_ModelSeed_ids(model):
    """
    This finds the ModelSeed ids for all reactions and metabolites ia a model 
    INPUTS:
    ------
    model: An object of type model

    OUTPUTS:
    --------
    The ModelSeed ids are assigned to the field ModelSeed_id of a compound or 
    reaction in the model
    """
    print '    Getting ModelSeed ids for compounds ...'
    get_cmp_ModelSeed_id(model.compounds)
    print '    Getting ModelSeed ids for reactions ...'
    get_rxn_ModelSeed_id(model.reactions)
 
    # Compounds with more than one ModelSeed_id match
    more_than_one_cmp = [cmp for cmp in model.compounds if cmp.ModelSeed_id != None and isinstance(cmp.ModelSeed_id,list) and len(cmp.ModelSeed_id) > 1]
    if len(more_than_one_cmp) > 0:
       print'\nWARNING! More than one ModelSeed id was detected for the following compounds:'
       for cmp in more_than_one_cmp:
           print '\t',cmp.id,'\t',cmp.ModelSeed_id

    # Reactions with more than one ModelSeed_id match
    more_than_one_rxn = [rxn for rxn in model.reactions if rxn.ModelSeed_id != None and isinstance(rxn.ModelSeed_id,list) and len(rxn.ModelSeed_id) > 1]
    if len(more_than_one_rxn) > 0:
       print'\nWARNING! More than one ModelSeed id was detected for the following compounds:'
       for rxn in more_than_one_rxn:
           print '\t',rxn.id,'\t',rxn.ModelSeed_id



