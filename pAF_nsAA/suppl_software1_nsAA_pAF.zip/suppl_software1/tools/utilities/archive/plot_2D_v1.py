import matplotlib
import matplotlib.pyplot as plt

def plot2D(data, x_axis = None, y_axis = None, title = None, plot_line = None, gridlines = None, warnings = True):
    """
    2D linear plot
    data: A pyton list of inner lists where each inner list is a list of tuples  the first element 
    is the x-coordiante and the second is y-coordinate
    """
    #------------ X-axis -------------- 
    x_axis_default = {'label':'x','label_weight':'normal','label_size':12,'tick_label_size':12,'tick_label_weight':'normal'}
    if x_axis != None and  not isinstance(x_axis,dict):
        raise TypeError('Invalid x_axis type. A dictioary expected.') 
    elif x_axis != None:
        if 'label' in x_axis.keys():
            x_axis_default['label'] = x_axis['label']
        if 'label_weight' in x_axis.keys():
            x_axis_default['label_weight'] = x_axis['label_weight']
        if 'label_size' in x_axis.keys():
            x_axis_default['label_size'] = x_axis['label_size']
        if 'tick_label_size' in x_axis.keys():
            x_axis_default['tick_label_size'] = x_axis['tick_label_size']
        if 'tick_label_weight' in x_axis.keys():
            x_axis_default['tick_label_weight'] = x_axis['tick_label_weight']

        # Irrelevant keys in the input dictionary 
        irrev_keys = [k for k in x_axis.keys() if k not in x_axis_default]
        if warnings and len(irrev_keys) > 0:
            print 'WARNING! The following keys x_axis are not eligible and were ignored: {}'.format(str(irrev_keys)) 
    x_axis = x_axis_default                       

    #------------ Y-axis -------------- 
    y_axis_default = {'label':'y','label_weight':'normal','label_size':12,'tick_label_size':12,'tick_label_weight':'normal'}
    if y_axis != None and  not isinstance(y_axis,dict):
        raise TypeError('Invalid y_axis type. A dictioary expected.') 
    elif y_axis != None:
        if 'label' in y_axis.keys():
            y_axis_default['label'] = y_axis['label']
        if 'label_weight' in y_axis.keys():
            y_axis_default['label_weight'] = y_axis['label_weight']
        if 'label_size' in y_axis.keys():
            y_axis_default['label_size'] = y_axis['label_size']
        if 'tick_label_size' in y_axis.keys():
            y_axis_default['tick_label_size'] = y_axis['tick_label_size']
        if 'tick_label_weight' in y_axis.keys():
            y_axis_default['tick_label_weight'] = y_axis['tick_label_weight']
        # Irrelevant keys in the input dictionary 
        irrev_keys = [k for k in y_axis.keys() if k not in y_axis_default]
        if warnings and len(irrev_keys) > 0:
            print 'WARNING! The following keys y_axis are not eligible and were ignored: {}'.format(str(irrev_keys)) 
    y_axis = y_axis_default

    #------------ Title -------------- 
    title_default = {'title':'','size':12,'weight':'normal'}
    if title != None and  not isinstance(title,dict):
        raise TypeError('Invalid title type. A dictioary expected.') 
    elif title != None:
        if 'title' in title.keys():
            title_default['title'] = title['title']
        if 'weight' in y_axis.keys():
            title_default['weight'] = title['weight']
        if 'size' in title.keys():
            title_default['size'] = title['size']
        if 'weight' in title.keys():
            title_default['weight'] = title['weight']
        # Irrelevant keys in the input dictionary 
        irrev_keys = [k for k in title.keys() if k not in title_default]
        if warnings and len(irrev_keys) > 0:
            print 'WARNING! The following keys title are not eligible and were ignored: {}'.format(str(irrev_keys)) 
    title = title_default

    #------------ Plot line -------------- 
    plot_line_default = {'style':'-','width':1, 'color': 'k','label':''} 
    if plot_line != None and  not isinstance(plot_line,dict):
        raise TypeError('Invalid plot_line type. A dictioary expected.') 
    elif plot_line != None:
        if 'style' in plot_line.keys():
            plot_line_default['style'] = plot_line['style']
        if 'width' in plot_line.keys():
            plot_line_default['width'] = plot_line['width']
        if 'size' in plot_line.keys():
            plot_line_default['color'] = plot_line['color']
        if 'label' in plot_line.keys():
            plot_line_default['label'] = plot_line['label']
        # Irrelevant keys in the input dictionary 
        irrev_keys = [k for k in plot_line.keys() if k not in plot_line_default]
        if warnings and len(irrev_keys) > 0:
            print 'WARNING! The following keys plot_line are not eligible and were ignored: {}'.format(str(irrev_keys)) 
    plot_line = plot_line_default


    #------------ Gridlines -------------- 
    gridlines_default = {'add_gridlines':False,'type':'major','color': 'k','linestyle':'--'} 
    if gridlines != None and  not isinstance(gridlines,dict):
        raise TypeError('Invalid gridlines type. A dictioary expected.') 
    elif gridlines != None:
        if 'add_gridlines' in gridlines.keys():
            gridlines_default['add_gridlines'] = gridlines['add_gridlines']
        if 'type' in y_axis.keys():
            gridlines_default['type'] = gridlines['type']
        if 'color' in gridlines.keys():
            gridlines_default['color'] = gridlines['color']
        if 'linestyle' in gridlines.keys():
            gridlines_default['linestyle'] = gridlines['linestyle']
        # Irrelevant keys in the input dictionary 
        irrev_keys = [k for k in gridlines.keys() if k not in gridlines_default]
        if warnings and len(irrev_keys) > 0:
            print 'WARNING! The following keys gridlines are not eligible and were ignored: {}'.format(str(irrev_keys)) 
    gridlines = gridlines_default
     
    #------------ Plot Data -------------- 
    plt.rc('xtick', labelsize = x_axis['tick_label_size'])
    plt.rc('ytick', labelsize = y_axis['tick_label_size'])
    for vec in data:
        plt.plot([x[0] for x in vec],[x[1] for x in vec],label = plot_line['label'],linewidth = plot_line['width'],linestyle = plot_line['style'],color = plot_line['color'])
    plt.xlabel(x_axis['label'],{'weight':x_axis['label_weight'],'size':x_axis['label_size']})
    plt.ylabel(y_axis['label'],{'weight':y_axis['label_weight'],'size':y_axis['label_size']})
    plt.title(title['title'], fontsize = title['size'], weight = title['weight'])

    plt.grid(gridlines['add_gridlines'], which = gridlines['type'], color = gridlines['color'], linestyle=gridlines['linestyle'])
    plt.show()

#--------------------------------
if __name__ == '__main__':
    #plot2D(data = [[(0,0),(1,2),(3,6),(4,8),(5,10)]], x_axis = None, y_axis = None, title = None, plot_line = None)
           
    x_axis = {'label':'Time','label_weight':'bold','label_size':26,'tick_label_size':20,'tick_label_weight':'normal'}
    y_axis = {'label':'Time','label_weight':'bold','label_size':26,'tick_label_size':20,'tick_label_weight':'normal'}
    title = {'title':'Test','size':30,'weight':'bold'}
    gridlines = {'add_gridlines':True,'type':'major','color': 'b','linestyle':'--'} 
    plot_line = {'style':'-','width':3, 'color': 'k','label':''} 

    plot2D(data = [[(0,0),(1,2),(3,6),(4,8),(5,10)]], x_axis = x_axis, y_axis = y_axis, title = title, gridlines = gridlines, plot_line = plot_line)

