from __future__ import division
import sys, time
sys.path.append('../../')
from tools.userError import userError
from tools.core.compound import compound
from tools.core.reaction import reaction
from tools.core.model import model
from models.model_seed_database.ModelSeed_compounds import ModelSeed_compounds
from models.model_seed_database.ModelSeed_reactions import ModelSeed_reactions
import re

"""
This file contains the folloiwng functions:

FUNCTIONS:
---------
remove_non_alphanumeric: Replaces all non-alphanumeric characters in a string or list of
                         string with underline or otehr alphanumeric ones 
remove_non_alphanumeric: Tries to get the ModelSeed ids for one or more compounds
remove_non_alphanumeric: Tries to get the Modelseed ids for one ore more reactions
      get_ModelSeed_ids: Tries to get the ModelSeed ids for a model

Ali R. Zomorrodi - Segre Lab @ Boston University
Last updated: 03-22-2015 
"""

def remove_non_alphanumeric(input_string):
    """
    This functions replaces the following non-alphanumeric characters in the input string
    or the input list of string input_string:
    Replaces + with _plus
    Replaces ' with _prime
    Replaces all other non-alphanumeric characters with underline

    INPUTS:
    ------
    input_string: A string or a list of strings

    OUTPUTS:
    a string with all non-alaphabetical and non-numerical characters replaced with an underline
    """
    converted_string = []

    # If the input is a string convert it to a list with one element
    if isinstance(input_string,str):
        input_string = [input_string]

    if type(input_string) is list:
        for s in input_string:
            # Replace + with _plus
            s = re.sub('\+','_plus',s)

            # Replace "'" with _prime 
            s = re.sub("'",'_prime',s)

            # Replace any other non-alphanumeric character with an underline
            s = re.sub('[^\w]','_',s)

            converted_string.append(s)
    else:
        raise userError('Invluad input for remove_non_alphanumeric! String or list of strings expected.')

    if len(converted_string) == 1:
        converted_string = converted_string[0]

    return converted_string   

def get_cmp_ModelSeed_id(cmp_list):
    """
    This functions finds the ModelSeed id for a compound or a list of compounds cmp

    INPUTS:
    -------
    cmp_list: An instance of type compound or a list of compounds

    OUTPUTS:
    --------
    If a ModelSeed id is found it is added to the ModelSeed_id field of the object compound
    """
    # Id of ModelSeed compounds with a kegg name
    ModelSeed_cmp_id_withkeggID = [sid for sid in ModelSeed_compounds.keys() if ModelSeed_compounds[sid]['Kegg_id'] != None]

    # Id of ModelSeed compounds with a kegg formula
    ModelSeed_cmp_id_withFormula = [sid for sid in ModelSeed_compounds.keys() if ModelSeed_compounds[sid]['formula'] != None]

    # List of Kegg ids in ModelSeed
    ModelSeed_KeggIDs = [ModelSeed_compounds[sid]['Kegg_id']]

    if not isinstance(cmp_list,list):
        cmp_list = [cmp_list]

    for cmp in [c for c in cmp_list if c.ModelSeed_id == None]:
        print '    ',cmp.id
        # Search by Kegg_id, if it is available 
        if cmp.Kegg_id != None and len([sid for sid in ModelSeed_cmp_id_withkeggID if cmp.Kegg_id in ModelSeed_compounds[sid]['Kegg_id']]) > 0:
            cmp.ModelSeed_id = [sid for sid in ModelSeed_cmp_id_withkeggID if cmp.Kegg_id in ModelSeed_compounds[sid]['Kegg_id']] 

        # Search by id if Kegg id is not available. Use regular expression to remove the compartment id
        # from their ids. Here we consider generally used compartment ids such as c0, e0, p0, m0, x0, g0 and
        # v0, or c, e, p, m, x, g and v
        elif len([sid for sid in ModelSeed_compounds.keys() if re.sub('_' + cmp.compartment.id + '$|' + '\[' + cmp.compartment.id + '\]$' + '|_[c,e,p,m,x,n,v,g]0$' + '|_[c,e,p,m,x,n,v,g]$' + '|\[' + '[c,e,p,m,x,n,v,g]\]$','',cmp.id).lower() == sid.lower()]) > 0: 
            cmp.ModelSeed_id = [sid for sid in ModelSeed_compounds.keys() if re.sub('_' + cmp.compartment.id + '$|' + '\[' + cmp.compartment.id + '\]$' + '|_[c,e,p,m,x,n,v,g]0$' + '|_[c,e,p,m,x,n,v,g]$' + '|\[' + '[c,e,p,m,x,n,v,g]\]$','',cmp.id).lower() == sid.lower()] 

        # Search by name 
        elif len([sid for sid in ModelSeed_compounds.keys() if cmp.name.lower() in [n.lower() for n in ModelSeed_compounds[sid]['name']] or remove_non_alphanumeric(cmp.name.lower()) in [n.lower() for n in remove_non_alphanumeric(ModelSeed_compounds[sid]['name'])]]) > 0:
	    cmp.ModelSeed_id = [sid for sid in ModelSeed_compounds.keys() if cmp.name.lower() in [n.lower() for n in ModelSeed_compounds[sid]['name']] or remove_non_alphanumeric(cmp.name.lower()) in [n.lower() for n in remove_non_alphanumeric(ModelSeed_compounds[sid]['name'])]]

        # Search by formula 
        elif cmp.formula != None and len([sid for sid in ModelSeed_cmp_id_withFormula if cmp.formula.lower() == ModelSeed_compounds[sid]['formula'].lower() or remove_non_alphanumeric(cmp.formula.lower()) == remove_non_alphanumeric(ModelSeed_compounds[sid]['formula'].lower())]) > 0:
            cmp.ModelSeed_id = [sid for sid in ModelSeed_cmp_id_withFormula if cmp.formula.lower() == ModelSeed_compounds[sid]['formula'].lower() or remove_non_alphanumeric(cmp.formula.lower()) == remove_non_alphanumeric(ModelSeed_compounds[sid]['formula'].lower())] 
 
        # If a ModelSeed id is found replace the name, Kegg_id and formula from the ModelSeed 
        if cmp.ModelSeed_id != None:
            # If more than one ModelSeed is was found
            if isinstance(cmp.ModelSeed_id,list) and len(cmp.ModelSeed_id) > 1:
                cmp.name = []
                cmp.name = []
                cmp.Kegg_id = []
                for seed_id in cmp.ModelSeed_id:
                    cmp.name.append(ModelSeed_compounds[seed_id]['name'])
                    cmp.formula.append(ModelSeed_compounds[seed_id]['formula']) 
                    cmp.Kegg_id.append(ModelSeed_compounds[seed_id]['Kegg_id'])

            # If only ModelSeed id was found
            elif isinstance(cmp.ModelSeed_id,list) and len(cmp.ModelSeed_id) == 1:
                cmp.ModelSeed_id = cmp.ModelSeed_id[0]      
                cmp.name = ModelSeed_compounds[cmp.ModelSeed_id]['name']
                cmp.formula = ModelSeed_compounds[cmp.ModelSeed_id]['formula']
                cmp.Kegg_id = ModelSeed_compounds[cmp.ModelSeed_id]['Kegg_id']

            # If a ModelSeed has already been assigned (as a string) in the original model 
            else:
                cmp.name = ModelSeed_compounds[cmp.ModelSeed_id]['name']
                cmp.formula = ModelSeed_compounds[cmp.ModelSeed_id]['formula']
                cmp.Kegg_id = ModelSeed_compounds[cmp.ModelSeed_id]['Kegg_id']

def get_rxn_ModelSeed_id(rxn_list):
    """
    This functions finds the ModelSeed id for a reaction or a list of reactions

    INPUTS:
    -------
    rxn_list: An instance of type reaction or a list of reactions

    OUTPUTS:
    --------
    If a ModelSeed id is found it is added to the ModelSeed_id field of the object rxn
    """
    # Id of ModelSeed reactions with a Kegg id
    ModelSeed_rxn_id_withkeggID = [sid for sid in ModelSeed_reactions.keys() if ModelSeed_reactions[sid]['Kegg_id'] != None] 
 
    if not isinstance(rxn_list,list):
       rxn_list = [rxn_list]

    for rxn in [r for r in rxn_list if r.ModelSeed_id == None]:
        print '    ',rxn.id
        # Search by Kegg_id, if it is available 
        # Search by Kegg_id, if it is available 
        if rxn.Kegg_id != None and len([sid for sid in ModelSeed_rxn_id_withkeggID if rxn.Kegg_id in ModelSeed_reactions[sid]['Kegg_id']]) > 0:
            rxn.ModelSeed_id = [sid for sid in ModelSeed_rxn_id_withkeggID if rxn.Kegg_id in ModelSeed_reactions[sid]['Kegg_id']] 

        # Search by id. If the reaction has multiple compartments
        # Consider only the first one
        elif len([sid for sid in ModelSeed_reactions.keys() if re.sub('_' + rxn.compartments[0].id + '$|' + '\[' + rxn.compartments[0].id + '\]$' + '|_[c,e,p,m,x,n,v,g]0$' + '|_[c,e,p,m,x,n,v,g]$' + '|\[' + '[c,e,p,m,x,n,v,g]\]$','',rxn.id) == sid]) > 0: 
            rxn.ModelSeed_id = [sid for sid in ModelSeed_reactions.keys() if re.sub('_' + rxn.compartments[0].id + '$|' + '\[' + rxn.compartments[0].id + '\]$' + '|_[c,e,p,m,x,n,v,g]0$' + '|_[c,e,p,m,x,n,v,g]$' + '|\[' + '[c,e,p,m,x,n,v,g]\]$','',rxn.id) == sid] 

        # Search by name if Kegg id is not available 
        elif len([sid for sid in ModelSeed_reactions.keys() if rxn.name.lower() in [n.lower() for n in ModelSeed_reactions[sid]['Name']] or remove_non_alphanumeric(rxn.name.lower()) in [n.lower() for n in remove_non_alphanumeric(ModelSeed_reactions['Name'])]]) > 0:
            rxn.ModelSeed_id = [sid for sid in ModelSeed_reactions.keys() if rxn.name.lower() in [n.lower() for n in ModelSeed_reactions[sid]['Name']] or remove_non_alphanumeric(rxn.name.lower()) in [n.lower() for n in remove_non_alphanumeric(ModelSeed_reactions['Name'])]]
 
        # If a ModelSeed id is found replace the name, Kegg_id and EC_number from the ModelSeed 
        if rxn.ModelSeed_id != None:
            # If more than one ModelSeed id was found
            if isinstance(rxn.ModelSeed_id,list) and len(rxn.ModelSeed_id) > 1:
                rxn.name = []
                rxn.name = []
                rxn.Kegg_id = []
                for seed_id in rxn.ModelSeed_id:
                    rxn.name.append(ModelSeed_reactions[seed_id]['name'])
                    rxn.EC_number.append(ModelSeed_reactions[seed_id]['EC_number']) 
                    rxn.Kegg_id.append(ModelSeed_reactions[seed_id]['Kegg_id'])
    
            # If only one ModelSeed id was found
            elif isinstance(rxn.ModelSeed_id,list) and len(rxn.ModelSeed_id) == 1:
                rxn.ModelSeed_id = rxn.ModelSeed_id[0]      
                rxn.name = ModelSeed_reactions[rxn.ModelSeed_id]['name']
                rxn.EC_number = ModelSeed_reactions[rxn.ModelSeed_id]['EC_number']
                rxn.Kegg_id = ModelSeed_reactions[rxn.ModelSeed_id]['Kegg_id']
    
            # If a ModelSeed id has already been assigned (as a string) in the original model
            else: 
                rxn.name.append(ModelSeed_reactions[rxn.ModelSeed_id]['name'])
                rxn.EC_number.append(ModelSeed_reactions[rxn.ModelSeed_id]['EC_number']) 
                rxn.Kegg_id.append(ModelSeed_reactions[rxn.ModelSeed_id]['Kegg_id'])
    

def get_ModelSeed_ids(model):
    """
    This finds the ModelSeed ids for all reactions and metabolites ia a model 
    INPUTS:
    ------
    model: An object of type model

    OUTPUTS:
    --------
    The ModelSeed ids are assigned to the field ModelSeed_id of a compound or 
    reaction in the model
    """
    print '    Getting ModelSeed ids for compounds ...'
    get_cmp_ModelSeed_id(model.compounds)
    print '    Getting ModelSeed ids for reactions ...'
    get_rxn_ModelSeed_id(model.reactions)
 
    # Compounds with more than one ModelSeed_id match
    more_than_one_cmp = [cmp for cmp in model.compounds if cmp.ModelSeed_id != None and isinstance(cmp.ModelSeed_id,list) and len(cmp_list.ModelSeed_id) > 1]
    if len(more_than_one_cmp) > 0:
       print'\nWARNING! More than one ModelSeed id was detected for the following compounds:'
       for cmp in more_than_one_cmp:
           print '\t',cmp.id,'\t',cmp.ModelSeed_id

    # Reactions with more than one ModelSeed_id match
    more_than_one_rxn = [rxn for rxn in model.reactions if rxn.ModelSeed_id != None and isinstance(rxn.ModelSeed_id,list) and len(rxn_list.ModelSeed_id) > 1]
    if len(more_than_one_rxn) > 0:
       print'\nWARNING! More than one ModelSeed id was detected for the following compounds:'
       for rxn in more_than_one_rxn:
           print '\t',rxn.id,'\t',rxn.ModelSeed_id



