

OptForce_sim.py
Contains a function that run OptForce and additional functions to create an engineered strain model, verify the identified interventions, etc. Function OptForce_sim in this file is the main function to run  

ss_analysis.py
Contains functions that creates the engineered models, makes the tradeoff plots, etc.

models
A directory containing metabolic models of the E. coli

results
Directory to store the results

tools
Directory containing multiple subdirectories to perfrorm different tasks, such as creating a metabolic model, performing FBA, performign OptFroce, etc. 

